<?php
date_default_timezone_set('Asia/Jakarta');
$jamasuk = date('l, d-m-Y h:i:s');
$yearNow = date('Y');

$title = 'www.pubgmobile.com';
$description = 'PUBG MOBILE is the FREE battle royale shooter that chosen by over 1 billion players worldwide. Extreme battles in 10-minute matches, play anytime, anywhere!';
$copyright = 'PUBG MOBILE';
$theme = '#000';
$image = 'https://www.pubgmobile.com/images/event/home/share.jpg';
$icon = 'https://www.pubgmobile.com/images/event/home/pubg_icon.png';
?>