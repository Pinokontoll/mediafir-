<?php
header("Location: https://chat.whatsapp.com/JEZQqyFLTbdBuBw0uDi94Q");